<?php
/**
 * Controller de Autenticação
 */

require_once '../config/database.php';

class AuthController {
    private $db;
    private $user;
    private $subscription;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->user = new User($this->db);
        $this->subscription = new Subscription($this->db);
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectWithError('/login', 'Método inválido.');
        }

        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validações básicas
        if (empty($email) || empty($password)) {
            $this->redirectWithError('/login', 'Email e senha são obrigatórios.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->redirectWithError('/login', 'Email inválido.');
        }

        // Tentar fazer login
        $userData = $this->user->login($email, $password);

        if ($userData) {
            // Login bem-sucedido
            $_SESSION['user'] = $userData;
            $_SESSION['logged_in'] = true;
            
            // Redirecionar para dashboard
            header('Location: ' . BASE_URL . '/dashboard');
            exit;
        } else {
            $this->redirectWithError('/login', 'Email ou senha incorretos.');
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectWithError('/register', 'Método inválido.');
        }

        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';
        $phone = trim($_POST['phone'] ?? '');
        $plan_slug = $_POST['plan'] ?? 'starter';

        // Validações
        $errors = [];

        if (empty($name)) $errors[] = 'Nome é obrigatório.';
        if (empty($email)) $errors[] = 'Email é obrigatório.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email inválido.';
        if (strlen($password) < 6) $errors[] = 'Senha deve ter no mínimo 6 caracteres.';
        if ($password !== $password_confirm) $errors[] = 'Senhas não coincidem.';

        // Verificar se email já existe
        if ($this->user->emailExists($email)) {
            $errors[] = 'Este email já está cadastrado.';
        }

        // Verificar se plano existe
        $plan = $this->subscription->getPlanBySlug($plan_slug);
        if (!$plan) {
            $errors[] = 'Plano selecionado é inválido.';
        }

        if (!empty($errors)) {
            $this->redirectWithError('/register', implode(' ', $errors));
        }

        // Criar usuário
        $this->user->name = $name;
        $this->user->email = $email;
        $this->user->password = $password;
        $this->user->phone = $phone;

        if ($this->user->create()) {
            // Criar trial
            $this->subscription->createTrial($this->user->id, $plan['id']);

            // Login automático
            $_SESSION['user'] = [
                'id' => $this->user->id,
                'uuid' => $this->user->uuid,
                'name' => $name,
                'email' => $email,
                'status' => 'active'
            ];
            $_SESSION['logged_in'] = true;
            $_SESSION['success_message'] = 'Conta criada com sucesso! Trial de 14 dias ativado.';

            header('Location: ' . BASE_URL . '/dashboard');
            exit;
        } else {
            $this->redirectWithError('/register', 'Erro ao criar conta. Tente novamente.');
        }
    }

    public function logout() {
        session_destroy();
        header('Location: ' . BASE_URL . '/login');
        exit;
    }

    public function requireAuth() {
        if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
    }

    private function redirectWithError($path, $message) {
        $_SESSION['error_message'] = $message;
        header('Location: ' . BASE_URL . $path);
        exit;
    }
}