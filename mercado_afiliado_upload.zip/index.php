<?php
/**
 * Arquivo de redirecionamento para public/
 */
header('Location: public/');
exit;