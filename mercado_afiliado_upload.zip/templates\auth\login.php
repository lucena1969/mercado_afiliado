<?php
// Redirecionar se já estiver logado
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    header('Location: ' . BASE_URL . '/dashboard');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body style="background: #f9fafb;">
    <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem;">
        <div style="width: 100%; max-width: 400px;">
            <!-- Logo -->
            <div style="text-align: center; margin-bottom: 2rem;">
                <a href="<?= BASE_URL ?>" style="display: inline-flex; align-items: center; gap: 0.5rem; text-decoration: none; color: var(--color-dark);">
                    <div style="width: 40px; height: 40px; background: var(--color-primary); border-radius: 8px;"></div>
                    <span style="font-size: 1.5rem; font-weight: 700;">Mercado Afiliado</span>
                </a>
            </div>

            <!-- Card de Login -->
            <div class="card">
                <div class="card-header">
                    <h1 style="font-size: 1.5rem; font-weight: 600; text-align: center;">Faça seu login</h1>
                </div>
                <div class="card-body">
                    <!-- Mensagens de erro/sucesso -->
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-error">
                            <?= htmlspecialchars($_SESSION['error_message']) ?>
                        </div>
                        <?php unset($_SESSION['error_message']); ?>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/api/auth/login" method="POST">
                        <div class="form-group">
                            <label for="email" class="form-label">E-mail</label>
                            <input 
                                type="email" 
                                id="email" 
                                name="email" 
                                class="form-input" 
                                placeholder="seu@email.com"
                                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="password" class="form-label">Senha</label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                class="form-input" 
                                placeholder="••••••••"
                                required
                            >
                        </div>

                        <div style="margin-bottom: 1rem;">
                            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                                <input type="checkbox" name="remember" style="margin: 0;">
                                <span style="font-size: 0.875rem; color: var(--color-gray);">Lembrar de mim</span>
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width: 100%; margin-bottom: 1rem;">
                            Entrar
                        </button>
                    </form>

                    <div style="text-align: center; margin-top: 1rem;">
                        <a href="#" style="color: var(--color-primary); text-decoration: none; font-size: 0.875rem;">
                            Esqueceu sua senha?
                        </a>
                    </div>
                </div>
            </div>

            <!-- Link para registro -->
            <div style="text-align: center; margin-top: 1.5rem; color: var(--color-gray);">
                Não tem uma conta? 
                <a href="<?= BASE_URL ?>/register" style="color: var(--color-primary); text-decoration: none; font-weight: 600;">
                    Teste grátis por 14 dias
                </a>
            </div>
        </div>
    </div>

    <script>
        // Auto-focus no primeiro campo
        document.getElementById('email').focus();
    </script>
</body>
</html>