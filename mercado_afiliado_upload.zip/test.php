<?php
echo "PHP está funcionando!<br>";
echo "Data/hora: " . date('Y-m-d H:i:s') . "<br>";
echo "Servidor: " . $_SERVER['SERVER_SOFTWARE'];
phpinfo();
?>