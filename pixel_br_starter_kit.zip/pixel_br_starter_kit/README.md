# Pixel BR – Starter Kit (Mercado Afiliado)
[Conteúdo resumido; veja instruções na resposta principal.]