<?php
/**
 * API para busca de qualificações para vinculação com tramitações
 * Permite buscar por NUP, objeto, área demandante ou palavras-chave
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

try {
    // Verificar se usuário está logado
    verificarLogin();
    
    $pdo = conectarDB();
    $usuario_nivel = $_SESSION['usuario_nivel'] ?? 4;
    
    // Parâmetros de busca
    $busca = trim($_GET['busca'] ?? '');
    $limite = min(20, max(1, intval($_GET['limite'] ?? 10)));
    
    if (strlen($busca) < 2) {
        echo json_encode([
            'success' => true,
            'message' => 'Digite pelo menos 2 caracteres para buscar',
            'data' => []
        ]);
        exit;
    }
    
    // Construir query de busca
    $where_conditions = [];
    $params = [];
    
    // Busca por múltiplos campos
    $search_fields = [
        "nup LIKE ?",
        "objeto LIKE ?", 
        "area_demandante LIKE ?",
        "palavras_chave LIKE ?",
        "responsavel LIKE ?"
    ];
    
    $where_conditions[] = "(" . implode(" OR ", $search_fields) . ")";
    
    // Adicionar parâmetro para cada campo de busca
    for ($i = 0; $i < count($search_fields); $i++) {
        $params[] = "%$busca%";
    }
    
    // Filtrar apenas qualificações em status apropriados para tramitação
    $status_validos = ['EM ANÁLISE', 'PENDENTE', 'AGUARDANDO REVISÃO', 'EM REVISÃO'];
    $where_conditions[] = "status IN ('" . implode("','", $status_validos) . "')";
    
    // Aplicar filtros por nível de usuário se necessário
    if ($usuario_nivel == 2) { // DIPLAN - apenas planejamento
        // Para DIPLAN, mostrar todas as qualificações (eles precisam ver para criar tramitações)
    } elseif ($usuario_nivel == 3) { // DIPLI - foco em licitação/qualificação  
        // Para DIPLI, mostrar todas as qualificações (eles trabalham com qualificação)
    }
    // Coordenador (1) e Visitante (4) veem todas
    
    $where_clause = implode(' AND ', $where_conditions);
    
    // Query principal
    $sql = "
        SELECT 
            id,
            nup,
            area_demandante,
            responsavel,
            modalidade,
            objeto,
            palavras_chave,
            valor_estimado,
            status,
            criado_em,
            atualizado_em,
            -- Calcular dias desde criação
            DATEDIFF(NOW(), criado_em) as dias_criacao,
            -- Verificar se já tem tramitação vinculada
            (SELECT COUNT(*) FROM tramitacoes_kanban tk WHERE tk.qualificacao_id = qualificacoes.id) as tramitacoes_existentes
        FROM qualificacoes 
        WHERE $where_clause
        ORDER BY 
            -- Priorizar sem tramitações
            tramitacoes_existentes ASC,
            -- Depois por data de criação (mais recentes primeiro)
            criado_em DESC
        LIMIT ?
    ";
    
    $params[] = $limite;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Processar resultados para formato de resposta
    $dados_processados = [];
    
    foreach ($resultados as $qualificacao) {
        // Calcular status da tramitação
        $status_tramitacao = 'disponivel';
        if ($qualificacao['tramitacoes_existentes'] > 0) {
            $status_tramitacao = 'em_tramitacao';
        }
        
        // Determinar cor do status
        $cor_status = match($qualificacao['status']) {
            'EM ANÁLISE' => '#f59e0b',
            'PENDENTE' => '#ef4444', 
            'AGUARDANDO REVISÃO' => '#3b82f6',
            'EM REVISÃO' => '#8b5cf6',
            default => '#6b7280'
        };
        
        // Preparar objeto resumido
        $objeto_resumido = strlen($qualificacao['objeto']) > 80 
            ? substr($qualificacao['objeto'], 0, 80) . '...' 
            : $qualificacao['objeto'];
            
        $dados_processados[] = [
            'id' => (int)$qualificacao['id'],
            'nup' => $qualificacao['nup'],
            'area_demandante' => $qualificacao['area_demandante'],
            'responsavel' => $qualificacao['responsavel'],
            'modalidade' => $qualificacao['modalidade'],
            'objeto' => $qualificacao['objeto'],
            'objeto_resumido' => $objeto_resumido,
            'palavras_chave' => $qualificacao['palavras_chave'] ? explode(',', $qualificacao['palavras_chave']) : [],
            'valor_estimado' => (float)$qualificacao['valor_estimado'],
            'valor_formatado' => 'R$ ' . number_format($qualificacao['valor_estimado'], 2, ',', '.'),
            'status' => $qualificacao['status'],
            'cor_status' => $cor_status,
            'status_tramitacao' => $status_tramitacao,
            'tramitacoes_existentes' => (int)$qualificacao['tramitacoes_existentes'],
            'dias_criacao' => (int)$qualificacao['dias_criacao'],
            'criado_em' => $qualificacao['criado_em'],
            'atualizado_em' => $qualificacao['atualizado_em']
        ];
    }
    
    // Resposta de sucesso
    echo json_encode([
        'success' => true,
        'message' => count($dados_processados) . ' qualificação(ões) encontrada(s)',
        'data' => $dados_processados,
        'total' => count($dados_processados),
        'busca' => $busca,
        'limite' => $limite
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Log do erro
    error_log("Erro na API buscar_qualificacoes: " . $e->getMessage());
    
    // Resposta de erro
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar qualificações: ' . $e->getMessage(),
        'data' => []
    ], JSON_UNESCAPED_UNICODE);
}
?>