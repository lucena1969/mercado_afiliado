<?php
require_once '../config.php';
require_once '../functions.php';

verificarLogin();

header('Content-Type: application/json');

$pdo = conectarDB();

try {
    // Se nenhum parâmetro for fornecido, retorna todos os PCAs (para seletor)
    if (!isset($_GET['id']) && !isset($_GET['numero_contratacao'])) {
        $busca = $_GET['busca'] ?? '';
        
        $sql = "SELECT 
                id,
                numero_contratacao, 
                titulo_contratacao, 
                area_requisitante, 
                valor_total_contratacao, 
                prioridade,
                numero_dfd,
                situacao_execucao
                FROM pca_dados 
                WHERE numero_contratacao IS NOT NULL";
        
        $params = [];
        
        // Se houver busca, filtrar
        if (!empty($busca)) {
            $sql .= " AND (numero_contratacao LIKE ? OR titulo_contratacao LIKE ? OR numero_dfd LIKE ?)";
            $busca_param = "%$busca%";
            $params[] = $busca_param;
            $params[] = $busca_param;
            $params[] = $busca_param;
        }
        
        $sql .= " ORDER BY numero_contratacao DESC";
        
        // Aplicar limite apenas quando há busca (para performance)
        if (!empty($busca)) {
            $sql .= " LIMIT 100";
        } else {
            // Sem busca: retorna todos os registros
            $sql .= " LIMIT 1000"; // Limite alto para garantir que todos sejam retornados
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $data = $stmt->fetchAll();
        
        echo json_encode($data);
        exit;
    }

    // Se for busca por ID (funcionalidade existente)
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $sql = "SELECT id, numero_contratacao, titulo_contratacao, area_requisitante, 
                valor_total_contratacao, prioridade, numero_dfd, situacao_execucao
                FROM pca_dados 
                WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        
        if ($data) {
            echo json_encode($data);
        } else {
            echo json_encode(['erro' => 'Dados não encontrados']);
        }
        exit;
    }

    // Se for busca por número de contratação
    if (isset($_GET['numero_contratacao'])) {
        $numeroContratacao = $_GET['numero_contratacao'];
        
        $sql = "SELECT 
            id,
            numero_contratacao, 
            titulo_contratacao, 
            area_requisitante, 
            valor_total_contratacao, 
            prioridade,
            numero_dfd,
            situacao_execucao
            FROM pca_dados 
            WHERE numero_contratacao = ?
            LIMIT 1";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$numeroContratacao]);
        $data = $stmt->fetch();
        
        if ($data) {
            echo json_encode($data);
        } else {
            echo json_encode(['erro' => 'Dados não encontrados']);
        }
        exit;
    }
    
} catch (Exception $e) {
    echo json_encode(['erro' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?>