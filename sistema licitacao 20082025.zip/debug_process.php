<?php
// Debug script para verificar se o process.php está funcionando
echo "<h1>🔍 Debug do Process.php</h1>";

// Verificar se o arquivo error.log existe
$error_log_path = "C:\\xampp\\apache\\logs\\error.log";
$error_log_alt = ini_get('error_log');

echo "<h2>📋 Informações do Sistema:</h2>";
echo "<ul>";
echo "<li><strong>PHP Version:</strong> " . phpversion() . "</li>";
echo "<li><strong>Error Log Path (ini):</strong> " . ($error_log_alt ?: 'Não definido') . "</li>";
echo "<li><strong>Error Log XAMPP:</strong> $error_log_path</li>";
echo "<li><strong>Log Errors:</strong> " . (ini_get('log_errors') ? 'Ativado' : 'Desativado') . "</li>";
echo "<li><strong>Display Errors:</strong> " . (ini_get('display_errors') ? 'Ativado' : 'Desativado') . "</li>";
echo "</ul>";

// Verificar se o arquivo de log existe
if (file_exists($error_log_path)) {
    echo "<h2>📄 Últimas linhas do Error Log:</h2>";
    $lines = file($error_log_path);
    $last_lines = array_slice($lines, -20); // Últimas 20 linhas
    echo "<pre style='background: #f5f5f5; padding: 10px; border: 1px solid #ddd; max-height: 300px; overflow-y: scroll;'>";
    foreach ($last_lines as $line) {
        if (strpos($line, '🚀') !== false || strpos($line, '❌') !== false || strpos($line, '✅') !== false || strpos($line, 'tramitacao') !== false) {
            echo "<strong style='color: blue;'>" . htmlspecialchars($line) . "</strong>";
        } else {
            echo htmlspecialchars($line);
        }
    }
    echo "</pre>";
} else {
    echo "<p style='color: red;'>❌ Arquivo de log não encontrado em: $error_log_path</p>";
}

// Testar conexão com banco
echo "<h2>🗄️ Teste de Conexão com Banco:</h2>";
try {
    require_once 'config.php';
    $pdo = conectarDB();
    echo "<p style='color: green;'>✅ Conexão com banco funcionando!</p>";
    
    // Verificar se a tabela existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'tramitacoes_kanban'");
    if ($stmt->rowCount() > 0) {
        echo "<p style='color: green;'>✅ Tabela tramitacoes_kanban existe!</p>";
        
        // Contar registros
        $count = $pdo->query("SELECT COUNT(*) FROM tramitacoes_kanban")->fetchColumn();
        echo "<p>📊 Total de tramitações: <strong>$count</strong></p>";
        
        // Mostrar últimos registros
        if ($count > 0) {
            echo "<h3>📝 Últimas tramitações:</h3>";
            $stmt = $pdo->query("SELECT id, titulo, status, criado_em FROM tramitacoes_kanban ORDER BY criado_em DESC LIMIT 5");
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>ID</th><th>Título</th><th>Status</th><th>Criado em</th></tr>";
            while ($row = $stmt->fetch()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . htmlspecialchars($row['titulo']) . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['criado_em'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p style='color: red;'>❌ Tabela tramitacoes_kanban NÃO existe!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro de conexão: " . $e->getMessage() . "</p>";
}

// Testar se o process.php pode ser acessado
echo "<h2>🔗 Teste de Acesso ao Process.php:</h2>";
echo "<form method='POST' action='process.php' style='background: #f0f0f0; padding: 15px; border: 1px solid #ccc;'>";
echo "<input type='hidden' name='action' value='teste_debug'>";
echo "<button type='submit'>🧪 Testar Process.php</button>";
echo "</form>";

// Registrar teste no log
error_log("🧪 DEBUG SCRIPT EXECUTADO - " . date('Y-m-d H:i:s'));
?>

<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h1, h2, h3 { color: #333; }
    pre { font-size: 12px; }
</style>