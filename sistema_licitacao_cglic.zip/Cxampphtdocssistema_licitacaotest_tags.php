TESTE TAGS: <?php echo json_encode('[]'); ?>
