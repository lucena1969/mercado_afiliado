<?php
// Debug específico do case sem includes problemáticos
session_start();
$_SESSION['usuario_id'] = 1;
$_SESSION['usuario_nivel'] = 1;

// Simular dados POST
$_POST['acao'] = 'relatorio_execucao_pca';
$_POST['ano'] = '2025';

// Headers
header('Content-Type: application/json');

echo json_encode([
    'debug' => 'funcionou',
    'session_id' => $_SESSION['usuario_id'] ?? 'null',
    'post_ano' => $_POST['ano'] ?? 'null'
]);
?>