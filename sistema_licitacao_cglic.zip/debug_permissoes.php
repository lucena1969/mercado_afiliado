<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

echo "<h1>Debug de Permissões</h1>";

// Verificar sessão
echo "<h2>Informações da Sessão:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Verificar nível do usuário
$nivel = $_SESSION['usuario_nivel'] ?? 'Não definido';
echo "<h2>Nível do Usuário: $nivel</h2>";

// Verificar permissão específica
$temPermissao = temPermissao('licitacao_relatorios');
echo "<h2>Tem permissão 'licitacao_relatorios': " . ($temPermissao ? "SIM" : "NÃO") . "</h2>";

// Verificar todas as permissões para este nível
echo "<h2>Todas as permissões para nível $nivel:</h2>";
$permissoes = [
    1 => ['*'], // Coordenador - acesso total
    2 => [ // DIPLAN
        'pca_importar', 'pca_visualizar', 'pca_relatorios', 'pca_exportar', 'pca_editar',
        'licitacao_visualizar', 'licitacao_exportar', 'licitacao_relatorios',
        'risco_visualizar', 'risco_exportar'
    ],
    3 => [ // DIPLI
        'licitacao_criar', 'licitacao_editar', 'licitacao_excluir', 'licitacao_visualizar', 'licitacao_exportar', 'licitacao_relatorios',
        'pca_visualizar', 'pca_exportar', 'pca_relatorios',
        'risco_visualizar', 'risco_criar', 'risco_editar'
    ],
    4 => [ // Visitante
        'pca_visualizar', 'pca_exportar', 'pca_relatorios',
        'licitacao_visualizar', 'licitacao_exportar', 'licitacao_relatorios',
        'risco_visualizar', 'risco_exportar', 'risco_relatorios'
    ]
];

if (isset($permissoes[$nivel])) {
    echo "<ul>";
    foreach ($permissoes[$nivel] as $perm) {
        echo "<li>$perm</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Nível não encontrado no array de permissões</p>";
}

// Testar outras permissões relacionadas
echo "<h2>Teste de outras permissões:</h2>";
$testPermissions = ['licitacao_visualizar', 'licitacao_criar', 'licitacao_editar', 'pca_visualizar'];
foreach ($testPermissions as $perm) {
    $result = temPermissao($perm);
    echo "<p>$perm: " . ($result ? "SIM" : "NÃO") . "</p>";
}

// Verificar se está logado
echo "<h2>Status do Login:</h2>";
if (isset($_SESSION['usuario_logado']) && $_SESSION['usuario_logado']) {
    echo "<p>✅ Usuário está logado</p>";
    echo "<p>ID: " . ($_SESSION['usuario_id'] ?? 'Não definido') . "</p>";
    echo "<p>Nome: " . ($_SESSION['usuario_nome'] ?? 'Não definido') . "</p>";
    echo "<p>Email: " . ($_SESSION['usuario_email'] ?? 'Não definido') . "</p>";
} else {
    echo "<p>❌ Usuário NÃO está logado</p>";
}
?>