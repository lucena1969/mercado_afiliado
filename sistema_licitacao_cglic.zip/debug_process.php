<?php
// Debug específico do process.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_start();

echo "=== DEBUG PROCESS.PHP ===\n";

// Simular ambiente
$_SERVER['REQUEST_METHOD'] = 'POST';
session_start();
$_SESSION['usuario_id'] = 1;
$_SESSION['usuario_nivel'] = 1;

// Simular POST
$_POST = [
    'acao' => 'relatorio_execucao_pca',
    'ano' => '2025',
    'data_inicio' => '',
    'data_fim' => '',
    'area_requisitante_filtro' => '',
    'categoria_filtro' => '',
    'status_execucao_filtro' => '',
    'status_contratacao_filtro' => '',
    'situacao_original_filtro' => '',
    'tem_licitacao_filtro' => '',
    'valor_minimo' => '',
    'valor_maximo' => ''
];

echo "POST simulado: " . print_r($_POST, true) . "\n";

// Incluir dependências
require_once 'config.php';
require_once 'functions.php';

echo "Dependências carregadas\n";

// Testar verificarLogin
$login_ok = verificarLogin();
echo "verificarLogin() retornou: " . ($login_ok ? 'true' : 'false') . "\n";

echo "\n=== EXECUTANDO CASE ===\n";

// Incluir process.php e capturar output
include 'process.php';

$output = ob_get_clean();
echo "Output capturado:\n";
echo "Tamanho: " . strlen($output) . " bytes\n";
echo "Conteúdo:\n$output\n";
?>
