<?php
// Script de debug para testar o endpoint isoladamente
include_once 'config.php';
include_once 'functions.php';

// Simular POST para o endpoint
$_POST['acao'] = 'relatorio_execucao_pca';
$_POST['ano'] = '2025';
$_POST['data_inicio'] = '';
$_POST['data_fim'] = '';
$_POST['area_requisitante_filtro'] = '';
$_POST['categoria_filtro'] = '';
$_POST['status_execucao_filtro'] = '';
$_POST['status_contratacao_filtro'] = '';
$_POST['situacao_original_filtro'] = '';
$_POST['tem_licitacao_filtro'] = '';
$_POST['valor_minimo'] = '';
$_POST['valor_maximo'] = '';
$_POST['pagina'] = '1';

// Simular sessão
session_start();
$_SESSION['usuario_logado'] = true;
$_SESSION['usuario_id'] = 1;

echo "=== TESTE DEBUG RELATÓRIO ===\n";
echo "Iniciando teste...\n";

// Capturar toda a saída
ob_start();

try {
    include 'process.php';
} catch (Exception $e) {
    echo "ERRO CAPTURADO: " . $e->getMessage() . "\n";
}

$output = ob_get_contents();
ob_end_clean();

echo "=== SAÍDA CAPTURADA ===\n";
echo "Tamanho: " . strlen($output) . " bytes\n";
echo "Conteúdo:\n";
echo $output;
echo "\n=== FIM SAÍDA ===\n";

// Tentar validar JSON
if (!empty($output)) {
    $json_decode = json_decode($output, true);
    if ($json_decode === null) {
        echo "ERRO JSON: " . json_last_error_msg() . "\n";
        echo "Últimos 100 caracteres: " . substr($output, -100) . "\n";
        echo "Primeiros 100 caracteres: " . substr($output, 0, 100) . "\n";
    } else {
        echo "JSON VÁLIDO!\n";
        echo "Estrutura:\n";
        print_r(array_keys($json_decode));
    }
}
?>