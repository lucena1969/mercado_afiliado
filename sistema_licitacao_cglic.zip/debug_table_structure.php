<?php
require_once 'config.php';

try {
    $pdo = conectarDB();
    $result = $pdo->query('DESCRIBE tramitacoes_kanban');
    
    echo "<h1>📋 Estrutura da tabela tramitacoes_kanban:</h1>";
    echo "<table border='1' style='border-collapse: collapse;'>";
    echo "<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    
    while ($row = $result->fetch()) {
        echo "<tr>";
        echo "<td><strong>" . $row['Field'] . "</strong></td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?: 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Verificar colunas específicas que precisamos
    $colunas_necessarias = ['situacao_prazo', 'dias_restantes', 'cor_card', 'tags'];
    echo "<h2>🔍 Verificação de colunas necessárias:</h2>";
    
    foreach ($colunas_necessarias as $coluna) {
        $check = $pdo->query("SHOW COLUMNS FROM tramitacoes_kanban LIKE '$coluna'");
        if ($check->rowCount() > 0) {
            echo "<p style='color: green;'>✅ $coluna - EXISTE</p>";
        } else {
            echo "<p style='color: red;'>❌ $coluna - NÃO EXISTE</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Erro: " . $e->getMessage() . "</p>";
}
?>

<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    table { margin: 20px 0; }
    th, td { padding: 8px 12px; text-align: left; }
    th { background: #f0f0f0; }
</style>