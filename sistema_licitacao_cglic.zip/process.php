<?php
// process.php
require_once 'config.php';
require_once 'functions.php';

// Configurar e iniciar sessão
configurarSessaoSegura();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$acao = $_POST['acao'] ?? $_POST['action'] ?? '';

$pdo = conectarDB();

switch ($acao) {
    case 'login':
        $email = limpar($_POST['email']);
        $senha = $_POST['senha'];

        // Verificar se login está bloqueado
        if (isLoginBloqueado()) {
            setMensagem('Muitas tentativas de login. Tente novamente em alguns minutos.', 'erro');
            header('Location: index.php');
            exit;
        }

        try {
            $sql = "SELECT id, nome, email, senha, tipo_usuario, nivel_acesso, departamento FROM usuarios WHERE email = ? AND ativo = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$email]);
            $usuario = $stmt->fetch();

            if ($usuario && password_verify($senha, $usuario['senha'])) {
                // Login bem-sucedido - usar nova função
                atualizarSessaoUsuario($usuario['id']);

                // Registrar login bem-sucedido
                registrarTentativaLogin($email, true, 'Login realizado com sucesso');
                registrarLog('login', 'Login realizado com sucesso', 'usuarios', null);

                header('Location: selecao_modulos.php');
            } else {
                // Login falhado
                if ($usuario) {
                    registrarTentativaLogin($email, false, 'Senha incorreta');
                } else {
                    registrarTentativaLogin($email, false, 'Usuário não encontrado');
                }

                setMensagem('E-mail ou senha incorretos!', 'erro');
                header('Location: index.php');
            }
        } catch (Exception $e) {
            registrarLog('LOGIN_ERROR', 'Erro no processo de login: ' . $e->getMessage(), null, null);
            setMensagem('Erro interno no sistema. Tente novamente.', 'erro');
            header('Location: index.php');
        }
        break;

    case 'cadastro':
        $nome = limpar($_POST['nome']);
        $email = limpar($_POST['email']);
        $senha = $_POST['senha'];
        $confirmar_senha = $_POST['confirmar_senha'];

        // Validações
        if (strlen($nome) < 3) {
            setMensagem('Nome deve ter pelo menos 3 caracteres!', 'erro');
            header('Location: index.php');
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            setMensagem('E-mail inválido!', 'erro');
            header('Location: index.php');
            exit;
        }

        if (strlen($senha) < 6) {
            setMensagem('Senha deve ter pelo menos 6 caracteres!', 'erro');
            header('Location: index.php');
            exit;
        }

        if ($senha !== $confirmar_senha) {
            setMensagem('As senhas não coincidem!', 'erro');
            header('Location: index.php');
            exit;
        }

        // Verificar se e-mail já existe
        $sql = "SELECT id FROM usuarios WHERE email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            setMensagem('E-mail já cadastrado!', 'erro');
            header('Location: index.php');
            exit;
        }

        // Inserir usuário com nível padrão VISITANTE (4)
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nome, email, senha, tipo_usuario, nivel_acesso, departamento) VALUES (?, ?, ?, 'visitante', 4, 'CGLIC')";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute([$nome, $email, $senha_hash])) {
            setMensagem('Cadastro realizado com sucesso! Faça login.');
            header('Location: index.php');
        } else {
            setMensagem('Erro ao cadastrar. Tente novamente!', 'erro');
            header('Location: index.php');
        }
        break;

    case 'importar_pca':
        verificarLogin();
        
        // Aumentar limites para importação
        ini_set('memory_limit', '512M');
        ini_set('max_execution_time', 300); // 5 minutos
        ini_set('max_input_time', 300);
        
        // Verificar permissão para importar PCA
        if (!temPermissao('pca_importar')) {
            setMensagem('Você não tem permissão para importar dados do PCA.', 'erro');
            header('Location: dashboard.php');
            exit;
        }

        if (!isset($_FILES['arquivo_pca'])) {
            setMensagem('Nenhum arquivo selecionado!', 'erro');
            header('Location: dashboard.php');
            exit;
        }

        // Obter ano do PCA (novo parâmetro)
        $ano_pca = intval($_POST['ano_pca'] ?? 2025);
        $eh_historico = ($ano_pca <= 2024);

        $resultado = processarUpload($_FILES['arquivo_pca']);

        if (!$resultado['sucesso']) {
            setMensagem($resultado['mensagem'], 'erro');
            header('Location: dashboard.php');
            exit;
        }

        // Processar o arquivo CSV
        $arquivo = $resultado['caminho'];

        try {
            // Detectar e corrigir encoding antes de abrir
            $conteudo_original = file_get_contents($arquivo);
            if ($conteudo_original === false) {
                throw new Exception('Não foi possível ler o arquivo enviado');
            }
            
            $encoding = mb_detect_encoding($conteudo_original, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'CP1252'], true);

            if ($encoding !== 'UTF-8') {
                $conteudo_utf8 = mb_convert_encoding($conteudo_original, 'UTF-8', $encoding);
                if (file_put_contents($arquivo, $conteudo_utf8) === false) {
                    throw new Exception('Erro ao converter encoding do arquivo');
                }
            }

            $handle = fopen($arquivo, 'r');
            if (!$handle) {
                throw new Exception('Erro ao abrir arquivo para leitura');
            }
        } catch (Exception $e) {
            error_log("Erro no processamento do arquivo CSV: " . $e->getMessage());
            setMensagem('Erro ao processar arquivo: ' . $e->getMessage(), 'erro');
            header('Location: dashboard.php');
            exit;
        }

        // Verificar e corrigir AUTO_INCREMENT antes da importação
        $auto_increment_corrigido = verificarECorrigirAutoIncrement('pca_importacoes');
        error_log("AUTO_INCREMENT verificado/corrigido: " . ($auto_increment_corrigido ? $auto_increment_corrigido : 'falhou'));
        
        // Criar registro de importação
        try {
            $sql = "INSERT INTO pca_importacoes (nome_arquivo, usuario_id, ano_pca) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            
            // Log dos dados que serão inseridos
            error_log("Inserindo importação - Arquivo: " . $resultado['arquivo'] . ", Usuário: " . $_SESSION['usuario_id'] . ", Ano: " . $ano_pca);
            
            $stmt->execute([$resultado['arquivo'], $_SESSION['usuario_id'], $ano_pca]);
            $importacao_id = $pdo->lastInsertId();
            
            // Log do resultado
            error_log("Resultado do INSERT - lastInsertId(): " . $importacao_id . ", rowCount(): " . $stmt->rowCount());
            
            // Verificar se o ID é válido
            if ($importacao_id <= 0) {
                error_log("LastInsertId retornou valor inválido: $importacao_id");
                
                // Tentar recuperar o ID manualmente
                $sql_recuperar = "SELECT id FROM pca_importacoes WHERE nome_arquivo = ? AND usuario_id = ? AND ano_pca = ? ORDER BY criado_em DESC LIMIT 1";
                $stmt_recuperar = $pdo->prepare($sql_recuperar);
                $stmt_recuperar->execute([$resultado['arquivo'], $_SESSION['usuario_id'], $ano_pca]);
                $registro_recuperado = $stmt_recuperar->fetch();
                
                if ($registro_recuperado) {
                    $importacao_id = $registro_recuperado['id'];
                    error_log("ID recuperado manualmente: $importacao_id");
                } else {
                    throw new Exception('Erro ao obter ID da importação - não foi possível recuperar');
                }
            }
            
            error_log("Registro de importação criado com ID: $importacao_id");
            
        } catch (PDOException $e) {
            error_log("Erro PDO na criação de importação: " . $e->getMessage());
            error_log("Código do erro: " . $e->getCode());
            
            // Se for erro de chave duplicada, tentar corrigir uma vez mais
            if ($e->getCode() == '23000' && strpos($e->getMessage(), 'Duplicate entry') !== false) {
                error_log("Erro de chave duplicada detectado. Tentando corrigir novamente...");
                
                try {
                    // Forçar correção mais agressiva
                    verificarECorrigirAutoIncrement('pca_importacoes');
                    // Tentar inserir novamente
                    $stmt->execute([$resultado['arquivo'], $_SESSION['usuario_id'], $ano_pca]);
                    $importacao_id = $pdo->lastInsertId();
                    
                    if ($importacao_id <= 0) {
                        throw new Exception('ID inválido após correção');
                    }
                    
                } catch (Exception $e2) {
                    error_log("Falha definitiva ao corrigir AUTO_INCREMENT: " . $e2->getMessage());
                    error_log("Stack trace da falha: " . $e2->getTraceAsString());
                    
                    // Verificar se o problema é mesmo de AUTO_INCREMENT
                    try {
                        $check_sql = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pca_importacoes'";
                        $check_result = $pdo->query($check_sql)->fetch();
                        error_log("AUTO_INCREMENT atual após falha: " . ($check_result ? $check_result['AUTO_INCREMENT'] : 'NULL'));
                        
                        $max_sql = "SELECT MAX(id) as max_id, COUNT(*) as total FROM pca_importacoes";
                        $max_result = $pdo->query($max_sql)->fetch();
                        error_log("Estado da tabela - MAX(id): " . $max_result['max_id'] . ", Total registros: " . $max_result['total']);
                    } catch (Exception $e3) {
                        error_log("Erro ao verificar estado da tabela: " . $e3->getMessage());
                    }
                    
                    setMensagem('Erro crítico no banco de dados: ' . $e2->getMessage() . ' (verifique logs)', 'erro');
                    header('Location: dashboard.php');
                    exit;
                }
            } else {
                setMensagem('Erro ao registrar importação: ' . $e->getMessage(), 'erro');
                header('Location: dashboard.php');
                exit;
            }
        }

        // Detectar separador automaticamente
        $primeira_linha = fgets($handle);
        rewind($handle);
        $separador = ';';
        if (substr_count($primeira_linha, ',') > substr_count($primeira_linha, ';')) {
            $separador = ',';
        }

        // Ler cabeçalho
        $header = fgetcsv($handle, 0, $separador);

        // Sistema unificado: permite importação para qualquer ano usando pca_dados
        // Anos históricos (< 2025) podem ser importados mas ficam em modo somente leitura após importação

        // Processar linhas usando nova função simplificada
        $linhas_processadas = 0;
        $linhas_novas = 0;
        $linhas_atualizadas = 0;
        $linhas_ignoradas = 0;
        $dados_para_importar = [];
        $erros = [];

        while (($linha = fgetcsv($handle, 0, $separador)) !== FALSE) {
            // Limpar encoding de cada campo individualmente
            $linha = array_map(function($campo) {
                if (!is_string($campo)) return $campo;
                // Remove BOM se presente
                $campo = str_replace("\xEF\xBB\xBF", '', $campo);
                // Garante UTF-8 válido
                return mb_convert_encoding($campo, 'UTF-8', 'UTF-8');
            }, $linha);
            // Pular linhas vazias
            if (empty($linha[0])) continue;

            $linhas_processadas++;

            try {
                // Mapear dados das colunas - CORRIGIDO MAPEAMENTO
                $dados_linha = [
                    'numero_contratacao' => trim($linha[0] ?? ''),
                    'status_contratacao' => trim($linha[1] ?? ''),
                    'situacao_execucao' => trim($linha[2] ?? '') ?: 'Não iniciado',
                    'titulo_contratacao' => trim($linha[3] ?? ''),
                    'categoria_contratacao' => trim($linha[4] ?? ''),
                    'uasg_atual' => trim($linha[5] ?? ''),
                    'valor_total_contratacao' => null,  // Será calculado com base no valor_total dos itens
                    'data_inicio_processo' => formatarDataDB($linha[6] ?? ''),   // Data início processo
                    'data_conclusao_processo' => formatarDataDB($linha[7] ?? ''), // Data conclusão processo
                    'prazo_duracao_dias' => !empty($linha[8]) ? intval($linha[8]) : null,  // Prazo duração
                    'area_requisitante' => trim($linha[9] ?? ''),    // ✅ CORRIGIDO - Área requisitante
                    'numero_dfd' => trim($linha[10] ?? ''),          // Nº DFD
                    'prioridade' => trim($linha[11] ?? ''),          // Prioridade
                    'numero_item_dfd' => trim($linha[12] ?? ''),     // Nº Item DFD
                    'data_conclusao_dfd' => formatarDataDB($linha[13] ?? ''),  // Data conclusão DFD
                    'classificacao_contratacao' => trim($linha[14] ?? ''),    // Classificação
                    'codigo_classe_grupo' => trim($linha[15] ?? ''),          // Código classe/grupo
                    'nome_classe_grupo' => trim($linha[16] ?? ''),            // Nome classe/grupo
                    'codigo_pdm_material' => trim($linha[17] ?? ''),          // Código PDM
                    'nome_pdm_material' => trim($linha[18] ?? ''),            // Nome PDM
                    'codigo_material_servico' => trim($linha[19] ?? ''),      // Código material
                    'descricao_material_servico' => trim($linha[20] ?? ''),   // Descrição material
                    'unidade_fornecimento' => trim($linha[21] ?? ''),         // Unidade fornecimento
                    'valor_unitario' => processarValorMonetario($linha[22] ?? ''),  // Valor unitário
                    'quantidade' => !empty($linha[23]) ? intval($linha[23]) : null,  // Quantidade
                    'valor_total' => processarValorMonetario($linha[24] ?? '')       // Valor total
                ];

                $dados_para_importar[] = $dados_linha;
                $linhas_novas++;

            } catch (Exception $e) {
                $erros[] = "Linha $linhas_processadas: " . $e->getMessage();
                continue;
            }
        }

        // Usar nova função UPSERT para importar dados
        try {
            if (empty($dados_para_importar)) {
                throw new Exception('Nenhum dado válido encontrado para importação');
            }

            error_log("Iniciando UPSERT de " . count($dados_para_importar) . " registros");
            $resultado_upsert = importarPcaComUpsert($ano_pca, $dados_para_importar, $importacao_id);
            $linhas_novas = $resultado_upsert['inseridos'];
            $linhas_atualizadas = $resultado_upsert['atualizados'];
            $total_processados = $resultado_upsert['total_processados'];
            error_log("UPSERT concluído: {$resultado_upsert['inseridos']} inseridos, {$resultado_upsert['atualizados']} atualizados, {$resultado_upsert['erros']} erros");
        } catch (Exception $e) {
            error_log("ERRO CRÍTICO NA IMPORTAÇÃO: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            $erros[] = "Erro na importação: " . $e->getMessage();
            
            // Atualizar status da importação como erro
            $sql_erro = "UPDATE pca_importacoes SET status = 'erro', observacoes = ? WHERE id = ?";
            $stmt_erro = $pdo->prepare($sql_erro);
            $stmt_erro->execute(["Erro: " . $e->getMessage(), $importacao_id]);
        }

        fclose($handle);

        // Atualizar registro de importação com os dados finais
        $status_final = !empty($erros) ? 'erro' : 'concluido';
        $observacoes_final = !empty($erros) ?
            'UPSERT com ' . count($erros) . ' erro(s). Inseridos: ' . $linhas_novas . ', Atualizados: ' . $linhas_atualizadas :
            'UPSERT concluído com sucesso. Inseridos: ' . $linhas_novas . ', Atualizados: ' . $linhas_atualizadas;

        $sql_update = "UPDATE pca_importacoes SET
                       status = ?,
                       total_registros = ?,
                       registros_novos = ?,
                       registros_atualizados = ?,
                       observacoes = ?
                       WHERE id = ?";
        $stmt_update = $pdo->prepare($sql_update);
        $stmt_update->execute([
            $status_final,
            $linhas_processadas,
            $linhas_novas,
            $linhas_atualizadas ?? 0,
            $observacoes_final,
            $importacao_id
        ]);

        // Mensagem detalhada
        $tipo_importacao = $eh_historico ? "histórica ($ano_pca)" : "atual ($ano_pca)";
        $mensagem = "✅ UPSERT PCA $tipo_importacao concluído! ";
        $mensagem .= "📄 Processadas: $linhas_processadas | ";
        $mensagem .= "🆕 Inseridas: $linhas_novas | ";
        $mensagem .= "🔄 Atualizadas: " . ($linhas_atualizadas ?? 0) . " | ";
        $mensagem .= "⚠️ Erros: " . count($erros);

        if (!empty($erros)) {
            $mensagem .= " | Erros: " . count($erros);
            // Log dos erros
            foreach (array_slice($erros, 0, 5) as $erro) {
                error_log("Importação PCA - $erro");
            }
        }

        registrarLog('IMPORTACAO_PCA', $mensagem, 'pca_importacoes', $importacao_id);
        setMensagem($mensagem);

        header('Location: dashboard.php');
        break;

    case 'reverter_importacao_pca':
        verificarLogin();
        
        // Verificar permissão para reverter importação (operação crítica)
        if (!temPermissao('pca_importar') || $_SESSION['usuario_nivel'] > 2) {
            setMensagem('Você não tem permissão para reverter importações.', 'erro');
            header('Location: dashboard.php?secao=importar-pca');
            exit;
        }
        verifyCSRFToken();
        
        $importacao_id = intval($_POST['importacao_id'] ?? 0);
        
        if ($importacao_id <= 0) {
            setMensagem('ID da importação inválido!', 'erro');
            header('Location: dashboard.php?secao=importar-pca');
            exit;
        }
        
        $resultado = reverterImportacaoPCA($importacao_id, $_SESSION['usuario_id']);
        
        if ($resultado['sucesso']) {
            setMensagem($resultado['mensagem'], 'sucesso');
        } else {
            setMensagem($resultado['mensagem'], 'erro');
        }
        
        header('Location: dashboard.php?secao=importar-pca');
        break;

case 'criar_licitacao':
    verificarLogin();
    
    // Verificar permissão para criar licitação
    if (!temPermissao('licitacao_criar')) {
        setMensagem('Você não tem permissão para criar licitações.', 'erro');
        header('Location: licitacao_dashboard.php');
        exit;
    }

    try {
        // DEBUG: Log todos os dados recebidos
        error_log("=== DEBUG CRIAR LICITAÇÃO ===");
        error_log("POST data: " . print_r($_POST, true));
        error_log("numero_contratacao recebido: '" . ($_POST['numero_contratacao'] ?? 'NÃO ENVIADO') . "'");
        error_log("Trimmed: '" . (isset($_POST['numero_contratacao']) ? trim($_POST['numero_contratacao']) : 'N/A') . "'");
        
        // Verificar CSRF (usando a função que já existe)
        verifyCSRFToken();

        // Validar campos obrigatórios
        $campos_obrigatorios = ['nup', 'modalidade', 'tipo', 'situacao', 'objeto', 'numero_contratacao']; // Adicionado numero_contratacao
        foreach ($campos_obrigatorios as $campo) {
            if (empty($_POST[$campo])) {
                throw new Exception("O campo '{$campo}' é obrigatório.");
            }
        }

        // Preparar dados para inserção
        $numero_contratacao_raw = $_POST['numero_contratacao'] ?? '';
        $numero_contratacao_trimmed = trim($numero_contratacao_raw);
        
        // DEBUG: Log detalhado do numero_contratacao
        error_log("Raw numero_contratacao: '" . $numero_contratacao_raw . "' (length: " . strlen($numero_contratacao_raw) . ")");
        error_log("Trimmed numero_contratacao: '" . $numero_contratacao_trimmed . "' (length: " . strlen($numero_contratacao_trimmed) . ")");
        error_log("Empty check: " . (empty($numero_contratacao_trimmed) ? 'TRUE' : 'FALSE'));
        
        $dados = [
            'nup' => trim($_POST['nup']),
            'data_entrada_dipli' => !empty($_POST['data_entrada_dipli']) ? $_POST['data_entrada_dipli'] : null,
            'resp_instrucao' => !empty($_POST['resp_instrucao']) ? trim($_POST['resp_instrucao']) : null,
            'area_demandante' => !empty($_POST['area_demandante']) ? trim($_POST['area_demandante']) : null,
            'pregoeiro' => !empty($_POST['pregoeiro']) ? trim($_POST['pregoeiro']) : null,
            'modalidade' => $_POST['modalidade'],
            'tipo' => $_POST['tipo'],
            'ano' => !empty($_POST['ano']) ? intval($_POST['ano']) : null,
            'valor_estimado' => !empty($_POST['valor_estimado']) ? floatval($_POST['valor_estimado']) : null,
            'qtd_itens' => !empty($_POST['qtd_itens']) ? intval($_POST['qtd_itens']) : null,
            'data_abertura' => !empty($_POST['data_abertura']) ? $_POST['data_abertura'] : null,
            'data_homologacao' => !empty($_POST['data_homologacao']) ? $_POST['data_homologacao'] : null,
            'valor_homologado' => !empty($_POST['valor_homologado']) ? floatval($_POST['valor_homologado']) : null,
            'qtd_homol' => !empty($_POST['qtd_homol']) ? intval($_POST['qtd_homol']) : null,
            'economia' => !empty($_POST['economia']) ? floatval($_POST['economia']) : null,
            'link' => !empty($_POST['link']) ? trim($_POST['link']) : null,
            'situacao' => $_POST['situacao'],
            'objeto' => trim($_POST['objeto']),
            'usuario_id' => $_SESSION['usuario_id'],
            'numero_contratacao' => !empty($numero_contratacao_trimmed) ? $numero_contratacao_trimmed : null,
        ];
        
        // DEBUG: Log dados finais
        error_log("Dados finais para inserção:");
        error_log("numero_contratacao final: '" . ($dados['numero_contratacao'] ?? 'NULL') . "'");

        // Validar formato do NUP
        if (!preg_match('/^\d{5}\.\d{6}\/\d{4}-\d{2}$/', $dados['nup'])) {
            throw new Exception("Formato do NUP inválido. Use: xxxxx.xxxxxx/xxxx-xx");
        }

        // Verificar se NUP já existe
        $stmt = $pdo->prepare("SELECT id FROM licitacoes WHERE nup = ?");
        $stmt->execute([$dados['nup']]);
        if ($stmt->fetch()) {
            throw new Exception("Já existe uma licitação com este NUP.");
        }

        // Remover a lógica de pca_dados_id se não for mais necessária para manter FKs,
        // pois estamos salvando os dados relevantes do PCA diretamente na licitação.
        // Se ainda precisar de um FK para outras lógicas, descomente e ajuste.
        /*
        if (!empty($_POST['numero_contratacao'])) {
            $stmt = $pdo->prepare("SELECT id FROM pca_dados WHERE numero_contratacao = ?");
            $stmt->execute([$_POST['numero_contratacao']]);
            $pca_dados = $stmt->fetch();
            if ($pca_dados) {
                $dados['pca_dados_id'] = $pca_dados['id'];
            } else {
                $dados['pca_dados_id'] = null; // Ou trate como erro se for obrigatório
            }
        } else {
            $dados['pca_dados_id'] = null;
        }
        */

        // Calcular economia automaticamente se ambos os valores estiverem preenchidos
        if ($dados['valor_estimado'] && $dados['valor_homologado']) {
            $dados['economia'] = $dados['valor_estimado'] - $dados['valor_homologado'];
        }

        // Preparar SQL de inserção
        $campos = array_keys($dados);
        $placeholders = ':' . implode(', :', $campos);
        $sql = "INSERT INTO licitacoes (" . implode(', ', $campos) . ") VALUES (" . $placeholders . ")";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($dados);

        // Log da ação (usando a assinatura correta da função)
        $licitacao_id = $pdo->lastInsertId();
        registrarLog('CRIAR_LICITACAO', "Criou licitação: {$dados['nup']}", 'licitacoes', $licitacao_id);

        // Verificar se é uma requisição AJAX
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
        $expectsJson = strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

        if ($isAjax || $expectsJson) {
            // Resposta JSON para requisições AJAX
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Licitação criada com sucesso!',
                'licitacao_id' => $licitacao_id
            ]);
            exit;
        } else {
            // Resposta tradicional para requisições normais
            setMensagem("Licitação criada com sucesso!");
            header('Location: licitacao_dashboard.php');
            exit;
        }

    } catch (Exception $e) {
        // Log do erro com mais detalhes
        error_log("Erro ao criar licitação: " . $e->getMessage());
        error_log("Stack trace: " . $e->getTraceAsString());

        // Verificar se é uma requisição AJAX
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
        $expectsJson = strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

        if ($isAjax || $expectsJson) {
            // Resposta JSON para requisições AJAX
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao criar licitação: ' . $e->getMessage()
            ]);
            exit;
        } else {
            // Resposta tradicional para requisições normais
            setMensagem('Erro ao criar licitação: ' . $e->getMessage(), 'erro');
            header('Location: licitacao_dashboard.php');
            exit;
        }
    } catch (Error $e) {
        // Capturar erros fatais também
        error_log("Erro fatal ao criar licitação: " . $e->getMessage());
        error_log("Stack trace: " . $e->getTraceAsString());

        // Verificar se é uma requisição AJAX
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
        $expectsJson = strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;

        if ($isAjax || $expectsJson) {
            // Resposta JSON para requisições AJAX
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Erro fatal ao processar requisição'
            ]);
            exit;
        } else {
            // Resposta tradicional para requisições normais
            setMensagem('Erro fatal ao processar requisição', 'erro');
            header('Location: licitacao_dashboard.php');
            exit;
        }
    }

case 'editar_licitacao':
        verificarLogin();
        
        // Verificar permissão para editar licitação
        if (!temPermissao('licitacao_editar')) {
            echo json_encode([
                'success' => false,
                'message' => 'Você não tem permissão para editar licitações.'
            ]);
            exit;
        }

        header('Content-Type: application/json');

        $response = ['success' => false, 'message' => ''];

        try {

            $pdo = conectarDB();
 
            // Validar ID

            if (empty($_POST['id'])) {

                throw new Exception('ID da licitação não fornecido');

            }

            // Validar NUP

            if (!validarNUP($_POST['nup'])) {

                throw new Exception('Formato do NUP inválido! Use: xxxxx.xxxxxx/xxxx-xx');

            }
 
            // CORREÇÃO: Lógica para buscar o pca_dados_id a partir do numero_contratacao

            $pca_dados_id = null;

            if (!empty($_POST['numero_contratacao'])) {

                $stmt_pca = $pdo->prepare("SELECT id FROM pca_dados WHERE numero_contratacao = ? LIMIT 1");

                $stmt_pca->execute([trim($_POST['numero_contratacao'])]);

                $pca_achado = $stmt_pca->fetch();

                if ($pca_achado) {

                    $pca_dados_id = $pca_achado['id'];

                }

            }

            // Processar dados

            $id = intval($_POST['id']);

            $nup = limpar($_POST['nup']);

            $data_entrada_dipli = formatarDataDB($_POST['data_entrada_dipli']);

            $resp_instrucao = limpar($_POST['resp_instrucao']);

            $area_demandante = limpar($_POST['area_demandante']);

            $pregoeiro = limpar($_POST['pregoeiro']);

            $modalidade = $_POST['modalidade'];

            $tipo = $_POST['tipo'];

            $numero = !empty($_POST['numero']) ? intval($_POST['numero']) : null;

            $ano = !empty($_POST['ano']) ? intval($_POST['ano']) : null;

            $valor_estimado = !empty($_POST['valor_estimado']) ? formatarValorDB($_POST['valor_estimado']) : null;

            $data_abertura = formatarDataDB($_POST['data_abertura']);

            $situacao = $_POST['situacao'];

            $objeto = limpar($_POST['objeto']);

            // Campos de homologação

            $data_homologacao = null;

            $qtd_homol = null;

            $valor_homologado = null;

            $economia = null;

            if ($situacao === 'HOMOLOGADO') {

                $data_homologacao = formatarDataDB($_POST['data_homologacao']);

                $qtd_homol = !empty($_POST['qtd_homol']) ? intval($_POST['qtd_homol']) : null;

                $valor_homologado = !empty($_POST['valor_homologado']) ? formatarValorDB($_POST['valor_homologado']) : null;

                $economia = !empty($_POST['economia']) ? formatarValorDB($_POST['economia']) : null;

            }

            // CORREÇÃO: Adicionado numero_contratacao ao UPDATE
            $numero_contratacao = !empty($_POST['numero_contratacao']) ? trim($_POST['numero_contratacao']) : null;

            $sql = "UPDATE licitacoes SET 
                    nup = ?, data_entrada_dipli = ?, resp_instrucao = ?, area_demandante = ?,
                    pregoeiro = ?, modalidade = ?, tipo = ?, numero = ?, ano = ?,
                    valor_estimado = ?, data_abertura = ?, situacao = ?, objeto = ?,
                    data_homologacao = ?, qtd_homol = ?, valor_homologado = ?, economia = ?,
                    numero_contratacao = ?, pca_dados_id = ?
                    WHERE id = ?";

            $stmt = $pdo->prepare($sql);

            $stmt->execute([
                $nup, $data_entrada_dipli, $resp_instrucao, $area_demandante,
                $pregoeiro, $modalidade, $tipo, $numero, $ano,
                $valor_estimado, $data_abertura, $situacao, $objeto,
                $data_homologacao, $qtd_homol, $valor_homologado, $economia,
                $numero_contratacao, $pca_dados_id, // CORREÇÃO: Salvando numero_contratacao
                $id
            ]);

            registrarLog('EDITAR_LICITACAO', "Editou licitação ID: $id - NUP: $nup", 'licitacoes', $id);

            $response['success'] = true;

            $response['message'] = 'Licitação atualizada com sucesso!';

        } catch (Exception $e) {

            $response['success'] = false;

            $response['message'] = $e->getMessage();

        }

        echo json_encode($response);

        break;

    case 'excluir_licitacao':
        verificarLogin();
        
        // Verificar permissão para excluir licitação (apenas DIPLI)
        if (!temPermissao('licitacao_excluir')) {
            echo json_encode([
                'success' => false,
                'message' => 'Você não tem permissão para excluir licitações. Apenas usuários DIPLI podem excluir.'
            ]);
            exit;
        }

        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];

        try {
            $pdo = conectarDB();

            // Validar ID
            if (empty($_POST['id'])) {
                throw new Exception('ID da licitação não fornecido');
            }

            $id = intval($_POST['id']);

            // Verificar se a licitação existe e buscar dados para log
            $sql_verificar = "SELECT id, nup, objeto FROM licitacoes WHERE id = ?";
            $stmt_verificar = $pdo->prepare($sql_verificar);
            $stmt_verificar->execute([$id]);
            $licitacao = $stmt_verificar->fetch();

            if (!$licitacao) {
                throw new Exception('Licitação não encontrada');
            }

            // Verificar se há dependências (ex: andamentos, etc.)
            // Para futuras implementações, verificar relacionamentos
            
            // Excluir a licitação
            $sql_excluir = "DELETE FROM licitacoes WHERE id = ?";
            $stmt_excluir = $pdo->prepare($sql_excluir);
            $resultado = $stmt_excluir->execute([$id]);

            if (!$resultado) {
                throw new Exception('Erro ao excluir licitação do banco de dados');
            }

            // Verificar se realmente foi excluída
            if ($stmt_excluir->rowCount() === 0) {
                throw new Exception('Nenhuma licitação foi excluída. Verifique se o ID está correto');
            }

            // Registrar no log
            registrarLog('EXCLUIR_LICITACAO', "Excluiu licitação ID: $id - NUP: {$licitacao['nup']} - Objeto: " . substr($licitacao['objeto'], 0, 50) . "...", 'licitacoes', $id);

            $response['success'] = true;
            $response['message'] = 'Licitação excluída com sucesso!';
            $response['nup'] = $licitacao['nup']; // Para feedback no frontend

        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
            
            // Log do erro
            error_log("Erro ao excluir licitação: " . $e->getMessage());
        }

        echo json_encode($response);
        break;

    case 'criar_qualificacao':
        verificarLogin();
        
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];
        
        // Log de debug inicial
        error_log("=== CRIAR QUALIFICAÇÃO - INÍCIO ===");
        error_log("POST data: " . json_encode($_POST));
        error_log("Usuário ID: " . $_SESSION['usuario_id']);
        
        try {
            // Validar dados obrigatórios
            $nup = limpar($_POST['nup'] ?? '');
            $area_demandante = limpar($_POST['area_demandante'] ?? '');
            $responsavel = limpar($_POST['responsavel'] ?? '');
            $modalidade = limpar($_POST['modalidade'] ?? '');
            $objeto = limpar($_POST['objeto'] ?? '');
            $palavras_chave = limpar($_POST['palavras_chave'] ?? '');
            $valor_estimado = limpar($_POST['valor_estimado'] ?? '');
            $status = limpar($_POST['status'] ?? '');
            $observacoes = limpar($_POST['observacoes'] ?? '');
            $pca_dados_id = !empty($_POST['pca_dados_id']) ? intval($_POST['pca_dados_id']) : null;
            
            // Log dos dados capturados
            error_log("Dados capturados:");
            error_log("- NUP: '$nup'");
            error_log("- Área: '$area_demandante'");
            error_log("- Responsável: '$responsavel'");
            error_log("- Modalidade: '$modalidade'");
            error_log("- Valor estimado: '$valor_estimado'");
            error_log("- Status: '$status'");
            
            // Validações
            if (empty($nup)) {
                throw new Exception('NUP é obrigatório');
            }
            
            if (empty($area_demandante)) {
                throw new Exception('Área demandante é obrigatória');
            }
            
            if (empty($responsavel)) {
                throw new Exception('Responsável é obrigatório');
            }
            
            if (empty($modalidade)) {
                throw new Exception('Modalidade é obrigatória');
            }
            
            if (empty($objeto)) {
                throw new Exception('Objeto é obrigatório');
            }
            
            if (empty($status)) {
                throw new Exception('Status é obrigatório');
            }
            
            // Limpar e converter valor monetário
            $valor_numerico = 0.00;
            if (!empty($valor_estimado)) {
                // Remover formatação completa (R$, espaços, etc)
                $valor_limpo = trim($valor_estimado);
                $valor_limpo = preg_replace('/[^\d,.]/', '', $valor_limpo);
                
                // Se tem vírgula e ponto, assumir formato brasileiro (1.000,00)
                if (strpos($valor_limpo, '.') !== false && strpos($valor_limpo, ',') !== false) {
                    $valor_limpo = str_replace('.', '', $valor_limpo); // Remove separador de milhares
                    $valor_limpo = str_replace(',', '.', $valor_limpo); // Vírgula vira ponto decimal
                }
                // Se tem apenas vírgula, assumir que é decimal brasileiro (100,50)
                elseif (strpos($valor_limpo, ',') !== false && strpos($valor_limpo, '.') === false) {
                    $valor_limpo = str_replace(',', '.', $valor_limpo);
                }
                // Se tem apenas ponto, pode ser decimal americano (100.50) ou separador de milhares (1.000)
                elseif (strpos($valor_limpo, '.') !== false && strpos($valor_limpo, ',') === false) {
                    // Se há mais de um ponto ou ponto não está nos últimos 3 dígitos, é separador de milhares
                    if (substr_count($valor_limpo, '.') > 1 || !preg_match('/\.\d{2}$/', $valor_limpo)) {
                        $valor_limpo = str_replace('.', '', $valor_limpo);
                    }
                }
                
                $valor_numerico = floatval($valor_limpo);
                
                // Log para debug
                error_log("Valor original: '$valor_estimado' -> Valor limpo: '$valor_limpo' -> Valor numérico: $valor_numerico");
                
                // Validar se o valor é válido
                if ($valor_numerico <= 0) {
                    throw new Exception('Valor estimado deve ser maior que zero');
                }
            }
            
            // Verificar se NUP já existe
            $sql_check = "SELECT id FROM qualificacoes WHERE nup = ?";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([$nup]);
            
            if ($stmt_check->fetch()) {
                throw new Exception('Este NUP já está cadastrado no sistema');
            }
            
            // Inserir qualificação
            $sql = "INSERT INTO qualificacoes (
                nup, 
                area_demandante, 
                responsavel, 
                modalidade, 
                objeto, 
                palavras_chave, 
                valor_estimado, 
                status, 
                observacoes, 
                usuario_id,
                pca_dados_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([
                $nup,
                $area_demandante,
                $responsavel,
                $modalidade,
                $objeto,
                $palavras_chave,
                $valor_numerico,
                $status,
                $observacoes,
                $_SESSION['usuario_id'],
                $pca_dados_id
            ]);
            
            if (!$resultado) {
                throw new Exception('Erro ao salvar qualificação no banco de dados');
            }
            
            $qualificacao_id = $pdo->lastInsertId();
            error_log("Qualificação inserida com sucesso! ID: $qualificacao_id");
            error_log("Linhas afetadas: " . $stmt->rowCount());
            
            // Registrar no log
            registrarLog('CRIAR_QUALIFICACAO', "Criou qualificação ID: $qualificacao_id - NUP: $nup - Área: $area_demandante", 'qualificacoes', $qualificacao_id);
            
            $response['success'] = true;
            $response['message'] = 'Qualificação cadastrada com sucesso!';
            $response['id'] = $qualificacao_id;
            $response['nup'] = $nup;
            
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
            
            // Log do erro
            error_log("Erro ao criar qualificação: " . $e->getMessage());
        }
        
        echo json_encode($response);
        break;
        
    case 'buscar_qualificacao':
        verificarLogin();
        
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];
        
        try {
            $id = intval($_POST['id'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception('ID da qualificação é obrigatório');
            }
            
            // Buscar qualificação
            $sql = "SELECT * FROM qualificacoes WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);
            $qualificacao = $stmt->fetch();
            
            if (!$qualificacao) {
                throw new Exception('Qualificação não encontrada');
            }
            
            $response['success'] = true;
            $response['data'] = $qualificacao;
            
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
        }
        
        echo json_encode($response);
        break;
        
    case 'excluir_qualificacao':
        verificarLogin();
        
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];
        
        try {
            $id = intval($_POST['id'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception('ID da qualificação é obrigatório');
            }
            
            // Verificar se qualificação existe antes de excluir
            $sql_check = "SELECT nup FROM qualificacoes WHERE id = ?";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([$id]);
            $qualificacao = $stmt_check->fetch();
            
            if (!$qualificacao) {
                throw new Exception('Qualificação não encontrada');
            }
            
            // Excluir qualificação
            $sql = "DELETE FROM qualificacoes WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([$id]);
            
            if (!$resultado) {
                throw new Exception('Erro ao excluir qualificação do banco de dados');
            }
            
            $response['success'] = true;
            $response['message'] = 'Qualificação excluída com sucesso!';
            
            // Log da operação
            error_log("Qualificação excluída - ID: $id, NUP: " . $qualificacao['nup'] . ", Usuário: " . $_SESSION['usuario_id']);
            
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
            
            // Log do erro
            error_log("Erro ao excluir qualificação: " . $e->getMessage());
        }
        
        echo json_encode($response);
        break;
        
    case 'editar_qualificacao':
        verificarLogin();
        
        // Log da sessão para debug
        error_log("DEBUG: Usuario logado: " . ($_SESSION['usuario_logado'] ?? 'false'));
        error_log("DEBUG: Usuario ID: " . ($_SESSION['usuario_id'] ?? 'null'));
        
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];
        
        try {
            $id = intval($_POST['id'] ?? 0);
            
            if ($id <= 0) {
                throw new Exception('ID da qualificação é obrigatório');
            }
            
            // Validar dados obrigatórios
            $nup = limpar($_POST['nup'] ?? '');
            $area_demandante = limpar($_POST['area_demandante'] ?? '');
            $responsavel = limpar($_POST['responsavel'] ?? '');
            $modalidade = limpar($_POST['modalidade'] ?? '');
            $objeto = limpar($_POST['objeto'] ?? '');
            $palavras_chave = limpar($_POST['palavras_chave'] ?? '');
            $valor_estimado = limpar($_POST['valor_estimado'] ?? '');
            $status = limpar($_POST['status'] ?? '');
            $observacoes = limpar($_POST['observacoes'] ?? '');
            $pca_dados_id = !empty($_POST['pca_dados_id']) ? intval($_POST['pca_dados_id']) : null;
            
            // Validações
            if (empty($nup)) {
                throw new Exception('NUP é obrigatório');
            }
            
            if (empty($area_demandante)) {
                throw new Exception('Área demandante é obrigatória');
            }
            
            if (empty($responsavel)) {
                throw new Exception('Responsável é obrigatório');
            }
            
            if (empty($modalidade)) {
                throw new Exception('Modalidade é obrigatória');
            }
            
            if (empty($objeto)) {
                throw new Exception('Objeto é obrigatório');
            }
            
            if (empty($status)) {
                throw new Exception('Status é obrigatório');
            }
            
            // Limpar e converter valor monetário
            $valor_numerico = 0.00;
            if (!empty($valor_estimado)) {
                $valor_limpo = trim($valor_estimado);
                $valor_limpo = preg_replace('/[^\d,.]/', '', $valor_limpo);
                
                if (strpos($valor_limpo, '.') !== false && strpos($valor_limpo, ',') !== false) {
                    $valor_limpo = str_replace('.', '', $valor_limpo);
                    $valor_limpo = str_replace(',', '.', $valor_limpo);
                } elseif (strpos($valor_limpo, ',') !== false && strpos($valor_limpo, '.') === false) {
                    $valor_limpo = str_replace(',', '.', $valor_limpo);
                }
                
                $valor_numerico = floatval($valor_limpo);
                
                if ($valor_numerico <= 0) {
                    throw new Exception('Valor estimado deve ser maior que zero');
                }
            }
            
            // Verificar se a qualificação existe
            $sql_check = "SELECT id FROM qualificacoes WHERE id = ?";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([$id]);
            
            if (!$stmt_check->fetch()) {
                throw new Exception('Qualificação não encontrada');
            }
            
            // Verificar se NUP já existe em outra qualificação
            $sql_nup = "SELECT id FROM qualificacoes WHERE nup = ? AND id != ?";
            $stmt_nup = $pdo->prepare($sql_nup);
            $stmt_nup->execute([$nup, $id]);
            
            if ($stmt_nup->fetch()) {
                throw new Exception('Este NUP já está cadastrado em outra qualificação');
            }
            
            // Atualizar qualificação
            $sql = "UPDATE qualificacoes SET 
                nup = ?, 
                area_demandante = ?, 
                responsavel = ?, 
                modalidade = ?, 
                objeto = ?, 
                palavras_chave = ?, 
                valor_estimado = ?, 
                status = ?, 
                observacoes = ?,
                pca_dados_id = ?
                WHERE id = ?";
            
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([
                $nup,
                $area_demandante,
                $responsavel,
                $modalidade,
                $objeto,
                $palavras_chave,
                $valor_numerico,
                $status,
                $observacoes,
                $pca_dados_id,
                $id
            ]);
            
            if (!$resultado) {
                throw new Exception('Erro ao atualizar qualificação no banco de dados');
            }
            
            $response['success'] = true;
            $response['message'] = 'Qualificação atualizada com sucesso!';
            
            // Log da operação
            error_log("Qualificação editada - ID: $id, NUP: $nup, Usuário: " . $_SESSION['usuario_id']);
            
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
            
            // Log do erro
            error_log("Erro ao editar qualificação: " . $e->getMessage());
        }
        
        echo json_encode($response);
        break;

    case 'vincular_pca':
        verificarLogin();
        
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => ''];
        
        try {
            // Verificar se é POST
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método não permitido');
            }
            
            // Validar entrada
            $qualificacao_id = filter_input(INPUT_POST, 'qualificacao_id', FILTER_VALIDATE_INT);
            $pca_dados_id = filter_input(INPUT_POST, 'pca_dados_id', FILTER_VALIDATE_INT);
            
            if (!$qualificacao_id || !$pca_dados_id) {
                throw new Exception('IDs de qualificação e PCA são obrigatórios');
            }
            
            // Verificar se a qualificação existe
            $sql_check_qualif = "SELECT id FROM qualificacoes WHERE id = ?";
            $stmt_check_qualif = $pdo->prepare($sql_check_qualif);
            $stmt_check_qualif->execute([$qualificacao_id]);
            
            if (!$stmt_check_qualif->fetch()) {
                throw new Exception('Qualificação não encontrada');
            }
            
            // Verificar se o PCA existe
            $sql_check_pca = "SELECT id FROM pca_dados WHERE id = ?";
            $stmt_check_pca = $pdo->prepare($sql_check_pca);
            $stmt_check_pca->execute([$pca_dados_id]);
            
            if (!$stmt_check_pca->fetch()) {
                throw new Exception('Registro PCA não encontrado');
            }
            
            // Atualizar qualificação com vinculação
            $sql_update = "UPDATE qualificacoes SET pca_dados_id = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?";
            $stmt_update = $pdo->prepare($sql_update);
            $resultado = $stmt_update->execute([$pca_dados_id, $qualificacao_id]);
            
            if (!$resultado) {
                throw new Exception('Erro ao criar vinculação no banco de dados');
            }
            
            $response['success'] = true;
            $response['message'] = 'Vinculação PCA criada com sucesso!';
            
            // Log da operação
            error_log("Vinculação PCA criada - Qualificação: $qualificacao_id, PCA: $pca_dados_id, Usuário: " . $_SESSION['usuario_id']);
            
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
            
            // Log do erro
            error_log("Erro ao vincular PCA: " . $e->getMessage());
        }
        
        echo json_encode($response);
        break;

    case 'dashboard_stats_qualificacao':
        try {
            // Verificar se a tabela existe
            $check_table = $pdo->query("SHOW TABLES LIKE 'qualificacoes'");
            if ($check_table->rowCount() == 0) {
                // Tabela não existe - retornar dados zerados
                $response = [
                    'success' => true,
                    'data' => [
                        'status_chart' => [
                            'labels' => ['Jul', 'Ago', 'Set'],
                            'em_analise' => [0, 0, 0],
                            'concluido' => [0, 0, 0],
                            'arquivado' => [0, 0, 0]
                        ],
                        'performance_chart' => [
                            'labels' => ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
                            'dados' => [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                        ]
                    ]
                ];
            } else {
                // Buscar dados do gráfico de status por mês
                $status_sql = "SELECT 
                    MONTH(criado_em) as mes,
                    SUM(CASE WHEN status LIKE '%AN%LISE' THEN 1 ELSE 0 END) as em_analise,
                    SUM(CASE WHEN status LIKE 'CONCLU%DO' THEN 1 ELSE 0 END) as concluido,
                    SUM(CASE WHEN status = 'ARQUIVADO' THEN 1 ELSE 0 END) as arquivado
                    FROM qualificacoes 
                    WHERE YEAR(criado_em) = YEAR(CURDATE())
                    GROUP BY MONTH(criado_em)
                    ORDER BY MONTH(criado_em)";
                
                $stmt_status = $pdo->query($status_sql);
                $dados_status = $stmt_status->fetchAll();
                
                // Usar dados reais dos últimos meses
                $meses_labels = ['Jul', 'Ago', 'Set'];
                $em_analise = [0, 0, 0];
                $concluido = [0, 0, 0];
                $arquivado = [0, 0, 0];
                
                // Preencher com dados reais (meses 7, 8, 9)
                foreach ($dados_status as $dado) {
                    $mes_index = $dado['mes'] - 7; // Converter para index dos últimos 3 meses (Jul=0, Ago=1, Set=2)
                    if ($mes_index >= 0 && $mes_index < 3) {
                        $em_analise[$mes_index] = intval($dado['em_analise']);
                        $concluido[$mes_index] = intval($dado['concluido']);
                        $arquivado[$mes_index] = intval($dado['arquivado']);
                    }
                }
                
                // Buscar dados de performance por responsável
                $performance_sql = "SELECT 
                    responsavel,
                    COUNT(*) as total_processos,
                    SUM(CASE WHEN status LIKE '%AN%LISE' THEN 1 ELSE 0 END) as em_andamento,
                    SUM(CASE WHEN status LIKE 'CONCLU%DO' THEN 1 ELSE 0 END) as concluidas,
                    SUM(CASE WHEN status = 'ARQUIVADO' THEN 1 ELSE 0 END) as arquivadas,
                    ROUND((SUM(CASE WHEN status LIKE 'CONCLU%DO' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 1) as taxa_conclusao
                    FROM qualificacoes 
                    GROUP BY responsavel 
                    ORDER BY total_processos DESC
                    LIMIT 7";
                
                $stmt_performance = $pdo->query($performance_sql);
                $dados_performance = $stmt_performance->fetchAll();
                
                // Preparar dados para o gráfico de barras horizontais
                $responsaveis_labels = [];
                $responsaveis_totais = [];
                $responsaveis_concluidas = [];
                $responsaveis_taxa = [];
                $responsaveis_cores = [];
                
                foreach ($dados_performance as $dado) {
                    $responsaveis_labels[] = htmlspecialchars($dado['responsavel']);
                    $responsaveis_totais[] = intval($dado['total_processos']);
                    $responsaveis_concluidas[] = intval($dado['concluidas']);
                    $taxa = floatval($dado['taxa_conclusao']);
                    $responsaveis_taxa[] = $taxa;
                    
                    // Definir cor baseada na taxa de conclusão
                    if ($taxa >= 70) {
                        $responsaveis_cores[] = '#27ae60'; // Verde - Alta performance
                    } elseif ($taxa >= 50) {
                        $responsaveis_cores[] = '#f39c12'; // Amarelo - Média performance
                    } else {
                        $responsaveis_cores[] = '#e74c3c'; // Vermelho - Baixa performance
                    }
                }
                
                $response = [
                    'success' => true,
                    'data' => [
                        'status_chart' => [
                            'labels' => $meses_labels,
                            'em_analise' => $em_analise,
                            'concluido' => $concluido,
                            'arquivado' => $arquivado
                        ],
                        'performance_chart' => [
                            'labels' => $responsaveis_labels,
                            'totais' => $responsaveis_totais,
                            'concluidas' => $responsaveis_concluidas,
                            'taxa' => $responsaveis_taxa,
                            'cores' => $responsaveis_cores
                        ]
                    ]
                ];
            }
            
            echo json_encode($response);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false, 
                'message' => 'Erro ao buscar dados dos gráficos: ' . $e->getMessage()
            ]);
        }
        break;

    case 'criar_tramitacao_kanban':
        // Debug - escrever em arquivo de log
        error_log("🚀 CHEGOU NO CASE criar_tramitacao_kanban!");
        error_log("📋 POST DATA: " . print_r($_POST, true));
        
        verificarLogin();
        
        try {
            $usuario_id = $_SESSION['usuario_id'];
            $usuario_nivel = $_SESSION['usuario_nivel'];
            
            // Verificar permissões - somente níveis 1, 2, 3 podem criar
            if ($usuario_nivel > 3) {
                throw new Exception('Sem permissão para criar tramitações');
            }
            
            // Função para limpar dados (caso não exista)
            if (!function_exists('limpar')) {
                function limpar($str) {
                    return trim(strip_tags($str));
                }
            }
            
            // Dados do formulário
            $modulo_origem = limpar($_POST['modulo_origem'] ?? '');
            $modulo_destino = limpar($_POST['modulo_destino'] ?? '');
            $titulo = limpar($_POST['titulo'] ?? '');
            $descricao = limpar($_POST['descricao'] ?? '');
            $tipo_demanda = limpar($_POST['tipo_demanda'] ?? '');
            $prioridade = limpar($_POST['prioridade'] ?? '') ?: 'MEDIA';
            $status = limpar($_POST['status'] ?? '') ?: 'TODO';
            $usuario_responsavel_id = !empty($_POST['usuario_responsavel_id']) ? (int)$_POST['usuario_responsavel_id'] : null;
            $prazo_limite = !empty($_POST['prazo_limite']) ? $_POST['prazo_limite'] : null;
            $tags = limpar($_POST['tags'] ?? '') ?: '';
            $cor_card = limpar($_POST['cor_card'] ?? '') ?: '#3b82f6';
            $observacoes = limpar($_POST['observacoes'] ?? '') ?: '';
            
            error_log("📋 DADOS PROCESSADOS:");
            error_log("  Título: $titulo");
            error_log("  Tipo: $tipo_demanda");
            error_log("  Origem: $modulo_origem");
            error_log("  Destino: $modulo_destino");
            
            // Validações básicas
            if (empty($modulo_origem) || empty($modulo_destino) || empty($titulo) || empty($tipo_demanda)) {
                throw new Exception('Campos obrigatórios não preenchidos');
            }
            
            // Verificar se módulos são válidos
            $modulos_validos = ['PLANEJAMENTO', 'LICITACAO', 'QUALIFICACAO', 'CONTRATOS'];
            if (!in_array($modulo_origem, $modulos_validos) || !in_array($modulo_destino, $modulos_validos)) {
                throw new Exception('Módulos inválidos');
            }
            
            // Preparar tags como JSON
            $tags_array = [];
            if (!empty($tags)) {
                $tags_array = array_map('trim', explode(',', $tags));
                $tags_array = array_filter($tags_array); // Remove tags vazias
            }
            $tags_json = json_encode($tags_array);
            
            // Calcular situação do prazo
            $situacao_prazo = 'NO_PRAZO';
            $dias_restantes = 0;
            
            if ($prazo_limite) {
                $prazo_date = new DateTime($prazo_limite);
                $now = new DateTime();
                $diff = $now->diff($prazo_date);
                $dias_restantes = $diff->invert ? -$diff->days : $diff->days;
                
                if ($dias_restantes < 0) {
                    $situacao_prazo = 'ATRASADO';
                } elseif ($dias_restantes <= 3) {
                    $situacao_prazo = 'VENCENDO';
                }
            }
            
            // Inserir tramitação
            $sql = "
                INSERT INTO tramitacoes_kanban (
                    modulo_origem, modulo_destino, titulo, descricao, tipo_demanda,
                    prioridade, status, usuario_criador_id, usuario_responsavel_id,
                    prazo_limite, situacao_prazo, dias_restantes, cor_card, tags, observacoes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";
            
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([
                $modulo_origem, $modulo_destino, $titulo, $descricao, $tipo_demanda,
                $prioridade, $status, $usuario_id, $usuario_responsavel_id,
                $prazo_limite, $situacao_prazo, $dias_restantes, $cor_card, $tags_json, $observacoes
            ]);
            
            if ($resultado) {
                $tramitacao_id = $pdo->lastInsertId();
                error_log("✅ TRAMITAÇÃO CRIADA COM SUCESSO! ID: $tramitacao_id");
                
                // Processar tarefas selecionadas (se houver)
                if (isset($_POST['tarefas_selecionadas']) && is_array($_POST['tarefas_selecionadas'])) {
                    foreach ($_POST['tarefas_selecionadas'] as $tarefa_id) {
                        // Aqui você poderia inserir tarefas relacionadas se tiver uma tabela para isso
                        // Por enquanto, apenas registrar no log
                        registrarLog('tramitacao_tarefa', "Tarefa $tarefa_id vinculada à tramitação $tramitacao_id", 'tramitacoes_kanban', $tramitacao_id);
                    }
                }
                
                // Registrar log de criação
                registrarLog('criar_tramitacao', "Tramitação criada: $titulo", 'tramitacoes_kanban', $tramitacao_id);
                
                setMensagem('Tramitação criada com sucesso!', 'sucesso');
                error_log("✅ MENSAGEM DE SUCESSO DEFINIDA");
            } else {
                error_log("❌ FALHA AO INSERIR NO BANCO");
                throw new Exception('Erro ao inserir tramitação no banco de dados');
            }
            
        } catch (Exception $e) {
            error_log("❌ ERRO AO CRIAR TRAMITAÇÃO: " . $e->getMessage());
            error_log("📍 STACK TRACE: " . $e->getTraceAsString());
            registrarLog('erro_tramitacao', 'Erro ao criar tramitação: ' . $e->getMessage(), 'tramitacoes_kanban', null);
            setMensagem('Erro ao criar tramitação: ' . $e->getMessage(), 'erro');
        }
        
        // Redirecionar de volta para o kanban
        $redirect = $_POST['redirect'] ?? 'tramitacao_kanban.php';
        error_log("🔄 REDIRECIONANDO PARA: $redirect");
        header("Location: $redirect");
        exit;
        break;
    
    case 'editar_tramitacao_kanban':
        error_log("✏️ CHEGOU NO CASE editar_tramitacao_kanban!");
        error_log("📋 POST DATA: " . print_r($_POST, true));
        
        verificarLogin();
        
        try {
            $usuario_id = $_SESSION['usuario_id'];
            $usuario_nivel = $_SESSION['usuario_nivel'];
            
            // Verificar permissões - somente níveis 1, 2, 3 podem editar
            if ($usuario_nivel > 3) {
                throw new Exception('Sem permissão para editar tramitações');
            }
            
            // Capturar dados do formulário
            $tramitacao_id = (int)$_POST['tramitacao_id'];
            $modulo_origem = limpar($_POST['modulo_origem']);
            $modulo_destino = limpar($_POST['modulo_destino']);
            $titulo = limpar($_POST['titulo']);
            $descricao = limpar($_POST['descricao']);
            $tipo_demanda = limpar($_POST['tipo_demanda']);
            $prioridade = limpar($_POST['prioridade']);
            $status = limpar($_POST['status']);
            $tags = limpar($_POST['tags'] ?? '');
            $cor_card = limpar($_POST['cor_card'] ?? '#3b82f6');
            $observacoes = limpar($_POST['observacoes'] ?? '');
            
            if (!$tramitacao_id) {
                throw new Exception('ID da tramitação é obrigatório');
            }
            
            // Verificar se a tramitação existe
            $sql_check = "SELECT id FROM tramitacoes_kanban WHERE id = ?";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([$tramitacao_id]);
            
            if (!$stmt_check->fetch()) {
                throw new Exception('Tramitação não encontrada');
            }
            
            // Atualizar tramitação
            $sql = "
                UPDATE tramitacoes_kanban SET 
                    modulo_origem = ?, modulo_destino = ?, titulo = ?, descricao = ?, 
                    tipo_demanda = ?, prioridade = ?, status = ?, tags = ?, 
                    cor_card = ?, observacoes = ?, atualizado_em = NOW()
                WHERE id = ?
            ";
            
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([
                $modulo_origem, $modulo_destino, $titulo, $descricao,
                $tipo_demanda, $prioridade, $status, $tags,
                $cor_card, $observacoes, $tramitacao_id
            ]);
            
            if ($resultado) {
                // Registrar log de edição
                registrarLog('editar_tramitacao', "Tramitação editada: $titulo", 'tramitacoes_kanban', $tramitacao_id);
                
                setMensagem('Tramitação editada com sucesso!', 'sucesso');
                error_log("✅ TRAMITAÇÃO EDITADA COM SUCESSO: ID $tramitacao_id");
            } else {
                error_log("❌ FALHA AO ATUALIZAR TRAMITAÇÃO NO BANCO");
                throw new Exception('Erro ao atualizar tramitação no banco de dados');
            }
            
        } catch (Exception $e) {
            error_log("❌ ERRO AO EDITAR TRAMITAÇÃO: " . $e->getMessage());
            error_log("📍 STACK TRACE: " . $e->getTraceAsString());
            registrarLog('erro_tramitacao', 'Erro ao editar tramitação: ' . $e->getMessage(), 'tramitacoes_kanban', $tramitacao_id ?? null);
            setMensagem('Erro ao editar tramitação: ' . $e->getMessage(), 'erro');
        }
        
        // Redirecionar de volta para o kanban
        $redirect = $_POST['redirect'] ?? 'tramitacao_kanban.php';
        error_log("🔄 REDIRECIONANDO PARA: $redirect");
        header("Location: $redirect");
        exit;
        break;

    case 'atualizar_status_tramitacao':
        verificarLogin();
        
        // Retornar JSON para AJAX
        header('Content-Type: application/json');
        
        try {
            $usuario_nivel = $_SESSION['usuario_nivel'];
            
            // Verificar permissões - somente níveis 1, 2, 3 podem editar
            if ($usuario_nivel > 3) {
                throw new Exception('Sem permissão para editar tramitações');
            }
            
            $id = (int)$_POST['id'];
            $novo_status = $_POST['status'];
            
            // Validar status
            $status_validos = ['TODO', 'EM_PROGRESSO', 'AGUARDANDO', 'CONCLUIDO'];
            if (!in_array($novo_status, $status_validos)) {
                throw new Exception('Status inválido');
            }
            
            // Atualizar no banco
            $sql = "UPDATE tramitacoes_kanban SET status = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([$novo_status, $id]);
            
            if ($resultado) {
                // Registrar log
                registrarLog('status_tramitacao', "Status da tramitação $id alterado para $novo_status", 'tramitacoes_kanban', $id);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Status atualizado com sucesso!'
                ]);
            } else {
                throw new Exception('Erro ao atualizar status no banco');
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
        exit;
        break;

    case 'atualizar_posicao_tramitacao':
        verificarLogin();
        
        // Retornar JSON para AJAX
        header('Content-Type: application/json');
        
        try {
            $usuario_nivel = $_SESSION['usuario_nivel'];
            
            // Verificar permissões - somente níveis 1, 2, 3 podem editar
            if ($usuario_nivel > 3) {
                throw new Exception('Sem permissão para editar tramitações');
            }
            
            $id = (int)$_POST['id'];
            $nova_posicao = (int)$_POST['posicao'];
            
            // Atualizar posição no banco
            $sql = "UPDATE tramitacoes_kanban SET posicao = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $resultado = $stmt->execute([$nova_posicao, $id]);
            
            if ($resultado) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Posição atualizada!'
                ]);
            } else {
                throw new Exception('Erro ao atualizar posição');
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
        exit;
        break;

    case 'relatorio_area_demandante':
        try {
            // Receber parâmetros de filtro
            $data_inicio = $_POST['data_inicio'] ?? '';
            $data_fim = $_POST['data_fim'] ?? '';
            $area_filtro = $_POST['area_filtro'] ?? '';
            $status_filtro = $_POST['status_filtro'] ?? '';
            $modalidade_filtro = $_POST['modalidade_filtro'] ?? '';
            $valor_minimo = $_POST['valor_minimo'] ?? '';
            $valor_maximo = $_POST['valor_maximo'] ?? '';
            
            // Construir consulta SQL com filtros
            $where_conditions = ['1=1'];
            $params = [];
            
            // Filtro de data
            if (!empty($data_inicio) && !empty($data_fim)) {
                $where_conditions[] = "DATE(criado_em) BETWEEN ? AND ?";
                $params[] = $data_inicio;
                $params[] = $data_fim;
            }
            
            // Filtro de área
            if (!empty($area_filtro)) {
                $where_conditions[] = "area_demandante = ?";
                $params[] = $area_filtro;
            }
            
            // Filtro de status (usando LIKE para problemas de codificação)
            if (!empty($status_filtro)) {
                if ($status_filtro === '1ª ANÁLISE') {
                    $where_conditions[] = "status LIKE '1%AN%LISE'";
                } elseif ($status_filtro === '2ª ANÁLISE') {
                    $where_conditions[] = "status LIKE '2%AN%LISE'";
                } elseif ($status_filtro === 'CONCLUÍDO') {
                    $where_conditions[] = "status LIKE 'CONCLU%DO'";
                } else {
                    $where_conditions[] = "status = ?";
                    $params[] = $status_filtro;
                }
            }
            
            // Filtro de modalidade
            if (!empty($modalidade_filtro)) {
                $where_conditions[] = "modalidade = ?";
                $params[] = $modalidade_filtro;
            }
            
            // Filtro de valor mínimo
            if (!empty($valor_minimo) && is_numeric($valor_minimo)) {
                $where_conditions[] = "valor_estimado >= ?";
                $params[] = floatval($valor_minimo);
            }
            
            // Filtro de valor máximo
            if (!empty($valor_maximo) && is_numeric($valor_maximo)) {
                $where_conditions[] = "valor_estimado <= ?";
                $params[] = floatval($valor_maximo);
            }
            
            $where_clause = implode(' AND ', $where_conditions);
            
            // Consulta principal
            $sql = "SELECT 
                        nup,
                        area_demandante,
                        modalidade,
                        status,
                        SUBSTRING(objeto, 1, 80) as objeto_resumo,
                        valor_estimado,
                        criado_em
                    FROM qualificacoes 
                    WHERE $where_clause 
                    ORDER BY area_demandante ASC, valor_estimado DESC";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $dados = $stmt->fetchAll();
            
            // Preparar dados formatados para a resposta
            $resultados = [];
            $total_valor = 0;
            $total_registros = 0;
            $areas_stats = [];
            
            foreach ($dados as $row) {
                $area = $row['area_demandante'];
                $valor = floatval($row['valor_estimado']);
                
                // Estatísticas por área
                if (!isset($areas_stats[$area])) {
                    $areas_stats[$area] = [
                        'total' => 0,
                        'valor_total' => 0,
                        'em_analise' => 0,
                        'concluido' => 0,
                        'arquivado' => 0
                    ];
                }
                
                $areas_stats[$area]['total']++;
                $areas_stats[$area]['valor_total'] += $valor;
                
                // Contar status (usando verificação flexível)
                $status = $row['status'];
                
                // Corrigir problemas de encoding no status
                $status_original = $status;
                
                // Primeiro, tentar converter encoding
                $status = mb_convert_encoding($status, 'UTF-8', 'auto');
                
                // Mapeamento de status com problemas conhecidos
                $statusMap = [
                    '1? AN?LISE' => '1ª ANÁLISE',
                    '1� AN�LISE' => '1ª ANÁLISE',
                    '2? AN?LISE' => '2ª ANÁLISE', 
                    '2� AN�LISE' => '2ª ANÁLISE',
                    'CONCLU?DO' => 'CONCLUÍDO',
                    'CONCLU�DO' => 'CONCLUÍDO',
                    // Versões com diferentes encodings
                    '1ª ANáLISE' => '1ª ANÁLISE',
                    '2ª ANáLISE' => '2ª ANÁLISE',
                    'CONCLUíDO' => 'CONCLUÍDO'
                ];
                
                // Tentar mapear primeiro o status original, depois o convertido
                if (isset($statusMap[$status_original])) {
                    $status = $statusMap[$status_original];
                } elseif (isset($statusMap[$status])) {
                    $status = $statusMap[$status];
                } else {
                    // Regex para capturar padrões comuns
                    if (preg_match('/1.+AN.+LISE/i', $status)) {
                        $status = '1ª ANÁLISE';
                    } elseif (preg_match('/2.+AN.+LISE/i', $status)) {
                        $status = '2ª ANÁLISE';
                    } elseif (preg_match('/CONCLU.+DO/i', $status)) {
                        $status = 'CONCLUÍDO';
                    }
                }
                
                if (strpos($status, 'AN') !== false && strpos($status, 'LISE') !== false) {
                    $areas_stats[$area]['em_analise']++;
                } elseif (strpos($status, 'CONCLU') !== false) {
                    $areas_stats[$area]['concluido']++;
                } elseif (strpos($status, 'ARQUIVADO') !== false) {
                    $areas_stats[$area]['arquivado']++;
                }
                
                $resultados[] = [
                    'nup' => $row['nup'],
                    'area_demandante' => $area,
                    'modalidade' => $row['modalidade'],
                    'status' => $status,
                    'objeto_resumo' => $row['objeto_resumo'],
                    'valor_estimado' => $valor,
                    'valor_formatado' => 'R$ ' . number_format($valor, 2, ',', '.')
                ];
                
                $total_valor += $valor;
                $total_registros++;
            }
            
            // Buscar lista de áreas para os filtros
            $areas_sql = "SELECT DISTINCT area_demandante FROM qualificacoes ORDER BY area_demandante ASC";
            $stmt_areas = $pdo->query($areas_sql);
            $lista_areas = $stmt_areas->fetchAll(PDO::FETCH_COLUMN);
            
            $response = [
                'success' => true,
                'data' => [
                    'resultados' => $resultados,
                    'estatisticas' => [
                        'total_registros' => $total_registros,
                        'valor_total' => $total_valor,
                        'valor_total_formatado' => 'R$ ' . number_format($total_valor, 2, ',', '.'),
                        'areas_stats' => $areas_stats
                    ],
                    'filtros' => [
                        'areas_disponiveis' => $lista_areas
                    ]
                ]
            ];
            
            echo json_encode($response);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao gerar relatório: ' . $e->getMessage()
            ]);
        }
        exit;
        break;

    case 'relatorio_execucao_pca':
        verificarLogin();

        // Limpar qualquer output anterior
        while (ob_get_level()) {
            ob_end_clean();
        }

        // Configurar headers corretamente
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

        try {
            $pdo = conectarDB();

            // Receber parâmetros de filtro
            $data_inicio = $_POST['data_inicio'] ?? '';
            $data_fim = $_POST['data_fim'] ?? '';
            $area_requisitante_filtro = $_POST['area_requisitante_filtro'] ?? '';
            $categoria_filtro = $_POST['categoria_filtro'] ?? '';
            $status_execucao_filtro = $_POST['status_execucao_filtro'] ?? '';
            $status_contratacao_filtro = $_POST['status_contratacao_filtro'] ?? '';
            $situacao_original_filtro = $_POST['situacao_original_filtro'] ?? '';
            $tem_licitacao_filtro = $_POST['tem_licitacao_filtro'] ?? '';
            $valor_minimo = $_POST['valor_minimo'] ?? '';
            $valor_maximo = $_POST['valor_maximo'] ?? '';

            // Obter ano e configurar tabela dinâmica (CORRIGIDO como dashboard)
            $ano_selecionado = $_POST['ano'] ?? date('Y');
            $tabela_pca = getPcaTableName($ano_selecionado);

            // Buscar IDs das importações do ano para filtrar corretamente
            $stmt_importacoes = $pdo->prepare("
                SELECT GROUP_CONCAT(id) as ids
                FROM pca_importacoes
                WHERE ano_pca = ? AND status = 'concluido'
            ");
            $stmt_importacoes->execute([$ano_selecionado]);
            $importacoes_result = $stmt_importacoes->fetch();
            $importacoes_ids_str = $importacoes_result['ids'] ?? '';

            if (empty($importacoes_ids_str)) {
                // Sem importações - retornar dados zerados
                $empty_json = json_encode([
                    'success' => true,
                    'data' => [
                        'resultados' => [],
                        'total_resultados' => 0,
                        'paginacao' => [
                            'pagina_atual' => 1,
                            'total_paginas' => 0,
                            'por_pagina' => 20,
                            'total_registros' => 0
                        ],
                        'estatisticas' => [
                            'total_registros' => 0,
                            'valor_total_formatado' => 'R$ 0,00',
                            'contadores' => [
                                'em_atraso' => 0,
                                'em_execucao' => 0,
                                'executado' => 0,
                                'nao_executado' => 0
                            ],
                            'percentuais_quantidade' => [
                                'em_atraso' => 0,
                                'em_execucao' => 0,
                                'executado' => 0,
                                'nao_executado' => 0
                            ]
                        ]
                    ]
                ]);
                echo $empty_json;

                // Forçar envio imediato
                if (function_exists('fastcgi_finish_request')) {
                    fastcgi_finish_request();
                } else {
                    flush();
                }
                exit;
            }

            $importacoes_ids = explode(',', $importacoes_ids_str);
            $where_stats = "importacao_id IN (" . implode(',', $importacoes_ids) . ")";

            // Construir consulta SQL base (CORRIGIDO - usa tabela dinâmica e filtros)
            $sql_base = "
                SELECT
                    pca.numero_dfd,
                    pca.numero_contratacao,
                    pca.titulo_contratacao,
                    pca.categoria_contratacao,
                    pca.area_requisitante,
                    pca.valor_total_contratacao,
                    pca.valor_total,
                    pca.status_contratacao,
                    pca.situacao_execucao,
                    pca.data_inicio_processo,
                    pca.data_conclusao_processo,

                    -- LÓGICA DE STATUS AJUSTADA
                    CASE
                        WHEN pca.situacao_execucao LIKE '%o iniciado' THEN 'EM ATRASO'
                        WHEN pca.situacao_execucao LIKE '%preparacao%' OR pca.situacao_execucao LIKE '%edicao%' THEN 'EM EXECUÇÃO'
                        WHEN pca.situacao_execucao LIKE '%encerrada%' THEN 'EXECUTADO'
                        WHEN pca.situacao_execucao LIKE '%revogada%' OR pca.situacao_execucao LIKE '%anulada%' THEN 'NÃO EXECUTADO'
                        ELSE 'INDEFINIDO'
                    END as status_execucao_ajustado,

                    -- RELACIONAMENTO COM LICITAÇÕES
                    CASE
                        WHEN l.numero_contratacao IS NOT NULL THEN 'SIM'
                        ELSE 'NÃO'
                    END as tem_licitacao,

                    l.modalidade as modalidade_licitacao,
                    l.situacao as situacao_licitacao,

                    -- CÁLCULO DE ATRASO EM DIAS
                    CASE
                        WHEN pca.situacao_execucao LIKE '%o iniciado' AND pca.data_inicio_processo < CURDATE()
                        THEN DATEDIFF(CURDATE(), pca.data_inicio_processo)
                        ELSE 0
                    END as dias_atraso

                FROM {$tabela_pca} pca
                LEFT JOIN licitacoes l ON pca.numero_contratacao = l.numero_contratacao
                WHERE {$where_stats}
                AND pca.numero_dfd IS NOT NULL AND pca.numero_dfd != ''
            ";

            // Construir condições WHERE
            $where_conditions = [];
            $params = [];

            // Filtro de data (data_inicio_processo)
            if (!empty($data_inicio) && !empty($data_fim)) {
                $where_conditions[] = "DATE(pca.data_inicio_processo) BETWEEN ? AND ?";
                $params[] = $data_inicio;
                $params[] = $data_fim;
            }

            // Filtro por área requisitante
            if (!empty($area_requisitante_filtro)) {
                $where_conditions[] = "pca.area_requisitante = ?";
                $params[] = $area_requisitante_filtro;
            }

            // Filtro por categoria
            if (!empty($categoria_filtro)) {
                $where_conditions[] = "pca.categoria_contratacao = ?";
                $params[] = $categoria_filtro;
            }

            // Filtro por status de contratação
            if (!empty($status_contratacao_filtro)) {
                $where_conditions[] = "pca.status_contratacao = ?";
                $params[] = $status_contratacao_filtro;
            }

            // Filtro por situação original
            if (!empty($situacao_original_filtro)) {
                $where_conditions[] = "pca.situacao_execucao LIKE ?";
                $params[] = '%' . $situacao_original_filtro . '%';
            }

            // Filtro por faixa de valores
            if (!empty($valor_minimo)) {
                $where_conditions[] = "pca.valor_total_contratacao >= ?";
                $params[] = floatval($valor_minimo);
            }

            if (!empty($valor_maximo)) {
                $where_conditions[] = "pca.valor_total_contratacao <= ?";
                $params[] = floatval($valor_maximo);
            }

            // Adicionar condições WHERE à consulta
            if (!empty($where_conditions)) {
                $sql_base .= " AND " . implode(" AND ", $where_conditions);
            }

            // Adicionar GROUP BY e ORDER BY (CORRIGIDO - agrupa por DFD, não contratação)
            $sql_base .= "
                ORDER BY pca.valor_total DESC
                LIMIT 100
            ";

            $stmt = $pdo->prepare($sql_base);
            $stmt->execute($params);
            $resultados = $stmt->fetchAll();

            // Filtrar por status de execução ajustado (pós-processamento)
            if (!empty($status_execucao_filtro)) {
                $resultados = array_filter($resultados, function($row) use ($status_execucao_filtro) {
                    return $row['status_execucao_ajustado'] === $status_execucao_filtro;
                });
            }

            // Filtrar por "tem licitação" (pós-processamento)
            if (!empty($tem_licitacao_filtro)) {
                $resultados = array_filter($resultados, function($row) use ($tem_licitacao_filtro) {
                    return $row['tem_licitacao'] === $tem_licitacao_filtro;
                });
            }

            // Calcular estatísticas (CORRIGIDO - usa valor_total dos itens)
            $total_registros = count($resultados);
            $valor_total = array_sum(array_column($resultados, 'valor_total'));

            // Calcular percentuais por status
            $stats_status = ['EM ATRASO' => 0, 'EM EXECUÇÃO' => 0, 'EXECUTADO' => 0, 'NÃO EXECUTADO' => 0];
            $stats_valores = ['EM ATRASO' => 0, 'EM EXECUÇÃO' => 0, 'EXECUTADO' => 0, 'NÃO EXECUTADO' => 0];

            foreach ($resultados as $row) {
                $status = $row['status_execucao_ajustado'];
                if (isset($stats_status[$status])) {
                    $stats_status[$status]++;
                    $stats_valores[$status] += floatval($row['valor_total']);
                }
            }

            // Formatar resultados para exibição
            $resultados_formatados = [];
            foreach ($resultados as $row) {
                $resultados_formatados[] = [
                    'numero_dfd' => $row['numero_dfd'],
                    'numero_contratacao' => $row['numero_contratacao'],
                    'titulo_contratacao' => substr($row['titulo_contratacao'], 0, 100) . '...',
                    'categoria_contratacao' => $row['categoria_contratacao'],
                    'area_requisitante' => $row['area_requisitante'],
                    'status_execucao_ajustado' => $row['status_execucao_ajustado'],
                    'valor_total_contratacao' => $row['valor_total_contratacao'],
                    'valor_total' => $row['valor_total'],
                    'valor_formatado' => 'R$ ' . number_format($row['valor_total'], 2, ',', '.'),
                    'dias_atraso' => $row['dias_atraso'],
                    'tem_licitacao' => $row['tem_licitacao'],
                    'modalidade_licitacao' => $row['modalidade_licitacao'] ?? '-',
                ];
            }


            // Implementar paginação
            $pagina = intval($_POST['pagina'] ?? 1);
            $por_pagina = 20;
            $offset = ($pagina - 1) * $por_pagina;
            $total_paginas = ceil(count($resultados_formatados) / $por_pagina);

            $resultados_limitados = array_slice($resultados_formatados, $offset, $por_pagina);

            // Calcular percentuais
            $percentuais_quantidade = [];
            if ($total_registros > 0) {
                $percentuais_quantidade = [
                    'em_atraso' => round(($stats_status['EM ATRASO'] / $total_registros) * 100, 1),
                    'em_execucao' => round(($stats_status['EM EXECUÇÃO'] / $total_registros) * 100, 1),
                    'executado' => round(($stats_status['EXECUTADO'] / $total_registros) * 100, 1),
                    'nao_executado' => round(($stats_status['NÃO EXECUTADO'] / $total_registros) * 100, 1)
                ];
            } else {
                $percentuais_quantidade = [
                    'em_atraso' => 0,
                    'em_execucao' => 0,
                    'executado' => 0,
                    'nao_executado' => 0
                ];
            }

            $json_data = [
                'success' => true,
                'data' => [
                    'resultados' => $resultados_limitados,
                    'total_resultados' => $total_registros,
                    'paginacao' => [
                        'pagina_atual' => $pagina,
                        'total_paginas' => $total_paginas,
                        'por_pagina' => $por_pagina,
                        'total_registros' => count($resultados_formatados)
                    ],
                    'estatisticas' => [
                        'total_registros' => $total_registros,
                        'valor_total_formatado' => 'R$ ' . number_format($valor_total, 2, ',', '.'),
                        'contadores' => [
                            'em_atraso' => $stats_status['EM ATRASO'],
                            'em_execucao' => $stats_status['EM EXECUÇÃO'],
                            'executado' => $stats_status['EXECUTADO'],
                            'nao_executado' => $stats_status['NÃO EXECUTADO']
                        ],
                        'percentuais_quantidade' => $percentuais_quantidade
                    ]
                ]
            ];

            // Enviar JSON com flush
            $json_output = json_encode($json_data);
            echo $json_output;

            // Forçar envio imediato
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                flush();
            }

        } catch (Exception $e) {
            error_log("Erro no relatório de execução PCA: " . $e->getMessage());
            $error_json = json_encode([
                'success' => false,
                'message' => 'Erro ao gerar relatório: ' . $e->getMessage()
            ]);
            echo $error_json;

            // Forçar envio imediato
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                flush();
            }
        }
        exit;
        break;

    case 'dashboard_executivo_pca':
        verificarLogin();

        header('Content-Type: application/json');

        try {
            $pdo = conectarDB();

            // Obter ano selecionado (padrão: ano atual)
            $ano_selecionado = $_POST['ano'] ?? date('Y');
            $tabela_pca = getPcaTableName($ano_selecionado);

            // Buscar IDs das importações do ano para filtrar corretamente
            $stmt_importacoes = $pdo->prepare("
                SELECT GROUP_CONCAT(id) as ids
                FROM pca_importacoes
                WHERE ano_pca = ? AND status = 'concluido'
            ");
            $stmt_importacoes->execute([$ano_selecionado]);
            $importacoes_result = $stmt_importacoes->fetch();
            $importacoes_ids_str = $importacoes_result['ids'] ?? '';

            if (empty($importacoes_ids_str)) {
                // Sem importações - retornar dados zerados
                echo json_encode([
                    'success' => true,
                    'estatisticas' => [
                        'total_contratacoes' => 0,
                        'percentual_licitados' => 0,
                        'valor_total_formatado' => 'R$ 0,00',
                        'valor_total_raw' => 0,
                        'total_atraso' => 0,
                        'valor_atraso_formatado' => 'R$ 0,00',
                        'valor_atraso_raw' => 0,
                        'total_preparacao' => 0,
                        'valor_preparacao_formatado' => 'R$ 0,00',
                        'valor_preparacao_raw' => 0,
                        'total_encerradas' => 0,
                        'valor_encerradas_formatado' => 'R$ 0,00',
                        'valor_encerradas_raw' => 0,
                        'total_aprovadas' => 0,
                        'valor_aprovadas_formatado' => 'R$ 0,00',
                        'valor_aprovadas_raw' => 0
                    ]
                ]);
                exit;
            }

            $importacoes_ids = explode(',', $importacoes_ids_str);
            $where_stats = "importacao_id IN (" . implode(',', $importacoes_ids) . ")";

            // 1. Total de DFDs planejados (CORRIGIDO - usa numero_dfd como dashboard)
            $stmt = $pdo->query("
                SELECT COUNT(DISTINCT numero_dfd) as total_dfds
                FROM {$tabela_pca}
                WHERE {$where_stats}
                AND numero_dfd IS NOT NULL AND numero_dfd != ''
            ");
            $total_contratacoes = $stmt->fetch()['total_dfds'];

            // 2. Percentual com licitação associada (CORRIGIDO - conta por DFD)
            $stmt = $pdo->query("
                SELECT
                    COUNT(DISTINCT p.numero_dfd) as total_dfds,
                    COUNT(DISTINCT CASE WHEN l.numero_contratacao IS NOT NULL THEN p.numero_dfd END) as dfds_com_licitacao
                FROM {$tabela_pca} p
                LEFT JOIN licitacoes l ON p.numero_contratacao = l.numero_contratacao
                WHERE {$where_stats}
                AND p.numero_dfd IS NOT NULL AND p.numero_dfd != ''
            ");
            $licitacao_stats = $stmt->fetch();
            $percentual_licitados = $licitacao_stats['total_dfds'] > 0 ?
                round(($licitacao_stats['dfds_com_licitacao'] / $licitacao_stats['total_dfds']) * 100, 1) : 0;

            // 3. Valor total planejado (CORRIGIDO - usa filtros corretos)
            $stmt = $pdo->query("
                SELECT COALESCE(SUM(valor_total), 0) as valor_total
                FROM {$tabela_pca}
                WHERE {$where_stats}
                AND numero_dfd IS NOT NULL AND numero_dfd != ''
            ");
            $valor_total = $stmt->fetch()['valor_total'] ?: 0;
            $valor_total_formatado = 'R$ ' . number_format($valor_total, 2, ',', '.');

            // 4. Contadores por status com valores (AGRUPADO POR CONTRATAÇÃO)
            $stmt = $pdo->query("
                SELECT
                    MAX(COALESCE(situacao_execucao, 'Não iniciado')) as situacao_execucao,
                    COUNT(DISTINCT numero_contratacao) as quantidade,
                    SUM(valor_total) as valor_total
                FROM {$tabela_pca}
                WHERE {$where_stats}
                AND numero_contratacao IS NOT NULL AND numero_contratacao != ''
                GROUP BY numero_contratacao
            ");

            $stats_status = [
                'atraso' => ['quantidade' => 0, 'valor' => 0],
                'preparacao' => ['quantidade' => 0, 'valor' => 0],
                'encerrada' => ['quantidade' => 0, 'valor' => 0]
            ];

            while ($row = $stmt->fetch()) {
                $situacao = strtolower($row['situacao_execucao']);
                $qtd = 1; // Sempre 1 porque estamos contando por contratação
                $valor = floatval($row['valor_total'] ?: 0);

                // Mapear situações para categorias com valores
                if (strpos($situacao, 'iniciado') !== false) {
                    $stats_status['atraso']['quantidade'] += $qtd;
                    $stats_status['atraso']['valor'] += $valor;
                } elseif (strpos($situacao, 'prepar') !== false || strpos($situacao, 'edicao') !== false) {
                    $stats_status['preparacao']['quantidade'] += $qtd;
                    $stats_status['preparacao']['valor'] += $valor;
                } elseif (strpos($situacao, 'encerrada') !== false) {
                    $stats_status['encerrada']['quantidade'] += $qtd;
                    $stats_status['encerrada']['valor'] += $valor;
                }
            }

            // 5. DFDs Aprovados (CORRIGIDO - conta por DFD, não contratação)
            $stmt = $pdo->query("
                SELECT
                    COUNT(DISTINCT numero_dfd) as quantidade,
                    SUM(valor_total) as valor_total
                FROM {$tabela_pca}
                WHERE {$where_stats}
                AND numero_dfd IS NOT NULL AND numero_dfd != ''
                AND status_contratacao = 'Aprovada'
            ");
            $aprovadas_stats = $stmt->fetch();
            $total_aprovadas = $aprovadas_stats['quantidade'] ?: 0;
            $valor_aprovadas = floatval($aprovadas_stats['valor_total'] ?: 0);
            $valor_aprovadas_formatado = 'R$ ' . number_format($valor_aprovadas, 2, ',', '.');

            // Formatação dos valores
            $valor_atraso_formatado = 'R$ ' . number_format($stats_status['atraso']['valor'], 2, ',', '.');
            $valor_preparacao_formatado = 'R$ ' . number_format($stats_status['preparacao']['valor'], 2, ',', '.');

            echo json_encode([
                'success' => true,
                'estatisticas' => [
                    'total_contratacoes' => $total_contratacoes,
                    'percentual_licitados' => $percentual_licitados,
                    'valor_total_formatado' => $valor_total_formatado,
                    'valor_total_raw' => $valor_total,
                    // Dados expandidos com quantidade + valor
                    'total_atraso' => $stats_status['atraso']['quantidade'],
                    'valor_atraso_formatado' => $valor_atraso_formatado,
                    'valor_atraso_raw' => $stats_status['atraso']['valor'],
                    'total_preparacao' => $stats_status['preparacao']['quantidade'],
                    'valor_preparacao_formatado' => $valor_preparacao_formatado,
                    'valor_preparacao_raw' => $stats_status['preparacao']['valor'],
                    // Contratações Encerradas (novo KPI)
                    'total_encerradas' => $stats_status['encerrada']['quantidade'],
                    'valor_encerradas_formatado' => 'R$ ' . number_format($stats_status['encerrada']['valor'], 2, ',', '.'),
                    'valor_encerradas_raw' => $stats_status['encerrada']['valor'],
                    // Contratações Aprovadas
                    'total_aprovadas' => $total_aprovadas,
                    'valor_aprovadas_formatado' => $valor_aprovadas_formatado,
                    'valor_aprovadas_raw' => $valor_aprovadas
                ]
            ]);

        } catch (Exception $e) {
            error_log("Erro no dashboard executivo PCA: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao carregar dashboard: ' . $e->getMessage()
            ]);
        }
        exit;
        break;

    case 'teste_debug':
        error_log("🧪 TESTE DEBUG EXECUTADO!");
        echo "<h1>✅ Process.php está funcionando!</h1>";
        echo "<p>Timestamp: " . date('Y-m-d H:i:s') . "</p>";
        echo "<p><a href='debug_process.php'>← Voltar para Debug</a></p>";
        exit;
        break;

    case 'dashboard_executivo_qualificacoes':
        // Dashboard executivo das qualificações com data-cards
        try {
            // 1. Total de processos de qualificação
            $stmt = $pdo->query("
                SELECT COUNT(*) as total_processos, SUM(valor_estimado) as valor_total
                FROM qualificacoes
                WHERE status IS NOT NULL
            ");
            $totais = $stmt->fetch();
            $total_processos = $totais['total_processos'] ?: 0;
            $valor_total = floatval($totais['valor_total'] ?: 0);
            $valor_total_formatado = 'R$ ' . number_format($valor_total, 2, ',', '.');

            // 2. Contadores por status com valores
            $stmt = $pdo->query("
                SELECT
                    status,
                    COUNT(*) as quantidade,
                    SUM(valor_estimado) as valor_total
                FROM qualificacoes
                WHERE status IS NOT NULL
                GROUP BY status
            ");

            $stats_status = [
                'primeira_analise' => ['quantidade' => 0, 'valor' => 0],
                'segunda_analise' => ['quantidade' => 0, 'valor' => 0],
                'concluidos' => ['quantidade' => 0, 'valor' => 0],
                'arquivados' => ['quantidade' => 0, 'valor' => 0]
            ];

            while ($row = $stmt->fetch()) {
                $status = strtolower($row['status']);
                $qtd = $row['quantidade'];
                $valor = floatval($row['valor_total'] ?: 0);

                // Mapear status para categorias
                if (strpos($status, '1') !== false && strpos($status, 'an') !== false) {
                    $stats_status['primeira_analise']['quantidade'] += $qtd;
                    $stats_status['primeira_analise']['valor'] += $valor;
                } elseif (strpos($status, '2') !== false && strpos($status, 'an') !== false) {
                    $stats_status['segunda_analise']['quantidade'] += $qtd;
                    $stats_status['segunda_analise']['valor'] += $valor;
                } elseif (strpos($status, 'conclu') !== false) {
                    $stats_status['concluidos']['quantidade'] += $qtd;
                    $stats_status['concluidos']['valor'] += $valor;
                } elseif (strpos($status, 'arquiv') !== false) {
                    $stats_status['arquivados']['quantidade'] += $qtd;
                    $stats_status['arquivados']['valor'] += $valor;
                }
            }

            // Formatação dos valores
            $valor_primeira_analise_formatado = 'R$ ' . number_format($stats_status['primeira_analise']['valor'], 2, ',', '.');
            $valor_segunda_analise_formatado = 'R$ ' . number_format($stats_status['segunda_analise']['valor'], 2, ',', '.');
            $valor_concluidos_formatado = 'R$ ' . number_format($stats_status['concluidos']['valor'], 2, ',', '.');
            $valor_arquivados_formatado = 'R$ ' . number_format($stats_status['arquivados']['valor'], 2, ',', '.');

            echo json_encode([
                'success' => true,
                'estatisticas' => [
                    'total_processos' => $total_processos,
                    'valor_total_formatado' => $valor_total_formatado,
                    'valor_total_raw' => $valor_total,
                    // Dados por status
                    'total_primeira_analise' => $stats_status['primeira_analise']['quantidade'],
                    'valor_primeira_analise_formatado' => $valor_primeira_analise_formatado,
                    'valor_primeira_analise_raw' => $stats_status['primeira_analise']['valor'],
                    'total_segunda_analise' => $stats_status['segunda_analise']['quantidade'],
                    'valor_segunda_analise_formatado' => $valor_segunda_analise_formatado,
                    'valor_segunda_analise_raw' => $stats_status['segunda_analise']['valor'],
                    'total_concluidos' => $stats_status['concluidos']['quantidade'],
                    'valor_concluidos_formatado' => $valor_concluidos_formatado,
                    'valor_concluidos_raw' => $stats_status['concluidos']['valor'],
                    'total_arquivados' => $stats_status['arquivados']['quantidade'],
                    'valor_arquivados_formatado' => $valor_arquivados_formatado,
                    'valor_arquivados_raw' => $stats_status['arquivados']['valor']
                ]
            ]);
        } catch (Exception $e) {
            error_log("Erro no dashboard qualificações: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao carregar estatísticas das qualificações'
            ]);
        }
        exit;
        break;

    case 'dashboard_executivo_licitacoes':
        // Dashboard executivo das licitações com foco em economia
        try {
            // 1. Total de licitações e valor total estimado
            $stmt = $pdo->query("
                SELECT COUNT(*) as total_licitacoes, SUM(valor_estimado) as valor_total_estimado
                FROM licitacoes
            ");
            $totais = $stmt->fetch();
            $total_licitacoes = $totais['total_licitacoes'] ?: 0;
            $valor_total_estimado = floatval($totais['valor_total_estimado'] ?: 0);
            $valor_total_formatado = 'R$ ' . number_format($valor_total_estimado, 2, ',', '.');

            // 2. Contadores por situação com valores
            $stmt = $pdo->query("
                SELECT
                    situacao,
                    COUNT(*) as quantidade,
                    SUM(valor_estimado) as valor_estimado_total,
                    SUM(valor_homologado) as valor_homologado_total
                FROM licitacoes
                GROUP BY situacao
            ");

            $stats_situacao = [
                'homologadas' => ['quantidade' => 0, 'valor_estimado' => 0, 'valor_homologado' => 0],
                'andamento' => ['quantidade' => 0, 'valor_estimado' => 0, 'valor_homologado' => 0],
                'canceladas' => ['quantidade' => 0, 'valor_estimado' => 0, 'valor_homologado' => 0]
            ];

            while ($row = $stmt->fetch()) {
                $situacao = strtolower($row['situacao']);
                $qtd = $row['quantidade'];
                $valor_estimado = floatval($row['valor_estimado_total'] ?: 0);
                $valor_homologado = floatval($row['valor_homologado_total'] ?: 0);

                // Mapear situações para categorias
                if (strpos($situacao, 'homolog') !== false) {
                    $stats_situacao['homologadas']['quantidade'] += $qtd;
                    $stats_situacao['homologadas']['valor_estimado'] += $valor_estimado;
                    $stats_situacao['homologadas']['valor_homologado'] += $valor_homologado;
                } elseif (strpos($situacao, 'andamento') !== false || strpos($situacao, 'preparacao') !== false) {
                    $stats_situacao['andamento']['quantidade'] += $qtd;
                    $stats_situacao['andamento']['valor_estimado'] += $valor_estimado;
                    $stats_situacao['andamento']['valor_homologado'] += $valor_homologado;
                } elseif (strpos($situacao, 'revog') !== false || strpos($situacao, 'cancel') !== false || strpos($situacao, 'fracass') !== false) {
                    $stats_situacao['canceladas']['quantidade'] += $qtd;
                    $stats_situacao['canceladas']['valor_estimado'] += $valor_estimado;
                    $stats_situacao['canceladas']['valor_homologado'] += $valor_homologado;
                }
            }

            // 3. Cálculo da economia total
            $stmt = $pdo->query("
                SELECT
                    SUM(economia) as economia_total,
                    SUM(valor_estimado) as valor_estimado_homologadas,
                    SUM(valor_homologado) as valor_homologado_total
                FROM licitacoes
                WHERE situacao = 'HOMOLOGADO'
            ");
            $economia_data = $stmt->fetch();
            $economia_total = floatval($economia_data['economia_total'] ?: 0);
            $valor_estimado_homologadas = floatval($economia_data['valor_estimado_homologadas'] ?: 0);

            // Calcular percentual de economia
            $economia_percentual = 0;
            if ($valor_estimado_homologadas > 0) {
                $economia_percentual = round(($economia_total / $valor_estimado_homologadas) * 100, 1);
            }

            // Formatação dos valores
            $valor_homologadas_formatado = 'R$ ' . number_format($stats_situacao['homologadas']['valor_homologado'], 2, ',', '.');
            $valor_andamento_formatado = 'R$ ' . number_format($stats_situacao['andamento']['valor_estimado'], 2, ',', '.');
            $valor_canceladas_formatado = 'R$ ' . number_format($stats_situacao['canceladas']['valor_estimado'], 2, ',', '.');
            $economia_total_formatado = 'R$ ' . number_format($economia_total, 2, ',', '.');

            echo json_encode([
                'success' => true,
                'estatisticas' => [
                    'total_licitacoes' => $total_licitacoes,
                    'valor_total_formatado' => $valor_total_formatado,
                    'valor_total_raw' => $valor_total_estimado,
                    // Dados por situação
                    'total_homologadas' => $stats_situacao['homologadas']['quantidade'],
                    'valor_homologadas_formatado' => $valor_homologadas_formatado,
                    'valor_homologadas_raw' => $stats_situacao['homologadas']['valor_homologado'],
                    'total_andamento' => $stats_situacao['andamento']['quantidade'],
                    'valor_andamento_formatado' => $valor_andamento_formatado,
                    'valor_andamento_raw' => $stats_situacao['andamento']['valor_estimado'],
                    'total_canceladas' => $stats_situacao['canceladas']['quantidade'],
                    'valor_canceladas_formatado' => $valor_canceladas_formatado,
                    'valor_canceladas_raw' => $stats_situacao['canceladas']['valor_estimado'],
                    // Dados de economia
                    'economia_total_formatado' => $economia_total_formatado,
                    'economia_total_raw' => $economia_total,
                    'economia_percentual' => $economia_percentual . '%'
                ]
            ]);
        } catch (Exception $e) {
            error_log("Erro no dashboard licitações: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao carregar estatísticas das licitações'
            ]);
        }
        exit;
        break;

    default:
        header('Location: index.php');
        break;
    }
?>