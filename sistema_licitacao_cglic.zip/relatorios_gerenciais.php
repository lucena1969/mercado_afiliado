<?php
require_once 'config.php';
require_once 'functions.php';

verificarLogin();

// VERIFICAR SE É COORDENADOR (NÍVEL 1) - ACESSO RESTRITO
if ($_SESSION['usuario_nivel'] != 1) {
    header('Location: selecao_modulos.php?erro=acesso_negado');
    exit;
}

$pdo = conectarDB();

// Determinar o módulo ativo (padrão: todos os módulos)
$modulo_ativo = $_GET['modulo'] ?? 'geral';
$modulos_disponiveis = [
    'geral' => 'Visão Geral do Sistema',
    'planejamento' => 'Planejamento (PCA)',
    'qualificacao' => 'Qualificação de Documentação',
    'licitacao' => 'Licitações e Pregões',
    'contratos' => 'Contratos Administrativos'
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios Gerenciais Executivos - Sistema CGLIC</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    
    <style>
        .dashboard-container {
            display: flex;
            min-height: 100vh;
            background: #f8fafc;
        }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            flex-shrink: 0;
            padding: 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 24px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-header h1 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 24px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .nav-item:hover, .nav-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .nav-item i {
            margin-right: 12px;
            width: 20px;
            height: 20px;
        }
        
        .main-content {
            flex: 1;
            padding: 24px;
            overflow-y: auto;
        }
        
        .header {
            background: white;
            padding: 24px;
            border-radius: 12px;
            margin-bottom: 24px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0 0 8px 0;
            color: #2d3748;
            font-size: 2rem;
        }
        
        .header p {
            margin: 0;
            color: #64748b;
        }
        
        /* Sistema de Abas */
        .tabs-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .tabs-header {
            display: flex;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .tab-button {
            flex: 1;
            padding: 16px 20px;
            border: none;
            background: transparent;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            color: #64748b;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .tab-button:hover {
            background: #e2e8f0;
            color: #2d3748;
        }
        
        .tab-button.active {
            background: white;
            color: #3b82f6;
            border-bottom-color: #3b82f6;
        }
        
        .tab-content {
            display: none;
            padding: 24px;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* Estilos de Formulários */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .form-group select,
        .form-group input {
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-actions {
            display: flex;
            gap: 12px;
            align-items: center;
            margin-top: 20px;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #4b5563;
        }
        
        /* Tabela de Resultados */
        .results-container {
            margin-top: 24px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .results-header {
            background: #f8fafc;
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .results-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
        }
        
        .export-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn-export {
            padding: 8px 16px;
            font-size: 12px;
            border: 1px solid #d1d5db;
            background: white;
            color: #4b5563;
        }
        
        .btn-export:hover {
            background: #f3f4f6;
        }
        
        .results-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .results-table th,
        .results-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .results-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #374151;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .results-table tbody tr:hover {
            background: #f9fafb;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-analise {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-concluido {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-arquivado {
            background: #f3f4f6;
            color: #374151;
        }

        /* ESTILOS ESPECÍFICOS DO PCA */
        .status-atraso {
            background: #fee2e2;
            color: #dc2626;
        }

        .status-preparacao {
            background: #fef3c7;
            color: #d97706;
        }

        .status-execucao {
            background: #dbeafe;
            color: #2563eb;
        }

        .status-encerrada {
            background: #d1fae5;
            color: #065f46;
        }

        .tem-licitacao {
            background: #e0f2fe;
            color: #0369a1;
            padding: 2px 6px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
        }

        .nao-tem-licitacao {
            background: #fef3c7;
            color: #92400e;
            padding: 2px 6px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
        }
        
        .valor {
            font-weight: 600;
            color: #059669;
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #6b7280;
        }

        /* MELHORIAS VISUAIS ESPECÍFICAS */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 24px;
            margin-bottom: 24px;
        }

        .chart-card {
            background: white;
            border-radius: 16px;
            padding: 32px 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
            min-height: 280px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .chart-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
            border-color: #3b82f6;
        }

        .chart-title {
            font-size: 20px;
            font-weight: 700;
            color: #1f2937;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .chart-title i {
            width: 24px;
            height: 24px;
            color: #3b82f6;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #1d4ed8, #1e40af);
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: #6b7280;
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-2px);
        }

        /* CSS Responsivo para Data Cards PCA */
        .pca-cards-grid {
            display: grid !important;
            grid-template-columns: repeat(6, 1fr) !important;
            gap: 15px !important;
            margin: 20px 0 !important;
        }

        /* Tablets */
        @media (max-width: 1200px) {
            .pca-cards-grid {
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 12px !important;
            }
        }

        /* Tablets pequenos */
        @media (max-width: 768px) {
            .pca-cards-grid {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 10px !important;
            }

            .pca-cards-grid > div {
                padding: 12px !important;
            }

            .pca-cards-grid h4 {
                font-size: 12px !important;
            }

            .pca-cards-grid > div > div {
                font-size: 24px !important;
            }
        }

        /* Smartphones */
        @media (max-width: 480px) {
            .pca-cards-grid {
                grid-template-columns: 1fr !important;
                gap: 8px !important;
                margin: 15px 0 !important;
            }

            .pca-cards-grid > div {
                padding: 10px !important;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h1>Relatórios Executivos</h1>
                <p>Sistema CGLIC - Visão Gerencial</p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="selecao_modulos.php" class="nav-item">
                    <i data-lucide="arrow-left"></i>
                    <span>Voltar ao Menu</span>
                </a>

                <div style="padding: 10px 20px; color: rgba(255,255,255,0.6); font-size: 12px; text-transform: uppercase; font-weight: 600;">Módulos do Sistema</div>

                <a href="?modulo=geral" class="nav-item <?php echo $modulo_ativo == 'geral' ? 'active' : ''; ?>">
                    <i data-lucide="bar-chart-4"></i>
                    <span>Visão Geral</span>
                </a>

                <a href="?modulo=planejamento" class="nav-item <?php echo $modulo_ativo == 'planejamento' ? 'active' : ''; ?>">
                    <i data-lucide="calendar-check"></i>
                    <span>Planejamento</span>
                </a>

                <a href="?modulo=qualificacao" class="nav-item <?php echo $modulo_ativo == 'qualificacao' ? 'active' : ''; ?>">
                    <i data-lucide="award"></i>
                    <span>Qualificação</span>
                </a>

                <a href="?modulo=licitacao" class="nav-item <?php echo $modulo_ativo == 'licitacao' ? 'active' : ''; ?>">
                    <i data-lucide="gavel"></i>
                    <span>Licitações</span>
                </a>

                <a href="?modulo=contratos" class="nav-item <?php echo $modulo_ativo == 'contratos' ? 'active' : ''; ?>">
                    <i data-lucide="file-text"></i>
                    <span>Contratos</span>
                </a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
                    <div>
                        <h1><?php echo $modulos_disponiveis[$modulo_ativo] ?? 'Módulo Desconhecido'; ?></h1>
                        <p><?php
                            switch($modulo_ativo) {
                                case 'geral':
                                    echo 'Visão consolidada de todos os módulos do sistema CGLIC';
                                    break;
                                case 'planejamento':
                                    echo 'Relatórios executivos do Plano de Contratações Anual (PCA)';
                                    break;
                                case 'qualificacao':
                                    echo 'Análise gerencial do processo de qualificação de documentação e artefatos licitatórios';
                                    break;
                                case 'licitacao':
                                    echo 'Relatórios gerenciais de licitações e pregões';
                                    break;
                                case 'contratos':
                                    echo 'Análise executiva de contratos administrativos';
                                    break;
                                default:
                                    echo 'Selecione um módulo na sidebar para visualizar os relatórios';
                            }
                        ?></p>
                    </div>

                    <?php if ($modulo_ativo == 'planejamento'): ?>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <label style="font-weight: 600; color: #2c3e50; white-space: nowrap;">
                            <i data-lucide="calendar-days" style="width: 18px; height: 18px; margin-right: 6px;"></i>
                            Ano do PCA:
                        </label>
                        <select id="ano_pca_header" style="padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 8px; font-weight: 500; min-width: 140px;" onchange="atualizarDashboardPorAno()">
                            <option value="2026">2026 (Atual)</option>
                            <option value="2025" selected>2025</option>
                            <option value="2024">2024 (Histórico)</option>
                            <option value="2023">2023 (Histórico)</option>
                            <option value="2022">2022 (Histórico)</option>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Conteúdo Dinâmico por Módulo -->
            <?php if ($modulo_ativo == 'geral'): ?>
            <div class="stats-grid">
                <div class="chart-card">
                    <h3 class="chart-title"><i data-lucide="bar-chart-4"></i> Dashboard Executivo</h3>
                    <p style="color: #7f8c8d; margin-bottom: 20px;">Visão consolidada de todos os módulos</p>
                    <div style="text-align: center;">
                        <i data-lucide="trending-up" style="width: 64px; height: 64px; color: #3b82f6; margin-bottom: 20px;"></i>
                        <button class="btn-primary" onclick="gerarDashboardExecutivo()">Gerar Dashboard</button>
                    </div>
                </div>

                <div class="chart-card">
                    <h3 class="chart-title"><i data-lucide="calendar-check"></i> Planejamento</h3>
                    <p style="color: #7f8c8d; margin-bottom: 20px;">Relatórios consolidados do PCA</p>
                    <div style="text-align: center;">
                        <i data-lucide="pie-chart" style="width: 64px; height: 64px; color: #1e3c72; margin-bottom: 20px;"></i>
                        <button class="btn-primary" onclick="window.location.href='?modulo=planejamento'">Acessar</button>
                    </div>
                </div>

                <div class="chart-card">
                    <h3 class="chart-title"><i data-lucide="award"></i> Qualificação</h3>
                    <p style="color: #7f8c8d; margin-bottom: 20px;">Qualificação de documentação e artefatos licitatórios</p>
                    <div style="text-align: center;">
                        <i data-lucide="users" style="width: 64px; height: 64px; color: #f59e0b; margin-bottom: 20px;"></i>
                        <button class="btn-primary" onclick="window.location.href='?modulo=qualificacao'">Acessar</button>
                    </div>
                </div>

                <div class="chart-card">
                    <h3 class="chart-title"><i data-lucide="gavel"></i> Licitações</h3>
                    <p style="color: #7f8c8d; margin-bottom: 20px;">Performance de processos licitatórios</p>
                    <div style="text-align: center;">
                        <i data-lucide="trending-up" style="width: 64px; height: 64px; color: #10b981; margin-bottom: 20px;"></i>
                        <button class="btn-primary" onclick="window.location.href='?modulo=licitacao'">Acessar</button>
                    </div>
                </div>

                <div class="chart-card">
                    <h3 class="chart-title"><i data-lucide="file-text"></i> Contratos</h3>
                    <p style="color: #7f8c8d; margin-bottom: 20px;">Gestão de contratos administrativos</p>
                    <div style="text-align: center;">
                        <i data-lucide="file-check" style="width: 64px; height: 64px; color: #dc2626; margin-bottom: 20px;"></i>
                        <button class="btn-primary" onclick="window.location.href='?modulo=contratos'">Acessar</button>
                    </div>
                </div>
            </div>

            <?php elseif ($modulo_ativo == 'qualificacao'): ?>
            <!-- Data Cards Executivos - Qualificações (Layout Compacto) -->
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin: 20px 0;">
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #1e3c72;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #1e3c72;"><i data-lucide="file-text" style="width: 16px; height: 16px;"></i> Total</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #1e3c72; margin: 5px 0;" id="total-processos-qual">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">processos</p>
                    <div style="font-size: 14px; font-weight: 600; color: #3b82f6; margin: 5px 0;" id="valor-total-qual">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #d97706;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #d97706;"><i data-lucide="search" style="width: 16px; height: 16px;"></i> 1ª Análise</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #d97706; margin: 5px 0;" id="total-primeira-analise">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">em análise</p>
                    <div style="font-size: 14px; font-weight: 600; color: #f59e0b; margin: 5px 0;" id="valor-primeira-analise">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #0369a1;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #0369a1;"><i data-lucide="eye" style="width: 16px; height: 16px;"></i> 2ª Análise</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #0369a1; margin: 5px 0;" id="total-segunda-analise">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">em revisão</p>
                    <div style="font-size: 14px; font-weight: 600; color: #0284c7; margin: 5px 0;" id="valor-segunda-analise">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #059669;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #059669;"><i data-lucide="check-circle" style="width: 16px; height: 16px;"></i> Concluídos</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #059669; margin: 5px 0;" id="total-concluidos">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">finalizados</p>
                    <div style="font-size: 14px; font-weight: 600; color: #10b981; margin: 5px 0;" id="valor-concluidos">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #6b7280;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #6b7280;"><i data-lucide="archive" style="width: 16px; height: 16px;"></i> Arquivados</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #6b7280; margin: 5px 0;" id="total-arquivados">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">arquivados</p>
                    <div style="font-size: 14px; font-weight: 600; color: #9ca3af; margin: 5px 0;" id="valor-arquivados">-</div>
                </div>
            </div>

            <!-- Sistema de Abas para Qualificações -->
            <div class="tabs-container">
                <div class="tabs-header">
                    <button class="tab-button active" onclick="showTab('filtros')">
                        <i data-lucide="filter"></i>
                        Filtros Gerais
                    </button>
                    <button class="tab-button" onclick="showTab('relatorio')">
                        <i data-lucide="file-text"></i>
                        Visualizar Relatório
                    </button>
                    <button class="tab-button" onclick="showTab('exportacao')">
                        <i data-lucide="download"></i>
                        Formato e Exportação
                    </button>
                </div>
                
                <!-- ABA 1: Filtros Gerais -->
                <div id="filtros" class="tab-content active">
                    <h3>📅 Período</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Início
                            </label>
                            <input type="date" id="data_inicio" name="data_inicio">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Fim
                            </label>
                            <input type="date" id="data_fim" name="data_fim">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="clock"></i>
                                Presets
                            </label>
                            <select id="preset_periodo" onchange="aplicarPreset()">
                                <option value="">Personalizado</option>
                                <option value="mes_atual">Mês Atual</option>
                                <option value="trimestre">Trimestre Atual</option>
                                <option value="ano">Ano Atual</option>
                                <option value="ultimo_mes">Último Mês</option>
                            </select>
                        </div>
                    </div>
                    
                    <h3>🏢 Filtros Específicos</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="building"></i>
                                Área Demandante
                            </label>
                            <select id="area_filtro" name="area_filtro">
                                <option value="">Todas as Áreas</option>
                                <!-- Preenchido via JavaScript -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="check-circle"></i>
                                Status
                            </label>
                            <select id="status_filtro" name="status_filtro">
                                <option value="">Todos os Status</option>
                                <option value="1ª ANÁLISE">1ª ANÁLISE</option>
                                <option value="2ª ANÁLISE">2ª ANÁLISE</option>
                                <option value="CONCLUÍDO">CONCLUÍDO</option>
                                <option value="ARQUIVADO">ARQUIVADO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="gavel"></i>
                                Modalidade
                            </label>
                            <select id="modalidade_filtro" name="modalidade_filtro">
                                <option value="">Todas as Modalidades</option>
                                <option value="PREGÃO">PREGÃO</option>
                                <option value="DISPENSA">DISPENSA</option>
                                <option value="INEXIBILIDADE">INEXIBILIDADE</option>
                            </select>
                        </div>
                    </div>
                    
                    <h3>💰 Faixa de Valores</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Mínimo
                            </label>
                            <input type="number" id="valor_minimo" name="valor_minimo" step="0.01" placeholder="0,00">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Máximo
                            </label>
                            <input type="number" id="valor_maximo" name="valor_maximo" step="0.01" placeholder="Sem limite">
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="aplicarFiltros()">
                            <i data-lucide="search"></i>
                            Aplicar Filtros
                        </button>
                        <button class="btn btn-secondary" onclick="limparFiltros()">
                            <i data-lucide="refresh-cw"></i>
                            Limpar Filtros
                        </button>
                    </div>
                </div>
                
                <!-- ABA 2: Relatório -->
                <div id="relatorio" class="tab-content">
                    <div id="loading" class="loading" style="display: none;">
                        <i data-lucide="loader" style="animation: spin 1s linear infinite;"></i>
                        <p>Carregando relatório...</p>
                    </div>
                    
                    <div id="results" style="display: none;">
                        <div class="results-container">
                            <div class="results-header">
                                <div class="results-title">Resultados do Relatório</div>
                                <div class="export-buttons">
                                    <button class="btn btn-export" onclick="exportarRelatorio('html')">
                                        <i data-lucide="eye"></i>
                                        HTML
                                    </button>
                                    <button class="btn btn-export" onclick="exportarRelatorio('excel')">
                                        <i data-lucide="file-spreadsheet"></i>
                                        Excel
                                    </button>
                                </div>
                            </div>
                            
                            <table class="results-table" id="tabela-resultados">
                                <thead>
                                    <tr>
                                        <th>NUP</th>
                                        <th>Área Demandante</th>
                                        <th>Modalidade</th>
                                        <th>Status</th>
                                        <th>Objeto (Resumo)</th>
                                        <th>Valor Estimado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Preenchido via JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- ABA 3: Exportação -->
                <div id="exportacao" class="tab-content">
                    <h3>📄 Formato de Saída</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Formato Principal</label>
                            <select id="formato_principal">
                                <option value="html">HTML (Visualização)</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (Excel compatível)</option>
                            </select>
                        </div>
                    </div>
                    
                    <h3>📊 Opções de Conteúdo</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_graficos" checked>
                                Incluir Gráficos Estatísticos
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_detalhes" checked>
                                Dados Detalhados
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_filtros">
                                Incluir Filtros Aplicados
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="gerarRelatorioFinal()">
                            <i data-lucide="download"></i>
                            Exportar Relatório
                        </button>
                    </div>
                </div>
            </div>

            <?php elseif ($modulo_ativo == 'planejamento'): ?>
            <!-- Dashboard Executivo PCA -->
            <!-- Data Cards Executivos - Planejamento PCA (Layout Compacto) -->
            <div id="dashboard-pca" style="display: none;">
                <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 15px; margin: 20px 0;" class="pca-cards-grid">
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #1e3c72;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #1e3c72;"><i data-lucide="calendar-check" style="width: 16px; height: 16px;"></i> Total</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #1e3c72; margin: 5px 0;" id="total-contratacoes">-</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">contratações</p>
                        <div style="font-size: 14px; font-weight: 600; color: #3b82f6; margin: 5px 0;" id="valor-total-pca">-</div>
                    </div>

                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #059669;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #059669;"><i data-lucide="trending-up" style="width: 16px; height: 16px;"></i> Licitação</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #059669; margin: 5px 0;"><span id="percentual-licitados">-</span>%</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">com processo</p>
                        <div style="font-size: 14px; font-weight: 600; color: #10b981; margin: 5px 0;">-</div>
                    </div>

                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #0369a1;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #0369a1;"><i data-lucide="check-square" style="width: 16px; height: 16px;"></i> Aprovadas</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #0369a1; margin: 5px 0;" id="total-aprovadas">-</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">aprovadas</p>
                        <div style="font-size: 14px; font-weight: 600; color: #0284c7; margin: 5px 0;" id="valor-aprovadas">-</div>
                    </div>

                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #dc2626;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #dc2626;"><i data-lucide="alert-triangle" style="width: 16px; height: 16px;"></i> Em Atraso</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #dc2626; margin: 5px 0;" id="total-atraso">-</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">não iniciadas</p>
                        <div style="font-size: 14px; font-weight: 600; color: #ef4444; margin: 5px 0;" id="valor-atraso">-</div>
                    </div>

                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #d97706;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #d97706;"><i data-lucide="clock" style="width: 16px; height: 16px;"></i> Preparação</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #d97706; margin: 5px 0;" id="total-preparacao">-</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">em preparação</p>
                        <div style="font-size: 14px; font-weight: 600; color: #f59e0b; margin: 5px 0;" id="valor-preparacao">-</div>
                    </div>

                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #059669;">
                        <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #059669;"><i data-lucide="check-circle" style="width: 16px; height: 16px;"></i> Encerradas</h4>
                        <div style="font-size: 28px; font-weight: bold; color: #059669; margin: 5px 0;" id="total-encerradas">-</div>
                        <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">finalizadas</p>
                        <div style="font-size: 14px; font-weight: 600; color: #10b981; margin: 5px 0;" id="valor-encerradas">-</div>
                    </div>
                </div>
            </div>

            <!-- Sistema de Abas para Planejamento - MESMO MODELO QUALIFICAÇÕES -->
            <div class="tabs-container">
                <div class="tabs-header">
                    <button class="tab-button active" onclick="showTab('filtros')">
                        <i data-lucide="filter"></i>
                        Filtros Gerais
                    </button>
                    <button class="tab-button" onclick="showTab('relatorio')">
                        <i data-lucide="file-text"></i>
                        Visualizar Relatório
                    </button>
                    <button class="tab-button" onclick="showTab('exportacao')">
                        <i data-lucide="download"></i>
                        Formato e Exportação
                    </button>
                </div>

                <!-- ABA 1: Filtros Gerais -->
                <div id="filtros" class="tab-content active">
                    <h3>📅 Período</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Início
                            </label>
                            <input type="date" id="data_inicio" name="data_inicio">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Fim
                            </label>
                            <input type="date" id="data_fim" name="data_fim">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="clock"></i>
                                Presets
                            </label>
                            <select id="preset_periodo" onchange="aplicarPreset()">
                                <option value="">Personalizado</option>
                                <option value="mes_atual">Mês Atual</option>
                                <option value="trimestre">Trimestre Atual</option>
                                <option value="ano">Ano Atual</option>
                                <option value="ultimo_mes">Último Mês</option>
                            </select>
                        </div>
                    </div>

                    <h3>📋 Filtros Específicos - Execução PCA</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="building"></i>
                                Área Requisitante
                            </label>
                            <select id="area_requisitante_filtro" name="area_requisitante_filtro">
                                <option value="">🔄 Carregando áreas...</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="building-2"></i>
                                Coordenações SAA (2º Nível)
                            </label>
                            <select id="coordenacao_saa_filtro" name="coordenacao_saa_filtro" onchange="filtrarPorCoordenacaoSAA()">
                                <option value="">Todas as Coordenações</option>
                                <optgroup label="8 Coordenações SAA - Segundo Nível">
                                    <option value="SAA.CGDI">SAA.CGDI (Coordenação Geral de Documentação e Informação)</option>
                                    <option value="SAA.CGINFRA">SAA.CGINFRA (Coordenação Geral de Infraestrutura)</option>
                                    <option value="SAA.CGSA">SAA.CGSA (Coordenação Geral de Saúde)</option>
                                    <option value="SAA.CGOF">SAA.CGOF (Coordenação Geral de Orçamento e Finanças)</option>
                                    <option value="SAA.COGEP">SAA.COGEP (Coordenação Geral de Planejamento)</option>
                                    <option value="SAA.CGCON">SAA.CGCON (Coordenação Geral de Contratos)</option>
                                    <option value="SAA.COGAD">SAA.COGAD (Coordenação Geral Administrativa)</option>
                                    <option value="SAA.CGENG">SAA.CGENG (Coordenação Geral de Engenharia)</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="list"></i>
                                Categoria da Contratação
                            </label>
                            <select id="categoria_filtro" name="categoria_filtro">
                                <option value="">Todas as Categorias</option>
                                <option value="BENS">BENS</option>
                                <option value="SERVICOS">SERVIÇOS</option>
                                <option value="CONTRATACOES_TIC">CONTRATAÇÕES TIC</option>
                                <option value="OBRAS_SERV_ESP_ENGENHARIA">OBRAS/SERV. ESP. ENGENHARIA</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="activity"></i>
                                Status de Execução
                            </label>
                            <select id="status_execucao_filtro" name="status_execucao_filtro">
                                <option value="">Todos os Status</option>
                                <option value="EM ATRASO">🔴 EM ATRASO</option>
                                <option value="EM EXECUÇÃO">🟡 EM EXECUÇÃO</option>
                                <option value="EXECUTADO">🟢 EXECUTADO</option>
                                <option value="NÃO EXECUTADO">⚫ NÃO EXECUTADO</option>
                            </select>
                        </div>
                    </div>

                    <h3>📊 Relatórios Específicos SAA</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="folder-open"></i>
                                DFDs Abertos por Coordenação
                            </label>
                            <button class="btn btn-primary" style="width: 100%;" onclick="gerarRelatorioSAA('dfds_abertos')">
                                <i data-lucide="file-text"></i>
                                Gerar Relatório
                            </button>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="alert-circle"></i>
                                DFDs Não Iniciados por Coordenação
                            </label>
                            <button class="btn btn-primary" style="width: 100%;" onclick="gerarRelatorioSAA('dfds_nao_iniciados')">
                                <i data-lucide="file-text"></i>
                                Gerar Relatório
                            </button>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="activity"></i>
                                DFDs Em Andamento por Coordenação
                            </label>
                            <button class="btn btn-primary" style="width: 100%;" onclick="gerarRelatorioSAA('dfds_em_andamento')">
                                <i data-lucide="file-text"></i>
                                Gerar Relatório
                            </button>
                        </div>
                    </div>

                    <h3>📊 Filtros de Status</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="check-circle"></i>
                                Status da Contratação
                            </label>
                            <select id="status_contratacao_filtro" name="status_contratacao_filtro">
                                <option value="">Todos os Status</option>
                                <option value="Aprovada">✅ Aprovada</option>
                                <option value="Aguardando Aprovação">⏳ Aguardando Aprovação</option>
                                <option value="Rascunho">📝 Rascunho</option>
                                <option value="Devolvida">🔄 Devolvida</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="alert-triangle"></i>
                                Situação de Execução Original
                            </label>
                            <select id="situacao_original_filtro" name="situacao_original_filtro">
                                <option value="">Todas as Situações</option>
                                <option value="Não iniciado">🔴 Não iniciado</option>
                                <option value="Preparação">🟡 Preparação</option>
                                <option value="Edição">🟠 Edição</option>
                                <option value="Encerrada">🟢 Encerrada</option>
                                <option value="Revogada">⚫ Revogada</option>
                                <option value="Anulada">❌ Anulada</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="link"></i>
                                Possui Licitação
                            </label>
                            <select id="tem_licitacao_filtro" name="tem_licitacao_filtro">
                                <option value="">Todos</option>
                                <option value="SIM">✅ Com Licitação</option>
                                <option value="NAO">❌ Sem Licitação</option>
                            </select>
                        </div>
                    </div>

                    <h3>💰 Faixa de Valores</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Mínimo
                            </label>
                            <input type="number" id="valor_minimo" name="valor_minimo" step="0.01" placeholder="0,00">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Máximo
                            </label>
                            <input type="number" id="valor_maximo" name="valor_maximo" step="0.01" placeholder="Sem limite">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="aplicarFiltros()">
                            <i data-lucide="search"></i>
                            Aplicar Filtros
                        </button>
                        <button class="btn btn-secondary" onclick="limparFiltros()">
                            <i data-lucide="refresh-cw"></i>
                            Limpar Filtros
                        </button>
                    </div>
                </div>

                <!-- ABA 2: Relatório -->
                <div id="relatorio" class="tab-content">
                    <div id="loading" class="loading" style="display: none;">
                        <i data-lucide="loader" style="animation: spin 1s linear infinite;"></i>
                        <p>Carregando relatório...</p>
                    </div>

                    <div id="results" style="display: none;">
                        <div class="results-container">
                            <div class="results-header">
                                <div class="results-title">Resultados do Relatório</div>
                                <div class="export-buttons">
                                    <button class="btn btn-export" onclick="exportarRelatorio('html')">
                                        <i data-lucide="eye"></i>
                                        HTML
                                    </button>
                                    <button class="btn btn-export" onclick="exportarRelatorio('excel')">
                                        <i data-lucide="file-spreadsheet"></i>
                                        Excel
                                    </button>
                                </div>
                            </div>

                            <table class="results-table" id="tabela-resultados">
                                <thead>
                                    <tr>
                                        <th>Nº Contratação</th>
                                        <th>Título (Resumo)</th>
                                        <th>Categoria</th>
                                        <th>Área Requisitante</th>
                                        <th>Status Execução</th>
                                        <th>Valor Total</th>
                                        <th>Dias Atraso</th>
                                        <th>Tem Licitação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Preenchido via JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ABA 3: Exportação -->
                <div id="exportacao" class="tab-content">
                    <h3>📄 Formato de Saída</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Formato Principal</label>
                            <select id="formato_principal">
                                <option value="html">HTML (Visualização)</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (Excel compatível)</option>
                            </select>
                        </div>
                    </div>

                    <h3>📊 Opções de Conteúdo</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_graficos" checked>
                                Incluir Gráficos Estatísticos
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_detalhes" checked>
                                Dados Detalhados
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_filtros">
                                Incluir Filtros Aplicados
                            </label>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="gerarRelatorioFinal()">
                            <i data-lucide="download"></i>
                            Exportar Relatório
                        </button>
                    </div>
                </div>
            </div>

            <?php elseif ($modulo_ativo == 'licitacao'): ?>
            <!-- Data Cards Executivos - Licitações (Layout Compacto) -->
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin: 20px 0;">
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #1e3c72;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #1e3c72;"><i data-lucide="gavel" style="width: 16px; height: 16px;"></i> Total</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #1e3c72; margin: 5px 0;" id="total-licitacoes">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">licitações</p>
                    <div style="font-size: 14px; font-weight: 600; color: #3b82f6; margin: 5px 0;" id="valor-total-licitacoes">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #059669;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #059669;"><i data-lucide="check-circle" style="width: 16px; height: 16px;"></i> Homologadas</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #059669; margin: 5px 0;" id="total-homologadas">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">concluídas</p>
                    <div style="font-size: 14px; font-weight: 600; color: #10b981; margin: 5px 0;" id="valor-homologadas">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #d97706;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #d97706;"><i data-lucide="clock" style="width: 16px; height: 16px;"></i> Em Andamento</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #d97706; margin: 5px 0;" id="total-andamento">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">em processo</p>
                    <div style="font-size: 14px; font-weight: 600; color: #f59e0b; margin: 5px 0;" id="valor-andamento">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #16a34a; position: relative;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #16a34a;"><i data-lucide="trending-down" style="width: 16px; height: 16px;"></i> Economia</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #16a34a; margin: 5px 0;" id="economia-total">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">economizada</p>
                    <div style="font-size: 14px; font-weight: 600; color: #15803d; margin: 5px 0;" id="economia-percentual">-</div>
                </div>

                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; border-left: 4px solid #dc2626;">
                    <h4 style="margin: 0 0 8px 0; font-size: 14px; color: #dc2626;"><i data-lucide="x-circle" style="width: 16px; height: 16px;"></i> Canceladas</h4>
                    <div style="font-size: 28px; font-weight: bold; color: #dc2626; margin: 5px 0;" id="total-canceladas">-</div>
                    <p style="color: #7f8c8d; margin: 3px 0; font-size: 11px;">revogadas</p>
                    <div style="font-size: 14px; font-weight: 600; color: #ef4444; margin: 5px 0;" id="valor-canceladas">-</div>
                </div>
            </div>

            <!-- Sistema de Abas para Licitações - MESMO MODELO QUALIFICAÇÕES -->
            <div class="tabs-container">
                <div class="tabs-header">
                    <button class="tab-button active" onclick="showTab('filtros')">
                        <i data-lucide="filter"></i>
                        Filtros Gerais
                    </button>
                    <button class="tab-button" onclick="showTab('relatorio')">
                        <i data-lucide="file-text"></i>
                        Visualizar Relatório
                    </button>
                    <button class="tab-button" onclick="showTab('exportacao')">
                        <i data-lucide="download"></i>
                        Formato e Exportação
                    </button>
                </div>

                <!-- ABA 1: Filtros Gerais -->
                <div id="filtros" class="tab-content active">
                    <h3>📅 Período</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Início
                            </label>
                            <input type="date" id="data_inicio" name="data_inicio">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Fim
                            </label>
                            <input type="date" id="data_fim" name="data_fim">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="clock"></i>
                                Presets
                            </label>
                            <select id="preset_periodo" onchange="aplicarPreset()">
                                <option value="">Personalizado</option>
                                <option value="mes_atual">Mês Atual</option>
                                <option value="trimestre">Trimestre Atual</option>
                                <option value="ano">Ano Atual</option>
                                <option value="ultimo_mes">Último Mês</option>
                            </select>
                        </div>
                    </div>

                    <h3>⚖️ Filtros Específicos</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="gavel"></i>
                                Modalidade
                            </label>
                            <select id="modalidade_filtro" name="modalidade_filtro">
                                <option value="">Todas as Modalidades</option>
                                <option value="PREGÃO ELETRÔNICO">PREGÃO ELETRÔNICO</option>
                                <option value="PREGÃO PRESENCIAL">PREGÃO PRESENCIAL</option>
                                <option value="CONCORRÊNCIA">CONCORRÊNCIA</option>
                                <option value="DISPENSA">DISPENSA</option>
                                <option value="INEXIBILIDADE">INEXIBILIDADE</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="check-circle"></i>
                                Status da Licitação
                            </label>
                            <select id="status_filtro" name="status_filtro">
                                <option value="">Todos os Status</option>
                                <option value="PLANEJAMENTO">PLANEJAMENTO</option>
                                <option value="PUBLICADO">PUBLICADO</option>
                                <option value="EM ANDAMENTO">EM ANDAMENTO</option>
                                <option value="SUSPENSO">SUSPENSO</option>
                                <option value="HOMOLOGADO">HOMOLOGADO</option>
                                <option value="REVOGADO">REVOGADO</option>
                                <option value="ANULADO">ANULADO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="user-check"></i>
                                Pregoeiro
                            </label>
                            <select id="pregoeiro_filtro" name="pregoeiro_filtro">
                                <option value="">Todos os Pregoeiros</option>
                            </select>
                        </div>
                    </div>

                    <h3>💰 Faixa de Valores</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Mínimo
                            </label>
                            <input type="number" id="valor_minimo" name="valor_minimo" step="0.01" placeholder="0,00">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Máximo
                            </label>
                            <input type="number" id="valor_maximo" name="valor_maximo" step="0.01" placeholder="Sem limite">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="aplicarFiltros()">
                            <i data-lucide="search"></i>
                            Aplicar Filtros
                        </button>
                        <button class="btn btn-secondary" onclick="limparFiltros()">
                            <i data-lucide="refresh-cw"></i>
                            Limpar Filtros
                        </button>
                    </div>
                </div>

                <!-- ABA 2: Relatório -->
                <div id="relatorio" class="tab-content">
                    <div id="loading" class="loading" style="display: none;">
                        <i data-lucide="loader" style="animation: spin 1s linear infinite;"></i>
                        <p>Carregando relatório...</p>
                    </div>

                    <div id="results" style="display: none;">
                        <div class="results-container">
                            <div class="results-header">
                                <div class="results-title">Resultados do Relatório</div>
                                <div class="export-buttons">
                                    <button class="btn btn-export" onclick="exportarRelatorio('html')">
                                        <i data-lucide="eye"></i>
                                        HTML
                                    </button>
                                    <button class="btn btn-export" onclick="exportarRelatorio('excel')">
                                        <i data-lucide="file-spreadsheet"></i>
                                        Excel
                                    </button>
                                </div>
                            </div>

                            <table class="results-table" id="tabela-resultados">
                                <thead>
                                    <tr>
                                        <th>Número</th>
                                        <th>Modalidade</th>
                                        <th>Status</th>
                                        <th>Objeto (Resumo)</th>
                                        <th>Valor Estimado</th>
                                        <th>Pregoeiro</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Preenchido via JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ABA 3: Exportação -->
                <div id="exportacao" class="tab-content">
                    <h3>📄 Formato de Saída</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Formato Principal</label>
                            <select id="formato_principal">
                                <option value="html">HTML (Visualização)</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (Excel compatível)</option>
                            </select>
                        </div>
                    </div>

                    <h3>📊 Opções de Conteúdo</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_graficos" checked>
                                Incluir Gráficos Estatísticos
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_detalhes" checked>
                                Dados Detalhados
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_filtros">
                                Incluir Filtros Aplicados
                            </label>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="gerarRelatorioFinal()">
                            <i data-lucide="download"></i>
                            Exportar Relatório
                        </button>
                    </div>
                </div>
            </div>

            <?php elseif ($modulo_ativo == 'contratos'): ?>
            <!-- Sistema de Abas para Contratos - MESMO MODELO QUALIFICAÇÕES -->
            <div class="tabs-container">
                <div class="tabs-header">
                    <button class="tab-button active" onclick="showTab('filtros')">
                        <i data-lucide="filter"></i>
                        Filtros Gerais
                    </button>
                    <button class="tab-button" onclick="showTab('relatorio')">
                        <i data-lucide="file-text"></i>
                        Visualizar Relatório
                    </button>
                    <button class="tab-button" onclick="showTab('exportacao')">
                        <i data-lucide="download"></i>
                        Formato e Exportação
                    </button>
                </div>

                <!-- ABA 1: Filtros Gerais -->
                <div id="filtros" class="tab-content active">
                    <h3>📅 Período</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Início
                            </label>
                            <input type="date" id="data_inicio" name="data_inicio">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="calendar"></i>
                                Data Fim
                            </label>
                            <input type="date" id="data_fim" name="data_fim">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="clock"></i>
                                Presets
                            </label>
                            <select id="preset_periodo" onchange="aplicarPreset()">
                                <option value="">Personalizado</option>
                                <option value="mes_atual">Mês Atual</option>
                                <option value="trimestre">Trimestre Atual</option>
                                <option value="ano">Ano Atual</option>
                                <option value="ultimo_mes">Último Mês</option>
                            </select>
                        </div>
                    </div>

                    <h3>📋 Filtros Específicos</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="building-2"></i>
                                Fornecedor
                            </label>
                            <select id="fornecedor_filtro" name="fornecedor_filtro">
                                <option value="">Todos os Fornecedores</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="check-circle"></i>
                                Status do Contrato
                            </label>
                            <select id="status_filtro" name="status_filtro">
                                <option value="">Todos os Status</option>
                                <option value="VIGENTE">VIGENTE</option>
                                <option value="SUSPENSO">SUSPENSO</option>
                                <option value="ENCERRADO">ENCERRADO</option>
                                <option value="RESCINDIDO">RESCINDIDO</option>
                                <option value="VENCIDO">VENCIDO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="file-text"></i>
                                Tipo de Contrato
                            </label>
                            <select id="tipo_filtro" name="tipo_filtro">
                                <option value="">Todos os Tipos</option>
                                <option value="FORNECIMENTO">FORNECIMENTO</option>
                                <option value="SERVIÇOS">SERVIÇOS</option>
                                <option value="OBRAS">OBRAS</option>
                                <option value="LOCAÇÃO">LOCAÇÃO</option>
                            </select>
                        </div>
                    </div>

                    <h3>💰 Faixa de Valores</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Mínimo
                            </label>
                            <input type="number" id="valor_minimo" name="valor_minimo" step="0.01" placeholder="0,00">
                        </div>
                        <div class="form-group">
                            <label>
                                <i data-lucide="dollar-sign"></i>
                                Valor Máximo
                            </label>
                            <input type="number" id="valor_maximo" name="valor_maximo" step="0.01" placeholder="Sem limite">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="aplicarFiltros()">
                            <i data-lucide="search"></i>
                            Aplicar Filtros
                        </button>
                        <button class="btn btn-secondary" onclick="limparFiltros()">
                            <i data-lucide="refresh-cw"></i>
                            Limpar Filtros
                        </button>
                    </div>
                </div>

                <!-- ABA 2: Relatório -->
                <div id="relatorio" class="tab-content">
                    <div id="loading" class="loading" style="display: none;">
                        <i data-lucide="loader" style="animation: spin 1s linear infinite;"></i>
                        <p>Carregando relatório...</p>
                    </div>

                    <div id="results" style="display: none;">
                        <div class="results-container">
                            <div class="results-header">
                                <div class="results-title">Resultados do Relatório</div>
                                <div class="export-buttons">
                                    <button class="btn btn-export" onclick="exportarRelatorio('html')">
                                        <i data-lucide="eye"></i>
                                        HTML
                                    </button>
                                    <button class="btn btn-export" onclick="exportarRelatorio('excel')">
                                        <i data-lucide="file-spreadsheet"></i>
                                        Excel
                                    </button>
                                </div>
                            </div>

                            <table class="results-table" id="tabela-resultados">
                                <thead>
                                    <tr>
                                        <th>Número</th>
                                        <th>Fornecedor</th>
                                        <th>Status</th>
                                        <th>Objeto (Resumo)</th>
                                        <th>Valor do Contrato</th>
                                        <th>Vigência</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Preenchido via JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ABA 3: Exportação -->
                <div id="exportacao" class="tab-content">
                    <h3>📄 Formato de Saída</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Formato Principal</label>
                            <select id="formato_principal">
                                <option value="html">HTML (Visualização)</option>
                                <option value="excel">Excel (.xlsx)</option>
                                <option value="csv">CSV (Excel compatível)</option>
                            </select>
                        </div>
                    </div>

                    <h3>📊 Opções de Conteúdo</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_graficos" checked>
                                Incluir Gráficos Estatísticos
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_detalhes" checked>
                                Dados Detalhados
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="incluir_filtros">
                                Incluir Filtros Aplicados
                            </label>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" onclick="gerarRelatorioFinal()">
                            <i data-lucide="download"></i>
                            Exportar Relatório
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
    
    <script>
        // Inicializar ícones Lucide
        lucide.createIcons();
        
        // Controle de Abas
        function showTab(tabId) {
            try {
                console.log('Showing tab:', tabId);
                
                // Esconder todas as abas
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Remover classe active de todos os botões
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Mostrar aba selecionada
                const tabElement = document.getElementById(tabId);
                if (tabElement) {
                    tabElement.classList.add('active');
                } else {
                    console.error('Tab element not found:', tabId);
                }
                
                // Ativar botão correspondente de forma mais robusta
                const tabMapping = {
                    'filtros': 0,
                    'relatorio': 1,
                    'exportacao': 2
                };
                
                const buttons = document.querySelectorAll('.tab-button');
                const targetIndex = tabMapping[tabId];
                
                if (targetIndex !== undefined && buttons[targetIndex]) {
                    buttons[targetIndex].classList.add('active');
                }
                
                // Re-inicializar ícones
                lucide.createIcons();
                
            } catch (error) {
                console.error('Erro na função showTab:', error);
            }
        }
        
        // Aplicar presets de período
        function aplicarPreset() {
            const preset = document.getElementById('preset_periodo').value;
            const hoje = new Date();
            
            if (preset === 'mes_atual') {
                const inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
                const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
                
                document.getElementById('data_inicio').value = inicio.toISOString().split('T')[0];
                document.getElementById('data_fim').value = fim.toISOString().split('T')[0];
            }
            // Adicionar outros presets conforme necessário
        }
        
        // Carregar áreas demandantes
        function carregarAreas() {
            fetch('process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'acao=relatorio_area_demandante'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.filtros.areas_disponiveis) {
                    const select = document.getElementById('area_filtro');
                    data.data.filtros.areas_disponiveis.forEach(area => {
                        const option = document.createElement('option');
                        option.value = area;
                        option.textContent = area;
                        select.appendChild(option);
                    });
                }
            })
            .catch(error => {
                console.error('Erro ao carregar áreas:', error);
            });
        }
        
        // Aplicar filtros e gerar relatório - ESPECÍFICO PARA PCA
        function aplicarFiltros() {
            try {
                console.log('Iniciando aplicação de filtros para PCA...');

                document.getElementById('loading').style.display = 'block';
                document.getElementById('results').style.display = 'none';

                // Determinar qual módulo está ativo
                const urlParams = new URLSearchParams(window.location.search);
                const modulo = urlParams.get('modulo') || 'geral';

                // Coletar dados do formulário baseado no módulo
                const formData = new FormData();

                if (modulo === 'planejamento') {
                    // RELATÓRIO ESPECÍFICO DE EXECUÇÃO PCA
                    formData.append('acao', 'relatorio_execucao_pca');
                    formData.append('ano', document.getElementById('ano_pca_header').value); // CORRIGIDO - envia ano selecionado do header
                    formData.append('data_inicio', document.getElementById('data_inicio').value);
                    formData.append('data_fim', document.getElementById('data_fim').value);
                    formData.append('area_requisitante_filtro', document.getElementById('area_requisitante_filtro').value);
                    formData.append('categoria_filtro', document.getElementById('categoria_filtro').value);
                    formData.append('status_execucao_filtro', document.getElementById('status_execucao_filtro').value);
                    formData.append('status_contratacao_filtro', document.getElementById('status_contratacao_filtro').value);
                    formData.append('situacao_original_filtro', document.getElementById('situacao_original_filtro').value);
                    formData.append('tem_licitacao_filtro', document.getElementById('tem_licitacao_filtro').value);
                    formData.append('valor_minimo', document.getElementById('valor_minimo').value);
                    formData.append('valor_maximo', document.getElementById('valor_maximo').value);
                } else if (modulo === 'qualificacao') {
                    // RELATÓRIO DE QUALIFICAÇÕES (ORIGINAL)
                    formData.append('acao', 'relatorio_area_demandante');
                    formData.append('data_inicio', document.getElementById('data_inicio').value);
                    formData.append('data_fim', document.getElementById('data_fim').value);
                    formData.append('area_filtro', document.getElementById('area_filtro')?.value || '');
                    formData.append('status_filtro', document.getElementById('status_filtro')?.value || '');
                    formData.append('modalidade_filtro', document.getElementById('modalidade_filtro')?.value || '');
                    formData.append('valor_minimo', document.getElementById('valor_minimo').value);
                    formData.append('valor_maximo', document.getElementById('valor_maximo').value);
                } else {
                    alert('Módulo não suportado ainda: ' + modulo);
                    document.getElementById('loading').style.display = 'none';
                    return;
                }

                console.log('Enviando dados para:', formData.get('acao'));

                // SOLUÇÃO COM FALLBACK PARA PCA
                let endpointUrl = 'process.php';
                let isPlanning = modulo === 'planejamento';

                if (isPlanning) {
                    // Para planejamento, tentar endpoint alternativo primeiro
                    endpointUrl = 'relatorio_pca_alternativo.php';
                    console.log('Usando endpoint alternativo para PCA:', endpointUrl);
                }

                fetch(endpointUrl, {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    console.log('Resposta recebida, status:', response.status);
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }

                    // Verificar se a resposta é JSON válido
                    return response.text().then(text => {
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            console.error('Resposta não é JSON válido:', text.substring(0, 500));
                            throw new Error('Resposta inválida do servidor (não é JSON)');
                        }
                    });
                })
                .catch(error => {
                    console.error('Erro no endpoint principal:', error);

                    // FALLBACK: Se falhar e for planejamento, tentar process.php
                    if (isPlanning && endpointUrl !== 'process.php') {
                        console.log('Tentando fallback para process.php...');
                        return fetch('process.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => {
                            console.log('Resposta fallback, status:', response.status);
                            if (!response.ok) {
                                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                            }

                            // Verificar se a resposta é JSON válido
                            return response.text().then(text => {
                                try {
                                    return JSON.parse(text);
                                } catch (e) {
                                    console.error('Resposta fallback não é JSON válido:', text.substring(0, 500));
                                    throw new Error('Resposta inválida do servidor (não é JSON)');
                                }
                            });
                        });
                    } else {
                        throw error;
                    }
                })
                .then(data => {
                    console.log('Dados recebidos:', data);
                    document.getElementById('loading').style.display = 'none';

                    if (data.success) {
                        if (modulo === 'planejamento') {
                            preencherTabelaPCA(data.data);
                        } else {
                            preencherTabela(data.data);
                        }
                        document.getElementById('results').style.display = 'block';
                        showTab('relatorio');
                    } else {
                        console.error('Erro do servidor:', data.message);
                        alert('Erro ao gerar relatório: ' + (data.message || 'Erro desconhecido'));
                    }
                })
                .catch(error => {
                    document.getElementById('loading').style.display = 'none';
                    console.error('Erro detalhado:', error);
                    alert('Erro ao gerar relatório: ' + error.message + '\nVerifique o console para mais detalhes.');
                });
            } catch (error) {
                document.getElementById('loading').style.display = 'none';
                console.error('Erro na função aplicarFiltros:', error);
                alert('Erro interno na aplicação: ' + error.message);
            }
        }

        // Preencher tabela específica para PCA (Execução do Planejamento)
        function preencherTabelaPCA(data) {
            try {
                console.log('Preenchendo tabela PCA com dados:', data);

                const tbody = document.querySelector('#tabela-resultados tbody');
                if (!tbody) {
                    throw new Error('Elemento tbody da tabela não encontrado');
                }

                tbody.innerHTML = ''; // Limpar tabela

                if (!data.resultados || data.resultados.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 20px; color: #6b7280;">Nenhum resultado encontrado com os filtros aplicados</td></tr>';
                    return;
                }

                data.resultados.forEach((item, index) => {
                    try {
                        const row = document.createElement('tr');

                        // Definir classes CSS para status
                        let statusClass = 'status-analise';
                        let statusEmoji = '';

                        switch(item.status_execucao_ajustado) {
                            case 'EM ATRASO':
                                statusClass = 'status-atraso';
                                statusEmoji = '🔴';
                                break;
                            case 'EM EXECUÇÃO':
                                statusClass = 'status-execucao';
                                statusEmoji = '🟡';
                                break;
                            case 'EXECUTADO':
                                statusClass = 'status-executado';
                                statusEmoji = '🟢';
                                break;
                            case 'NÃO EXECUTADO':
                                statusClass = 'status-nao-executado';
                                statusEmoji = '⚫';
                                break;
                        }

                        // Badge para "Tem Licitação"
                        let licitacaoBadge = '';
                        if (item.tem_licitacao === 'SIM') {
                            licitacaoBadge = '<span style="background: #10b981; color: white; padding: 2px 6px; border-radius: 4px; font-size: 11px;">✅ SIM</span>';
                        } else {
                            licitacaoBadge = '<span style="background: #ef4444; color: white; padding: 2px 6px; border-radius: 4px; font-size: 11px;">❌ NÃO</span>';
                        }

                        // Exibir dias de atraso apenas se > 0
                        let diasAtrasoDisplay = '';
                        if (item.dias_atraso > 0) {
                            diasAtrasoDisplay = `${item.dias_atraso} dias`;
                        } else {
                            diasAtrasoDisplay = '-';
                        }

                        row.innerHTML = `
                            <td>${item.numero_contratacao || '-'}</td>
                            <td title="${item.titulo_contratacao || ''}">${(item.titulo_contratacao || '').substring(0, 60)}...</td>
                            <td>${item.categoria_contratacao || '-'}</td>
                            <td title="${item.area_requisitante || ''}">${(item.area_requisitante || '').substring(0, 30)}...</td>
                            <td><span class="status-badge ${statusClass}">${statusEmoji} ${item.status_execucao_ajustado || '-'}</span></td>
                            <td class="valor">${item.valor_formatado || 'R$ 0,00'}</td>
                            <td style="text-align: center; color: ${item.dias_atraso > 0 ? '#dc2626' : '#6b7280'}">${diasAtrasoDisplay}</td>
                            <td>${licitacaoBadge}</td>
                        `;

                        tbody.appendChild(row);
                    } catch (rowError) {
                        console.error('Erro ao processar linha', index, ':', rowError, 'Item:', item);
                    }
                });

                // Atualizar título com estatísticas
                const titleElement = document.querySelector('.results-title');
                if (titleElement && data.estatisticas) {
                    const stats = data.estatisticas;
                    titleElement.innerHTML = `
                        <div>
                            <strong>Execução do PCA: ${stats.total_registros || 0} contratações</strong><br>
                            <small style="color: #6b7280;">
                                Total: ${stats.valor_total_formatado || 'R$ 0,00'} |
                                Em Atraso: ${stats.contadores.em_atraso}(${stats.percentuais_quantidade.em_atraso}%) |
                                Executado: ${stats.contadores.executado}(${stats.percentuais_quantidade.executado}%)
                            </small>
                        </div>
                    `;
                }

                console.log('Tabela PCA preenchida com sucesso!');

            } catch (error) {
                console.error('Erro na função preencherTabelaPCA:', error);
                const tbody = document.querySelector('#tabela-resultados tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 20px; color: #dc2626;">Erro ao exibir resultados. Verifique o console.</td></tr>';
                }
            }
        }

        // Preencher tabela com resultados
        function preencherTabela(data) {
            try {
                console.log('Preenchendo tabela com dados:', data);
                
                const tbody = document.querySelector('#tabela-resultados tbody');
                if (!tbody) {
                    throw new Error('Elemento tbody da tabela não encontrado');
                }
                
                tbody.innerHTML = ''; // Limpar tabela
                
                if (!data.resultados || data.resultados.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: #6b7280;">Nenhum resultado encontrado com os filtros aplicados</td></tr>';
                    return;
                }
                
                data.resultados.forEach((item, index) => {
                    try {
                        const row = document.createElement('tr');
                        
                        // Definir classe CSS para status
                        let statusClass = 'status-analise';
                        if (item.status && (item.status.includes('CONCLU') || item.status === 'CONCLUÍDO')) {
                            statusClass = 'status-concluido';
                        } else if (item.status && item.status.includes('ARQUIVADO')) {
                            statusClass = 'status-arquivado';
                        } else if (item.status && (item.status.includes('ANÁLISE') || item.status.includes('AN') && item.status.includes('LISE'))) {
                            statusClass = 'status-analise';
                        }
                        
                        // Formatar valor se não estiver formatado
                        let valorFormatado = item.valor_formatado || 'R$ 0,00';
                        if (!item.valor_formatado && item.valor_estimado) {
                            try {
                                valorFormatado = `R$ ${parseFloat(item.valor_estimado).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                            } catch (e) {
                                valorFormatado = 'R$ 0,00';
                            }
                        }
                        
                        row.innerHTML = `
                            <td>${item.nup || ''}</td>
                            <td>${item.area_demandante || ''}</td>
                            <td>${item.modalidade || ''}</td>
                            <td><span class="status-badge ${statusClass}">${item.status || ''}</span></td>
                            <td title="${item.objeto_resumo || ''}">${(item.objeto_resumo || '').substring(0, 80)}...</td>
                            <td class="valor">${valorFormatado}</td>
                        `;
                        
                        tbody.appendChild(row);
                    } catch (rowError) {
                        console.error('Erro ao processar linha', index, ':', rowError, 'Item:', item);
                    }
                });
                
                // Atualizar título com estatísticas
                const titleElement = document.querySelector('.results-title');
                if (titleElement && data.estatisticas) {
                    titleElement.innerHTML = `
                        Resultados: ${data.estatisticas.total_registros || 0} registros | Total: ${data.estatisticas.valor_total_formatado || 'R$ 0,00'}
                    `;
                }
                
                console.log('Tabela preenchida com sucesso!');
                
            } catch (error) {
                console.error('Erro na função preencherTabela:', error);
                const tbody = document.querySelector('#tabela-resultados tbody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: #dc2626;">Erro ao exibir resultados. Verifique o console.</td></tr>';
                }
            }
        }
        
        // Limpar todos os filtros
        function limparFiltros() {
            document.getElementById('data_inicio').value = '';
            document.getElementById('data_fim').value = '';
            document.getElementById('preset_periodo').value = '';
            document.getElementById('area_filtro').value = '';
            document.getElementById('status_filtro').value = '';
            document.getElementById('modalidade_filtro').value = '';
            document.getElementById('valor_minimo').value = '';
            document.getElementById('valor_maximo').value = '';
        }
        
        // Exportar relatório
        function exportarRelatorio(formato) {
            const resultsDiv = document.getElementById('results');

            if (!resultsDiv || resultsDiv.style.display === 'none') {
                alert('Nenhum resultado para exportar. Por favor, gere um relatório primeiro.');
                return;
            }

            if (formato === 'html') {
                exportarHTML();
            } else if (formato === 'excel') {
                exportarExcel();
            }
        }

        // Exportar para HTML (abre em nova janela)
        function exportarHTML() {
            const resultsContent = document.querySelector('#results .results-content');

            if (!resultsContent) {
                alert('Nenhum conteúdo encontrado para exportar.');
                return;
            }

            // Obter informações do cabeçalho
            const moduloAtivo = '<?php echo $modulos_disponiveis[$modulo_ativo] ?? "Relatório"; ?>';
            const dataGeracao = new Date().toLocaleString('pt-BR');

            // Criar HTML completo
            const htmlContent = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Gerencial - ${moduloAtivo}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f8fafc;
            padding: 40px 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 3px solid #3498db;
        }
        .header h1 {
            color: #2c3e50;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .header .subtitle {
            color: #7f8c8d;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        .metadata {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
            padding: 20px;
            background: #ecf0f1;
            border-radius: 8px;
        }
        .metadata-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .metadata-item strong {
            color: #2c3e50;
        }
        .content {
            margin-top: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th {
            background: #34495e;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 10px 12px;
            border-bottom: 1px solid #ecf0f1;
        }
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        tr:hover {
            background: #e3f2fd;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-concluido { background: #d4edda; color: #155724; }
        .status-andamento { background: #fff3cd; color: #856404; }
        .status-atrasado { background: #f8d7da; color: #721c24; }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ecf0f1;
            text-align: center;
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        @media print {
            body { padding: 0; }
            .container { box-shadow: none; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Relatório Gerencial Executivo</h1>
            <div class="subtitle">${moduloAtivo}</div>
        </div>

        <div class="metadata">
            <div class="metadata-item">
                <strong>📅 Data de Geração:</strong>
                <span>${dataGeracao}</span>
            </div>
            <div class="metadata-item">
                <strong>👤 Usuário:</strong>
                <span><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
            </div>
            <div class="metadata-item">
                <strong>🏢 Sistema:</strong>
                <span>CGLIC - Ministério da Saúde</span>
            </div>
        </div>

        <div class="content">
            ${resultsContent.innerHTML}
        </div>

        <div class="footer">
            <p><strong>Sistema de Informações CGLIC</strong> | Ministério da Saúde</p>
            <p>Relatório gerado automaticamente em ${dataGeracao}</p>
        </div>
    </div>
</body>
</html>`;

            // Abrir em nova janela
            const novaJanela = window.open('', '_blank');
            if (novaJanela) {
                novaJanela.document.write(htmlContent);
                novaJanela.document.close();
            } else {
                alert('Popup bloqueado! Por favor, permita popups para este site.');
            }
        }

        // Exportar para Excel (CSV)
        function exportarExcel() {
            alert('Exportação para Excel em desenvolvimento.\n\nEm breve você poderá exportar os dados em formato CSV compatível com Excel.');
        }
        
        // Gerar relatório final
        function gerarRelatorioFinal() {
            const formato = document.getElementById('formato_principal').value;
            alert('Gerando relatório final em formato ' + formato.toUpperCase() + '...');
        }
        
        // Gerar Dashboard Executivo
        function gerarDashboardExecutivo() {
            alert('Dashboard Executivo será implementado - Visão consolidada de:\n\n• Total de contratações planejadas vs executadas\n• Performance geral por módulo\n• Principais gargalos identificados\n• Indicadores de economia\n• Timeline de entregas\n\nEm desenvolvimento para próxima versão.');
        }

        // Atualizar Dashboard por Ano
        function atualizarDashboardPorAno() {
            console.log('Ano do PCA alterado, atualizando dashboard...');
            carregarAreasRequisitantes(); // Carregar áreas do ano selecionado
            carregarDashboardPCA();
        }

        // Carregar áreas requisitantes dinamicamente
        function carregarAreasRequisitantes() {
            const anoSelecionado = document.getElementById('ano_pca_header')?.value || new Date().getFullYear();
            const selectArea = document.getElementById('area_requisitante_filtro');

            if (!selectArea) return;

            console.log('Carregando áreas requisitantes para o ano:', anoSelecionado);

            // Mostrar loading
            selectArea.innerHTML = '<option value="">🔄 Carregando áreas...</option>';
            selectArea.disabled = true;

            fetch(`api/get_areas_requisitantes.php?ano=${anoSelecionado}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Limpar e adicionar opção padrão
                        selectArea.innerHTML = '<option value="">Todas as Áreas</option>';

                        // Adicionar áreas carregadas
                        data.areas.forEach(area => {
                            const option = document.createElement('option');
                            option.value = area.codigo;
                            option.textContent = `${area.nome} (${area.quantidade_contratacoes} contratações)`;
                            selectArea.appendChild(option);
                        });

                        console.log(`✅ ${data.total_areas} áreas carregadas para ${data.ano}`);
                    } else {
                        selectArea.innerHTML = '<option value="">❌ Erro ao carregar áreas</option>';
                        console.error('Erro ao carregar áreas:', data.message);
                    }
                })
                .catch(error => {
                    selectArea.innerHTML = '<option value="">❌ Erro na conexão</option>';
                    console.error('Erro na requisição:', error);
                })
                .finally(() => {
                    selectArea.disabled = false;
                });
        }

        // Carregar Dashboard Executivo PCA
        function carregarDashboardPCA() {
            console.log('Carregando dashboard executivo PCA...');

            // Mostrar dashboard
            const dashboard = document.getElementById('dashboard-pca');
            if (dashboard) {
                dashboard.style.display = 'grid';
            }

            // Obter ano selecionado do campo (padrão: 2025)
            const anoSelecionado = document.getElementById('ano_pca_header') ? document.getElementById('ano_pca_header').value : '2025';

            // Buscar dados do servidor (CORRIGIDO - envia ano selecionado)
            fetch('process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `acao=dashboard_executivo_pca&ano=${anoSelecionado}`
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.estatisticas) {
                    const stats = data.estatisticas;

                    // Atualizar cards combinados do dashboard
                    document.getElementById('total-contratacoes').textContent = stats.total_contratacoes || '0';
                    document.getElementById('percentual-licitados').textContent = (stats.percentual_licitados || '0') + '%';
                    document.getElementById('valor-total-pca').textContent = stats.valor_total_formatado || 'R$ 0,00';

                    // Card de Contratações Aprovadas
                    document.getElementById('total-aprovadas').textContent = stats.total_aprovadas || '0';
                    document.getElementById('valor-aprovadas').textContent = stats.valor_aprovadas_formatado || 'R$ 0,00';

                    // Cards combinados com valor por status
                    document.getElementById('total-atraso').textContent = stats.total_atraso || '0';
                    document.getElementById('valor-atraso').textContent = stats.valor_atraso_formatado || 'R$ 0,00';

                    document.getElementById('total-preparacao').textContent = stats.total_preparacao || '0';
                    document.getElementById('valor-preparacao').textContent = stats.valor_preparacao_formatado || 'R$ 0,00';

                    // Card de Contratações Encerradas (novo KPI)
                    document.getElementById('total-encerradas').textContent = stats.total_encerradas || '0';
                    document.getElementById('valor-encerradas').textContent = stats.valor_encerradas_formatado || 'R$ 0,00';

                    console.log('Dashboard PCA atualizado com sucesso:', stats);
                } else {
                    console.error('Erro ao carregar estatísticas:', data.message);
                }
            })
            .catch(error => {
                console.error('Erro ao carregar dashboard PCA:', error);
            });
        }

        // Dashboard Qualificações
        function carregarDashboardQualificacoes() {
            console.log('Carregando dashboard das qualificações...');

            // Buscar dados do servidor
            fetch('process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'acao=dashboard_executivo_qualificacoes'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.estatisticas) {
                    const stats = data.estatisticas;

                    // Atualizar cards do dashboard de qualificações
                    document.getElementById('total-processos-qual').textContent = stats.total_processos || '0';
                    document.getElementById('valor-total-qual').textContent = stats.valor_total_formatado || 'R$ 0,00';

                    // Cards por status
                    document.getElementById('total-primeira-analise').textContent = stats.total_primeira_analise || '0';
                    document.getElementById('valor-primeira-analise').textContent = stats.valor_primeira_analise_formatado || 'R$ 0,00';

                    document.getElementById('total-segunda-analise').textContent = stats.total_segunda_analise || '0';
                    document.getElementById('valor-segunda-analise').textContent = stats.valor_segunda_analise_formatado || 'R$ 0,00';

                    document.getElementById('total-concluidos').textContent = stats.total_concluidos || '0';
                    document.getElementById('valor-concluidos').textContent = stats.valor_concluidos_formatado || 'R$ 0,00';

                    document.getElementById('total-arquivados').textContent = stats.total_arquivados || '0';
                    document.getElementById('valor-arquivados').textContent = stats.valor_arquivados_formatado || 'R$ 0,00';

                    console.log('Dashboard Qualificações atualizado com sucesso:', stats);
                } else {
                    console.error('Erro ao carregar estatísticas:', data.message);
                }
            })
            .catch(error => {
                console.error('Erro ao carregar dashboard Qualificações:', error);
            });
        }

        // Dashboard Licitações
        function carregarDashboardLicitacoes() {
            console.log('Carregando dashboard das licitações...');

            // Buscar dados do servidor
            fetch('process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'acao=dashboard_executivo_licitacoes'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.estatisticas) {
                    const stats = data.estatisticas;

                    // Atualizar cards do dashboard de licitações
                    document.getElementById('total-licitacoes').textContent = stats.total_licitacoes || '0';
                    document.getElementById('valor-total-licitacoes').textContent = stats.valor_total_formatado || 'R$ 0,00';

                    // Cards por situação
                    document.getElementById('total-homologadas').textContent = stats.total_homologadas || '0';
                    document.getElementById('valor-homologadas').textContent = stats.valor_homologadas_formatado || 'R$ 0,00';

                    document.getElementById('total-andamento').textContent = stats.total_andamento || '0';
                    document.getElementById('valor-andamento').textContent = stats.valor_andamento_formatado || 'R$ 0,00';

                    document.getElementById('total-canceladas').textContent = stats.total_canceladas || '0';
                    document.getElementById('valor-canceladas').textContent = stats.valor_canceladas_formatado || 'R$ 0,00';

                    // Card especial de economia
                    document.getElementById('economia-total').textContent = stats.economia_total_formatado || 'R$ 0,00';
                    document.getElementById('economia-percentual').textContent = stats.economia_percentual || '0%';

                    console.log('Dashboard Licitações atualizado com sucesso:', stats);
                } else {
                    console.error('Erro ao carregar estatísticas:', data.message);
                }
            })
            .catch(error => {
                console.error('Erro ao carregar dashboard Licitações:', error);
            });
        }

        // Relatórios de Planejamento
        function gerarRelatorioPlanejamento(tipo) {
            const titulos = {
                'status': 'Relatório por Status do PCA',
                'area': 'Relatório por Área Demandante',
                'prazo': 'Relatório de Prazos',
                'financeiro': 'Relatório Financeiro'
            };

            alert(`${titulos[tipo]}\n\nSistema em desenvolvimento - Funcionalidades:\n\n• Filtros avançados por período\n• Análise de situação de execução\n• Exportação em múltiplos formatos\n• Gráficos estatísticos interativos\n\nImplementação: Próxima versão`);
        }

        // Relatórios Específicos SAA
        function gerarRelatorioSAA(tipo) {
            const ano = document.getElementById('ano_pca_header')?.value || 2025;
            const coordenacao = document.getElementById('coordenacao_saa_filtro')?.value || '';
            const formato = 'html';
            const incluir_graficos = 1;

            let url = `relatorios/relatorios_saa.php?tipo=${tipo}&ano=${ano}&formato=${formato}`;

            if (coordenacao) {
                url += `&coordenacao=${encodeURIComponent(coordenacao)}`;
            }

            if (incluir_graficos) {
                url += '&incluir_graficos=1';
            }

            console.log('Gerando relatório SAA:', tipo, 'URL:', url);

            // Abrir em nova aba
            window.open(url, '_blank');
        }

        // Função para filtrar por coordenação SAA
        function filtrarPorCoordenacaoSAA() {
            const coordenacao = document.getElementById('coordenacao_saa_filtro').value;

            if (coordenacao) {
                // Atualizar filtro de área requisitante para a coordenação selecionada
                document.getElementById('area_requisitante_filtro').value = coordenacao;

                console.log('Filtrado por coordenação SAA:', coordenacao);
            } else {
                // Limpar filtro de área requisitante
                document.getElementById('area_requisitante_filtro').value = '';
            }
        }

        // Relatórios de Licitação
        function gerarRelatorioLicitacao(tipo) {
            const titulos = {
                'modalidade': 'Relatório por Modalidade',
                'pregoeiro': 'Relatório por Pregoeiro',
                'tempo': 'Relatório de Prazos',
                'economia': 'Relatório de Economia'
            };

            alert(`${titulos[tipo]}\n\nSistema em desenvolvimento - Funcionalidades:\n\n• Performance detalhada por categoria\n• Análise de tempos e gargalos\n• Cálculo de economia gerada\n• Comparativos históricos\n\nImplementação: Próxima versão`);
        }

        // Relatórios de Contratos
        function gerarRelatorioContrato(tipo) {
            const titulos = {
                'status': 'Relatório por Status',
                'vigencia': 'Relatório de Vigências',
                'fornecedor': 'Relatório por Fornecedor',
                'valor': 'Relatório Financeiro'
            };

            alert(`${titulos[tipo]}\n\nSistema em desenvolvimento - Funcionalidades:\n\n• Controle de vigências e renovações\n• Análise de performance de fornecedores\n• Execução orçamentária e financeira\n• Alertas de vencimentos\n\nImplementação: Próxima versão`);
        }

        // Inicializar página
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($modulo_ativo == 'qualificacao'): ?>
            carregarAreas();
            carregarDashboardQualificacoes();
            <?php elseif ($modulo_ativo == 'planejamento'): ?>
            carregarAreasRequisitantes(); // Carregar áreas na inicialização
            carregarDashboardPCA();
            <?php elseif ($modulo_ativo == 'licitacao'): ?>
            carregarDashboardLicitacoes();
            <?php endif; ?>
            lucide.createIcons();
        });
    </script>
</body>
</html>