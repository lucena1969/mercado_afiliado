<?php
echo "PHP funcionando!";
phpinfo();
?>