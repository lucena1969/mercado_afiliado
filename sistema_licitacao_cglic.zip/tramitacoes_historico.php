<?php
require_once 'config.php';
require_once 'functions.php';

verificarLogin();

$pdo = conectarDB();
$usuario_nivel = $_SESSION['usuario_nivel'];

// Verificar permissões - todos podem visualizar o histórico
// Aplicar filtros baseados no nível do usuário
$where_conditions = ["1=1"];
$params = [];

if ($usuario_nivel == 2) { // DIPLAN - apenas planejamento
    $where_conditions[] = "(t.modulo_origem = 'PLANEJAMENTO' OR t.modulo_destino = 'PLANEJAMENTO')";
} elseif ($usuario_nivel == 3) { // DIPLI - licitação, qualificação, contratos
    $where_conditions[] = "(t.modulo_origem IN ('LICITACAO','QUALIFICACAO','CONTRATOS') OR t.modulo_destino IN ('LICITACAO','QUALIFICACAO','CONTRATOS'))";
}

// Filtro por NUP específico (vindos da tela de qualificação)
$filtro_nup = $_GET['filtro_nup'] ?? '';
$where_clause_main = implode(' AND ', $where_conditions);
$where_clause_stats = implode(' AND ', $where_conditions);
$params_main = $params;
$params_stats = $params;

if (!empty($filtro_nup)) {
    // Para query principal (com JOIN)
    $where_conditions_main = $where_conditions;
    $where_conditions_main[] = "(q.nup = ? OR t.nup_vinculado = ?)";
    $params_main[] = $filtro_nup;
    $params_main[] = $filtro_nup;
    $where_clause_main = implode(' AND ', $where_conditions_main);
    
    // Para query de estatísticas (sem JOIN)
    $where_conditions_stats = $where_conditions;
    $where_conditions_stats[] = "t.nup_vinculado = ?";
    $params_stats[] = $filtro_nup;
    $where_clause_stats = implode(' AND ', $where_conditions_stats);
}

// Buscar tramitações completas com dados de qualificação
$query = "
    SELECT 
        t.*,
        u_criador.nome as nome_criador,
        u_responsavel.nome as nome_responsavel,
        q.nup,
        q.objeto,
        q.area_demandante,
        q.responsavel as responsavel_qualificacao,
        q.valor_estimado,
        q.status as status_qualificacao
    FROM tramitacoes_kanban t
    LEFT JOIN usuarios u_criador ON t.usuario_criador_id = u_criador.id
    LEFT JOIN usuarios u_responsavel ON t.usuario_responsavel_id = u_responsavel.id
    LEFT JOIN qualificacoes q ON t.qualificacao_id = q.id
    WHERE $where_clause_main
    ORDER BY t.criado_em DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute($params_main);
$tramitacoes = $stmt->fetchAll();

// Buscar estatísticas gerais
$stats_query = "
    SELECT 
        COALESCE(COUNT(*), 0) as total,
        COALESCE(SUM(CASE WHEN status = 'TODO' THEN 1 ELSE 0 END), 0) as todo,
        COALESCE(SUM(CASE WHEN status = 'EM_PROGRESSO' THEN 1 ELSE 0 END), 0) as em_progresso,
        COALESCE(SUM(CASE WHEN status = 'AGUARDANDO' THEN 1 ELSE 0 END), 0) as aguardando,
        COALESCE(SUM(CASE WHEN status = 'CONCLUIDO' THEN 1 ELSE 0 END), 0) as concluido,
        COALESCE(SUM(CASE WHEN status = 'CANCELADO' THEN 1 ELSE 0 END), 0) as cancelado
    FROM tramitacoes_kanban t
    WHERE $where_clause_stats
";

$stmt_stats = $pdo->prepare($stats_query);
$stmt_stats->execute($params_stats);
$stats = $stmt_stats->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Tramitações - Sistema CGLIC</title>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <link rel="stylesheet" href="assets/design-system.css">
    <style>
        /* Layout compacto para histórico */
        body {
            background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
            min-height: 100vh;
            padding: 16px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header compacto */
        .header {
            background: white;
            border-radius: 12px;
            padding: 20px 24px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            color: #1e293b;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }

        .header-content .subtitle {
            color: #64748b;
            font-size: 14px;
            margin-top: 4px;
        }

        .header-actions {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .btn-action {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .btn-action:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .btn-action.secondary {
            background: linear-gradient(135deg, #64748b, #475569);
        }

        .btn-action.secondary:hover {
            box-shadow: 0 4px 12px rgba(100, 116, 139, 0.3);
        }

        /* Cards de estatísticas compactos */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 16px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0;
            transition: all 0.2s ease;
            position: relative;
        }

        .stat-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            border-radius: 10px 10px 0 0;
        }

        .stat-card.total::before { background: #3b82f6; }
        .stat-card.todo::before { background: #64748b; }
        .stat-card.em-progresso::before { background: #f59e0b; }
        .stat-card.aguardando::before { background: #8b5cf6; }
        .stat-card.concluido::before { background: #22c55e; }
        .stat-card.cancelado::before { background: #ef4444; }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 4px;
            font-feature-settings: 'tnum';
        }

        .stat-card.total .stat-value { color: #3b82f6; }
        .stat-card.todo .stat-value { color: #64748b; }
        .stat-card.em-progresso .stat-value { color: #f59e0b; }
        .stat-card.aguardando .stat-value { color: #8b5cf6; }
        .stat-card.concluido .stat-value { color: #22c55e; }
        .stat-card.cancelado .stat-value { color: #ef4444; }

        .stat-label {
            color: #64748b;
            font-size: 12px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Tabela elegante */
        .table-container {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }

        .table-header {
            background: linear-gradient(135deg, #1e293b, #334155);
            color: white;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0;
        }

        .filter-badge {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #f1f5f9;
        }

        .table th {
            background: #f8fafc;
            font-weight: 600;
            color: #475569;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table td {
            font-size: 13px;
            color: #334155;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: #f8fafc;
        }

        /* Badges de status compactos */
        .status-badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .status-badge::before {
            content: '';
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: currentColor;
        }

        .status-todo { background: #f1f5f9; color: #64748b; }
        .status-em-progresso { background: #fef3c7; color: #d97706; }
        .status-aguardando { background: #ede9fe; color: #7c3aed; }
        .status-concluido { background: #dcfce7; color: #16a34a; }
        .status-cancelado { background: #fee2e2; color: #dc2626; }

        .priority-badge {
            padding: 2px 8px;
            border-radius: 8px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .priority-baixa { background: #f1f5f9; color: #64748b; }
        .priority-media { background: #dbeafe; color: #2563eb; }
        .priority-alta { background: #fed7aa; color: #ea580c; }
        .priority-urgente { background: #fecaca; color: #dc2626; animation: pulse 2s infinite; }

        .valor-monetario {
            font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
            font-weight: 600;
            color: #16a34a;
            font-size: 12px;
        }

        .truncate {
            max-width: 180px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Estado vazio elegante */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #64748b;
        }

        .empty-state-icon {
            font-size: 48px;
            margin-bottom: 12px;
            opacity: 0.4;
        }

        .empty-state h3 {
            font-size: 18px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
        }

        .empty-state p {
            font-size: 14px;
            color: #64748b;
        }

        /* Responsivo */
        @media (max-width: 768px) {
            body { padding: 12px; }
            
            .header {
                flex-direction: column;
                gap: 12px;
                text-align: center;
                padding: 16px;
            }

            .header-content h1 {
                font-size: 20px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }

            .stat-card {
                padding: 12px;
            }

            .stat-value {
                font-size: 24px;
            }

            .table th,
            .table td {
                padding: 8px 12px;
                font-size: 12px;
            }

            .truncate {
                max-width: 120px;
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <h1>
                    <i data-lucide="history"></i>
                    Histórico de Tramitações
                    <?php if (!empty($filtro_nup)): ?>
                        <span style="color: #8b5cf6; font-weight: 500; font-size: 16px;">
                            - Processo <?= htmlspecialchars($filtro_nup) ?>
                        </span>
                    <?php endif; ?>
                </h1>
                <div class="subtitle">
                    <?php if (!empty($filtro_nup)): ?>
                        Tramitações vinculadas ao processo <strong><?= htmlspecialchars($filtro_nup) ?></strong>
                    <?php else: ?>
                        Visualização completa de todas as tramitações do sistema
                    <?php endif; ?>
                </div>
            </div>
            <div class="header-actions">
                <?php if (!empty($filtro_nup)): ?>
                    <a href="qualificacao_dashboard.php" class="btn-action secondary">
                        <i data-lucide="arrow-left"></i>
                        Voltar à Qualificação
                    </a>
                <?php endif; ?>
                <a href="tramitacao_kanban.php" class="btn-action">
                    <i data-lucide="kanban-square"></i>
                    <?= !empty($filtro_nup) ? 'Ir ao Kanban' : 'Voltar ao Kanban' ?>
                </a>
            </div>
        </div>

        <!-- Estatísticas -->
        <div class="stats-grid">
            <div class="stat-card total">
                <div class="stat-value"><?= number_format($stats['total'] ?? 0) ?></div>
                <div class="stat-label">Total de Tramitações</div>
            </div>
            <div class="stat-card todo">
                <div class="stat-value"><?= number_format($stats['todo'] ?? 0) ?></div>
                <div class="stat-label">A Fazer</div>
            </div>
            <div class="stat-card em-progresso">
                <div class="stat-value"><?= number_format($stats['em_progresso'] ?? 0) ?></div>
                <div class="stat-label">Em Progresso</div>
            </div>
            <div class="stat-card aguardando">
                <div class="stat-value"><?= number_format($stats['aguardando'] ?? 0) ?></div>
                <div class="stat-label">Aguardando</div>
            </div>
            <div class="stat-card concluido">
                <div class="stat-value"><?= number_format($stats['concluido'] ?? 0) ?></div>
                <div class="stat-label">Concluído</div>
            </div>
            <div class="stat-card cancelado">
                <div class="stat-value"><?= number_format($stats['cancelado'] ?? 0) ?></div>
                <div class="stat-label">Cancelado</div>
            </div>
        </div>

        <!-- Tabela de Tramitações -->
        <div class="table-container">
            <div class="table-header">
                <h2>
                    <i data-lucide="table"></i>
                    Histórico Completo de Tramitações
                </h2>
                <?php if (!empty($filtro_nup)): ?>
                    <div class="filter-badge">
                        <i data-lucide="filter" style="width: 12px; height: 12px;"></i>
                        NUP: <?= htmlspecialchars($filtro_nup) ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (empty($tramitacoes)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i data-lucide="inbox"></i>
                    </div>
                    <?php if (!empty($filtro_nup)): ?>
                        <h3>Nenhuma tramitação encontrada para este processo</h3>
                        <p>O processo <strong><?= htmlspecialchars($filtro_nup) ?></strong> ainda não possui tramitações vinculadas.</p>
                    <?php else: ?>
                        <h3>Nenhuma tramitação encontrada</h3>
                        <p>Não há tramitações para exibir com os filtros aplicados.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="table-wrapper">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nº Tramite</th>
                                <th>Título</th>
                                <th>NUP</th>
                                <th>Objeto</th>
                                <th>Área</th>
                                <th>Responsável</th>
                                <th>Valor Estimado</th>
                                <th>Status</th>
                                <th>Prioridade</th>
                                <th>Criado em</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tramitacoes as $tramitacao): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($tramitacao['numero_tramite']) ?></strong>
                                    </td>
                                    <td>
                                        <div class="truncate" title="<?= htmlspecialchars($tramitacao['titulo']) ?>">
                                            <?= htmlspecialchars($tramitacao['titulo']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($tramitacao['nup']): ?>
                                            <strong><?= htmlspecialchars($tramitacao['nup']) ?></strong>
                                        <?php elseif ($tramitacao['nup_vinculado']): ?>
                                            <?= htmlspecialchars($tramitacao['nup_vinculado']) ?>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($tramitacao['objeto']): ?>
                                            <div class="truncate" title="<?= htmlspecialchars($tramitacao['objeto']) ?>">
                                                <?= htmlspecialchars($tramitacao['objeto']) ?>
                                            </div>
                                        <?php elseif ($tramitacao['objeto_vinculado']): ?>
                                            <div class="truncate" title="<?= htmlspecialchars($tramitacao['objeto_vinculado']) ?>">
                                                <?= htmlspecialchars($tramitacao['objeto_vinculado']) ?>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($tramitacao['area_demandante']): ?>
                                            <?= htmlspecialchars($tramitacao['area_demandante']) ?>
                                        <?php elseif ($tramitacao['area_vinculada']): ?>
                                            <?= htmlspecialchars($tramitacao['area_vinculada']) ?>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($tramitacao['nome_responsavel']): ?>
                                            <?= htmlspecialchars($tramitacao['nome_responsavel']) ?>
                                        <?php elseif ($tramitacao['responsavel_qualificacao']): ?>
                                            <?= htmlspecialchars($tramitacao['responsavel_qualificacao']) ?>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">Não atribuído</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($tramitacao['valor_estimado']): ?>
                                            <span class="valor-monetario">
                                                R$ <?= number_format($tramitacao['valor_estimado'] / 100, 2, ',', '.') ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?= strtolower(str_replace('_', '-', $tramitacao['status'])) ?>">
                                            <?= str_replace('_', ' ', $tramitacao['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="priority-badge priority-<?= strtolower($tramitacao['prioridade']) ?>">
                                            <?= $tramitacao['prioridade'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= date('d/m/Y H:i', strtotime($tramitacao['criado_em'])) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Inicializar ícones Lucide
        lucide.createIcons();
    </script>
</body>
</html>